-- =====================================================================
--  Me Dog — ข้อมูลตัวอย่าง (ไม่บังคับ) ใช้สำหรับเดโม/นำเสนอ
--  ทุกแถวถูกทำเครื่องหมาย is_demo = true
--  ลบทิ้งได้ทีหลังจากหน้า "แอดมิน → ภาพรวม → ลบข้อมูลตัวอย่าง"
--  หมายเหตุ: พิกัดเป็นค่าประมาณเพื่อการสาธิตเท่านั้น
-- =====================================================================

-- ---------- สัตว์ตัวอย่าง ----------
create temp table demo_areas (amphoe text, tambon text, lat float8, lng float8, n int, vacc float8, steril float8);
insert into demo_areas values
  ('เมืองเพชรบูรณ์', 'ในเมือง',   16.4190, 101.1590, 40, 0.92, 0.80),
  ('เมืองเพชรบูรณ์', 'สะเดียง',   16.4020, 101.1380, 30, 0.58, 0.40),
  ('เมืองเพชรบูรณ์', 'ตะเบาะ',    16.3400, 101.2300, 25, 0.22, 0.15),
  ('เมืองเพชรบูรณ์', 'บ้านโตก',   16.4600, 101.1300, 20, 0.52, 0.30),
  ('เมืองเพชรบูรณ์', 'นางั่ว',    16.4750, 101.2000, 18, 0.30, 0.20),
  ('เมืองเพชรบูรณ์', 'ห้วยใหญ่',  16.3600, 101.1200, 15, 0.86, 0.72),
  ('เมืองเพชรบูรณ์', 'ป่าเลา',    16.4400, 101.2400, 15, 0.40, 0.25),
  ('เมืองเพชรบูรณ์', 'ท่าพล',     16.5500, 101.1200, 20, 0.80, 0.62),
  ('หล่มสัก',       'หล่มสัก',   16.7800, 101.2450, 25, 0.33, 0.20),
  ('หล่มเก่า',      'หล่มเก่า',  16.8850, 101.2300, 15, 0.62, 0.40),
  ('วิเชียรบุรี',    'ท่าโรง',    15.6600, 101.1000, 20, 0.45, 0.30),
  ('เขาค้อ',        'แคมป์สน',   16.7700, 101.0100, 12, 0.90, 0.75);

insert into public.animals (
  owner_id, is_demo, species, status, name, sex, breed, color, birth_date, birth_date_estimated,
  sterilized, temperament, bite_history, province, amphoe, tambon, lat, lng, address_note
)
select null, true,
       case when r.species < 0.7 then 'dog' else 'cat' end,
       case when r.status < 0.55 then 'pet' when r.status < 0.8 then 'community' else 'stray' end,
       (array['ถุงทอง','โกโก้','มะลิ','ข้าวปั้น','ด่างดำ','เจ้าขาว','ส้มจี๊ด','ลูกชิ้น','ขนมปัง','บราวนี่',
              'ภูผา','ทองดี','มอมแมม','ปุยฝ้าย','เสือ','ไข่เจียว','น้ำตาล','ชาไทย','ดำดี','หมูแดง'])[1 + floor(r.nm * 20)::int]
         || ' (ตัวอย่าง)',
       case when r.sex < 0.48 then 'male' when r.sex < 0.95 then 'female' else 'unknown' end,
       case when r.species < 0.7 then 'พันธุ์ไทย/พันธุ์ผสม' else 'แมวไทยพื้นบ้าน' end,
       (array['น้ำตาล','ดำ','ขาว','ครีม','ลายเสือ','ด่าง'])[1 + floor(r.col * 6)::int],
       (current_date - (200 + floor(r.age * 3000))::int), true,
       case when r.steril < a.steril then 'yes' when r.steril < a.steril + 0.3 then 'no' else 'unknown' end,
       case when r.temper < 0.08 then 'aggressive' when r.temper < 0.2 then 'guarding'
            when r.temper < 0.4 then 'shy' else 'friendly' end,
       r.temper < 0.04,
       'เพชรบูรณ์', a.amphoe, a.tambon,
       a.lat + (r.dlat - 0.5) * 0.03, a.lng + (r.dlng - 0.5) * 0.03,
       'ข้อมูลตัวอย่างสำหรับสาธิต'
from demo_areas a
cross join lateral generate_series(1, a.n) gs
cross join lateral (
  select random() + gs * 0 as species, random() as status, random() as sex, random() as nm, random() as col,
         random() as age, random() as steril, random() as temper, random() as dlat, random() as dlng
) r;

-- วัคซีนพิษสุนัขบ้า: แต่ละตำบลมีอัตราต่างกัน (ให้แผนที่มีทั้งเขียว/เหลือง/แดง)
insert into public.vaccinations (animal_id, vaccine, given_on, next_due, clinic)
select v.id, 'rabies', v.given, v.given + 365, 'หน่วยฉีดวัคซีนเคลื่อนที่ (ตัวอย่าง)'
from (
  select an.id, a.vacc, random() as r, (current_date - (20 + floor(random() * 300))::int) as given
  from public.animals an join demo_areas a on a.tambon = an.tambon
  where an.is_demo
) v
where v.r < v.vacc;

-- วัคซีนรวม (สุนัข/แมว)
insert into public.vaccinations (animal_id, vaccine, given_on, next_due, clinic)
select v.id, case when v.species = 'cat' then 'cat_core' else 'dog_core' end, v.given, v.given + 365, 'คลินิกตัวอย่าง'
from (
  select an.id, an.species, a.vacc, random() as r, (current_date - (20 + floor(random() * 300))::int) as given
  from public.animals an join demo_areas a on a.tambon = an.tambon
  where an.is_demo
) v
where v.r < v.vacc * 0.85;

drop table demo_areas;

-- ---------- หน่วยงานในพื้นที่ (ชื่อจริง — โปรดเพิ่มช่องทางติดต่อเอง) ----------
insert into public.agencies (name, kind, province, amphoe, tambon, notes) values
  ('เทศบาลเมืองเพชรบูรณ์', 'municipality', 'เพชรบูรณ์', 'เมืองเพชรบูรณ์', 'ในเมือง', 'ช่องทางร้องเรียน LINE OA หัวข้อ สุนัขจรจัด/แมวไม่มีเจ้าของ — โปรดเพิ่มเบอร์ติดต่อ'),
  ('สำนักงานปศุสัตว์อำเภอเมืองเพชรบูรณ์', 'livestock', 'เพชรบูรณ์', 'เมืองเพชรบูรณ์', null, 'ปฐมพยาบาลสัตว์ป่วย/บาดเจ็บเบื้องต้น; โครงการฉีดวัคซีน/ทำหมันต้องให้ อปท. ประสานขอ — โปรดเพิ่มเบอร์ติดต่อ'),
  ('สำนักงานปศุสัตว์จังหวัดเพชรบูรณ์', 'livestock', 'เพชรบูรณ์', null, null, 'โปรดเพิ่มเบอร์ติดต่อ');

-- ---------- เคสตัวอย่าง ----------
insert into public.cases (is_demo, title, category, species, animal_count, description, province, amphoe, tambon,
  location_note, lat, lng, proximity, aggression, vaccination_status, status, is_urgent, goal_amount, fund_purpose, public_note)
values
  (true, 'ฝูงสุนัขจร 6 ตัวหน้าโรงเรียน ยังไม่ได้ฉีดวัคซีน (ตัวอย่าง)', 'aggressive', 'dog', 6,
   'สุนัขจรรวมฝูงบริเวณหน้าประตูโรงเรียนช่วงเช้า มีเห่าไล่เด็กนักเรียน ไม่มีปลอกคอ ไม่ทราบประวัติวัคซีน',
   'เพชรบูรณ์', 'เมืองเพชรบูรณ์', 'ตะเบาะ', 'หน้าโรงเรียน ใกล้ร้านค้าชุมชน', 16.3420, 101.2280,
   'very_near', 'medium', 'none', 'fundraising', true, 8000, 'ค่าวัคซีนพิษสุนัขบ้า + ทำหมัน 6 ตัว', 'ประสานเทศบาลแล้ว รอคิวหน่วยทำหมันเคลื่อนที่'),
  (true, 'แม่แมวคลอดลูก 4 ตัวใต้ศาลาวัด (ตัวอย่าง)', 'puppies', 'cat', 5,
   'แม่แมวจรคลอดลูกใต้ศาลา ลูกแมวอายุประมาณ 3 สัปดาห์ ต้องการอาหารและที่อยู่ชั่วคราว',
   'เพชรบูรณ์', 'เมืองเพชรบูรณ์', 'นางั่ว', 'ศาลาวัด', 16.4760, 101.2010,
   'near', 'none', 'unknown', 'verified', false, null, null, null),
  (true, 'สุนัขขาหลังบาดเจ็บ เดินกะเผลก (ตัวอย่าง)', 'injured', 'dog', 1,
   'สุนัขเพศผู้สีน้ำตาล ขาหลังขวาบาดเจ็บ มีแผลเปิด อยู่บริเวณตลาดเช้า',
   'เพชรบูรณ์', 'หล่มสัก', 'หล่มสัก', 'ตลาดเช้า', 16.7810, 101.2460,
   'near', 'low', 'unknown', 'fundraising', true, 3500, 'ค่ารักษาแผลและยา', 'อาสาพาไปคลินิกแล้ว'),
  (true, 'ขอสนับสนุนอาหารสัตว์ชุมชน 15 ตัว (ตัวอย่าง)', 'food', 'dog', 15,
   'คุณป้าในชุมชนดูแลสุนัขชุมชน 15 ตัว ต้องการอาหารเม็ดรายเดือน',
   'เพชรบูรณ์', 'เมืองเพชรบูรณ์', 'สะเดียง', 'ชุมชนริมน้ำ', 16.4010, 101.1370,
   'far', 'none', 'partial', 'forwarded', false, null, null, null),
  (true, 'ทำหมันแมวชุมชนเสร็จแล้ว 8 ตัว (ตัวอย่าง)', 'sterilize', 'cat', 8,
   'ร่วมกับคลินิกในพื้นที่ทำหมันแมวชุมชนครบทุกตัว',
   'เพชรบูรณ์', 'เมืองเพชรบูรณ์', 'ในเมือง', 'ตลาดสด', 16.4185, 101.1600,
   'near', 'none', 'vaccinated', 'resolved', false, null, null, 'ปิดเคสเรียบร้อย ขอบคุณผู้บริจาคทุกท่าน');

insert into public.case_updates (case_id, status, note, is_public)
select id, 'submitted', 'รับแจ้งเคส', true from public.cases where is_demo;
insert into public.case_updates (case_id, status, note, is_public)
select id, status, public_note, true from public.cases where is_demo and status <> 'submitted';

-- ---------- บริจาคตัวอย่าง (ยืนยันแล้ว) ----------
insert into public.donations (case_id, donor_id, donor_name, is_anonymous, amount, message, status, confirmed_at, is_demo)
select c.id, null, d.name, d.anon, d.amount, d.msg, 'confirmed', now(), true
from public.cases c
cross join (values
  ('คุณเอ (ตัวอย่าง)', false, 1500::numeric, 'ขอให้น้องๆ ปลอดภัย'),
  ('', true, 500::numeric, null),
  ('ร้านอาหารสัตว์ใจดี (ตัวอย่าง)', false, 2000::numeric, 'สนับสนุนค่าวัคซีน')
) as d(name, anon, amount, msg)
where c.is_demo and c.status = 'fundraising';

-- ---------- สินค้าตัวอย่าง ----------
insert into public.products (name, description, price, category, impact_note, stock, sort, is_demo) values
  ('อาหารเม็ดสุนัข 10 กก. (ส่งถึงจุดดูแล)', 'อาหารเม็ดสำหรับสุนัขโต ส่งตรงถึงจุดให้อาหารสัตว์ชุมชน', 690, 'food', '1 ถุง = อาหารประมาณ 60 มื้อสำหรับน้องหมาจร', 50, 1, true),
  ('อาหารเม็ดแมว 7 กก.', 'อาหารแมวโต สูตรควบคุมก้อนขน', 590, 'food', '1 ถุง = อาหารประมาณ 100 มื้อสำหรับน้องแมว', 40, 2, true),
  ('ชุดทำแผลสำหรับอาสา', 'น้ำเกลือ ผ้าก๊อซ ยาฆ่าเชื้อ ถุงมือ ปลอกคอกันเลีย', 350, 'medical', 'ช่วยอาสาปฐมพยาบาลน้องที่บาดเจ็บได้ 5–10 เคส', 30, 3, true),
  ('สนับสนุนวัคซีนพิษสุนัขบ้า 1 เข็ม', 'ร่วมจ่ายค่าวัคซีนให้สัตว์จรในพื้นที่เสี่ยง (แดง)', 150, 'kit', '1 เข็ม = ปกป้องน้อง 1 ตัว และคนในชุมชนนาน 1 ปี', null, 4, true),
  ('สติกเกอร์ "จมูกหมา" Me Dog', 'สติกเกอร์กันน้ำ ขนาด 7 ซม. รายได้ทั้งหมดเข้ากองทุน', 49, 'merch', 'ทุก 3 ชิ้น = อาหาร 1 มื้อ', 200, 5, true);
