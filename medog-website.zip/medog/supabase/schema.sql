-- =====================================================================
--  Me Dog — โครงสร้างฐานข้อมูล (Supabase / PostgreSQL)
--  วิธีใช้: Supabase → SQL Editor → New query → วางไฟล์นี้ทั้งไฟล์ → Run
--  รันซ้ำได้ครั้งแรกครั้งเดียว (ถ้าต้องการล้างใหม่ ให้สร้างโปรเจกต์ใหม่)
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1) ผู้ใช้ + บทบาท
--    user      = ผู้ใช้ทั่วไป
--    volunteer = อาสาที่ผ่านการอบรม + แอดมินอนุมัติแล้ว
--    co_admin  = ผู้ช่วยแอดมิน ดูแลเฉพาะ "เคส" (กำหนดจังหวัดได้)
--    admin     = เจ้าของระบบ เห็นข้อมูลสัตว์รายตัวทั้งหมด
-- ---------------------------------------------------------------------
create type public.user_role as enum ('user', 'volunteer', 'co_admin', 'admin');

create table public.profiles (
  id             uuid primary key references auth.users (id) on delete cascade,
  display_name   text,
  phone          text,
  line_id        text,
  province       text,
  amphoe         text,
  tambon         text,
  role           public.user_role not null default 'user',
  staff_province text,               -- co_admin: ดูแลเฉพาะจังหวัดนี้ (ว่าง = ทุกจังหวัด)
  created_at     timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.my_role()
returns public.user_role language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('admin', 'co_admin') from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_volunteer()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('volunteer', 'co_admin', 'admin') from public.profiles where id = auth.uid()), false)
$$;

-- แอดมินดูแลได้ทุกเคส / co_admin ดูแลได้เฉพาะจังหวัดที่ได้รับมอบหมาย
create or replace function public.staff_can_case(p_province text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((
    select p.role = 'admin'
        or (p.role = 'co_admin' and (p.staff_province is null or p.staff_province = p_province))
    from public.profiles p where p.id = auth.uid()
  ), false)
$$;

-- กันผู้ใช้เปลี่ยนบทบาทตัวเอง (รันจาก SQL Editor ได้ เพราะไม่มี auth.uid())
create or replace function public.protect_profile_role()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.role is distinct from old.role or new.staff_province is distinct from old.staff_province then
      raise exception 'เฉพาะแอดมินเท่านั้นที่เปลี่ยนบทบาทได้';
    end if;
  end if;
  return new;
end $$;

create trigger profiles_protect_role
  before update on public.profiles
  for each row execute function public.protect_profile_role();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------------------------------------------------------------------
-- 2) หน่วยงานในพื้นที่ (อบต. / เทศบาล / ปศุสัตว์ / มูลนิธิ) สำหรับส่งต่อเคส
-- ---------------------------------------------------------------------
create table public.agencies (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  kind           text not null default 'sao'
                 check (kind in ('sao', 'municipality', 'livestock', 'foundation', 'hospital', 'other')),
  province       text,
  amphoe         text,
  tambon         text,
  contact_person text,
  phone          text,
  email          text,
  line_id        text,
  notes          text,
  created_at     timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 3) ทะเบียนสัตว์ + วัคซีน
-- ---------------------------------------------------------------------
create table public.animals (
  id                   uuid primary key default gen_random_uuid(),
  owner_id             uuid references auth.users (id) on delete set null default auth.uid(),
  is_demo              boolean not null default false,
  species              text not null check (species in ('dog', 'cat', 'other')),
  status               text not null default 'pet' check (status in ('pet', 'community', 'stray')),
  name                 text,
  sex                  text not null default 'unknown' check (sex in ('male', 'female', 'unknown')),
  breed                text,
  breed_ai             jsonb,             -- ผลวิเคราะห์ AI: {breeds:[{name_th,name_en,percent}], ...}
  color                text,
  markings             text,
  birth_date           date,
  birth_date_estimated boolean not null default false,
  weight_kg            numeric(5, 2),
  microchip            text,
  sterilized           text not null default 'unknown' check (sterilized in ('yes', 'no', 'unknown')),
  sterilized_date      date,
  sterilized_place     text,
  temperament          text not null default 'friendly'
                       check (temperament in ('friendly', 'shy', 'guarding', 'aggressive')),
  bite_history         boolean not null default false,
  health_notes         text,
  photo_urls           text[] not null default '{}',
  province             text,
  amphoe               text,
  tambon               text,
  address_note         text,
  lat                  double precision,
  lng                  double precision,
  caretaker_name       text,
  caretaker_phone      text,
  is_deceased          boolean not null default false,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index animals_owner_idx on public.animals (owner_id);
create index animals_area_idx on public.animals (province, amphoe, tambon);
create trigger animals_touch before update on public.animals
  for each row execute function public.touch_updated_at();

create table public.vaccinations (
  id           uuid primary key default gen_random_uuid(),
  animal_id    uuid not null references public.animals (id) on delete cascade,
  vaccine      text not null check (vaccine in ('rabies', 'dog_core', 'kennel_cough', 'cat_core', 'felv', 'other')),
  vaccine_name text,
  given_on     date not null,
  next_due     date,
  clinic       text,
  created_at   timestamptz not null default now()
);
create index vaccinations_animal_idx on public.vaccinations (animal_id);

-- ---------------------------------------------------------------------
-- 4) เคสขอความช่วยเหลือ
--    คะแนนความเร่งด่วน (สูตร Me Dog) =
--      ความใกล้ชุมชน/โรงเรียน 40% + ความก้าวร้าว 30% + ความเสี่ยงจากไม่ได้ฉีดวัคซีน 30%
-- ---------------------------------------------------------------------
create table public.cases (
  id                  uuid primary key default gen_random_uuid(),
  case_no             bigint generated always as identity,
  reporter_id         uuid references auth.users (id) on delete set null default auth.uid(),
  is_demo             boolean not null default false,
  title               text not null,
  category            text not null default 'other'
                      check (category in ('injured', 'sick', 'aggressive', 'puppies', 'sterilize', 'food', 'abuse', 'other')),
  species             text not null default 'dog' check (species in ('dog', 'cat', 'other')),
  animal_count        int not null default 1 check (animal_count > 0),
  description         text,
  photo_urls          text[] not null default '{}',
  province            text,
  amphoe              text,
  tambon              text,
  location_note       text,
  lat                 double precision,
  lng                 double precision,
  proximity           text not null default 'far' check (proximity in ('very_near', 'near', 'far')),
  aggression          text not null default 'none' check (aggression in ('none', 'low', 'medium', 'high')),
  vaccination_status  text not null default 'unknown' check (vaccination_status in ('vaccinated', 'partial', 'unknown', 'none')),
  urgency_score       int not null default 0,
  status              text not null default 'submitted'
                      check (status in ('submitted', 'reviewing', 'verified', 'forwarded', 'fundraising', 'in_progress', 'resolved', 'rejected')),
  is_urgent           boolean not null default false,   -- แอดมินประเมินแล้วว่าเร่งด่วน
  forwarded_agency_id uuid references public.agencies (id) on delete set null,
  forwarded_at        timestamptz,
  goal_amount         numeric(12, 2),
  fund_purpose        text,
  promptpay_id        text,
  reviewed_by         uuid references auth.users (id) on delete set null,
  reviewed_at         timestamptz,
  public_note         text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index cases_status_idx on public.cases (status);
create index cases_area_idx on public.cases (province, amphoe, tambon);

create or replace function public.compute_urgency()
returns trigger language plpgsql as $$
declare prox int; aggr int; vacc int;
begin
  prox := case new.proximity when 'very_near' then 100 when 'near' then 60 else 20 end;
  aggr := case new.aggression when 'high' then 100 when 'medium' then 67 when 'low' then 33 else 0 end;
  vacc := case new.vaccination_status when 'none' then 100 when 'unknown' then 80 when 'partial' then 50 else 0 end;
  new.urgency_score := round(prox * 0.4 + aggr * 0.3 + vacc * 0.3);
  return new;
end $$;

create trigger cases_urgency before insert or update of proximity, aggression, vaccination_status on public.cases
  for each row execute function public.compute_urgency();
create trigger cases_touch before update on public.cases
  for each row execute function public.touch_updated_at();

-- ข้อมูลติดต่อผู้แจ้ง (แยกตาราง เพื่อไม่ให้เบอร์โทรเป็นสาธารณะ)
create table public.case_contacts (
  case_id       uuid primary key references public.cases (id) on delete cascade,
  reporter_name text,
  phone         text,
  line_id       text
);

create table public.case_updates (
  id         uuid primary key default gen_random_uuid(),
  case_id    uuid not null references public.cases (id) on delete cascade,
  author_id  uuid references auth.users (id) on delete set null default auth.uid(),
  status     text,
  note       text,
  is_public  boolean not null default true,
  created_at timestamptz not null default now()
);
create index case_updates_case_idx on public.case_updates (case_id);

create table public.case_volunteers (
  case_id      uuid not null references public.cases (id) on delete cascade,
  volunteer_id uuid not null references auth.users (id) on delete cascade default auth.uid(),
  note         text,
  created_at   timestamptz not null default now(),
  primary key (case_id, volunteer_id)
);

-- บันทึกไทม์ไลน์อัตโนมัติเมื่อสถานะเคสเปลี่ยน
create or replace function public.log_case_status()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    insert into public.case_updates (case_id, author_id, status, note, is_public)
    values (new.id, auth.uid(), new.status, null, true);
  end if;
  return new;
end $$;

create trigger cases_log_status after update of status on public.cases
  for each row execute function public.log_case_status();

-- ---------------------------------------------------------------------
-- 5) อาสาสมัคร (ต้องผ่านแบบทดสอบ ≥ 8/10 แล้วแอดมินอนุมัติ)
-- ---------------------------------------------------------------------
create table public.volunteer_applications (
  user_id        uuid primary key references auth.users (id) on delete cascade,
  full_name      text,
  phone          text,
  province       text,
  amphoe         text,
  skills         text[] not null default '{}',
  motivation     text,
  availability   text,
  has_transport  boolean not null default false,
  quiz_score     int,
  quiz_passed_at timestamptz,
  status         text not null default 'draft' check (status in ('draft', 'pending', 'approved', 'rejected')),
  review_note    text,
  reviewed_by    uuid references auth.users (id) on delete set null,
  reviewed_at    timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create trigger volunteer_touch before update on public.volunteer_applications
  for each row execute function public.touch_updated_at();

-- ตรวจคำตอบฝั่งเซิร์ฟเวอร์ (เฉลยอยู่ในฐานข้อมูล ผู้ใช้โกงจากหน้าเว็บไม่ได้)
create or replace function public.submit_volunteer_quiz(answers int[])
returns int language plpgsql security definer set search_path = public as $$
declare
  answer_key int[] := array[1, 0, 1, 2, 1, 0, 1, 3, 1, 2];
  score int := 0;
  i int;
begin
  if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบ'; end if;
  if answers is null or array_length(answers, 1) <> array_length(answer_key, 1) then
    raise exception 'กรุณาตอบให้ครบทุกข้อ';
  end if;
  for i in 1 .. array_length(answer_key, 1) loop
    if answers[i] = answer_key[i] then score := score + 1; end if;
  end loop;

  insert into public.volunteer_applications (user_id, quiz_score, quiz_passed_at)
  values (auth.uid(), score, case when score >= 8 then now() end)
  on conflict (user_id) do update
    set quiz_score = excluded.quiz_score,
        quiz_passed_at = coalesce(public.volunteer_applications.quiz_passed_at, excluded.quiz_passed_at);
  return score;
end $$;

create or replace function public.submit_volunteer_application(
  p_full_name text, p_phone text, p_province text, p_amphoe text,
  p_skills text[], p_motivation text, p_availability text, p_has_transport boolean)
returns void language plpgsql security definer set search_path = public as $$
declare app public.volunteer_applications;
begin
  select * into app from public.volunteer_applications where user_id = auth.uid();
  if app.user_id is null or app.quiz_passed_at is null then
    raise exception 'ต้องผ่านแบบทดสอบก่อนสมัคร';
  end if;
  if app.status = 'approved' then raise exception 'คุณเป็นอาสาแล้ว'; end if;
  update public.volunteer_applications
     set full_name = p_full_name, phone = p_phone, province = p_province, amphoe = p_amphoe,
         skills = coalesce(p_skills, '{}'), motivation = p_motivation, availability = p_availability,
         has_transport = coalesce(p_has_transport, false), status = 'pending', review_note = null
   where user_id = auth.uid();
end $$;

-- เมื่อแอดมินอนุมัติ → ปรับบทบาทเป็นอาสาอัตโนมัติ
create or replace function public.on_volunteer_review()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'approved' and old.status is distinct from 'approved' then
    update public.profiles set role = 'volunteer' where id = new.user_id and role = 'user';
  elsif old.status = 'approved' and new.status <> 'approved' then
    update public.profiles set role = 'user' where id = new.user_id and role = 'volunteer';
  end if;
  return new;
end $$;

create trigger volunteer_review after update of status on public.volunteer_applications
  for each row execute function public.on_volunteer_review();

-- ---------------------------------------------------------------------
-- 6) บริจาค (โอนผ่านพร้อมเพย์ + แนบสลิป → แอดมินยืนยัน)
-- ---------------------------------------------------------------------
create table public.donations (
  id           uuid primary key default gen_random_uuid(),
  case_id      uuid references public.cases (id) on delete set null,  -- ว่าง = กองทุนกลาง
  donor_id     uuid references auth.users (id) on delete set null default auth.uid(),
  donor_name   text,
  is_anonymous boolean not null default false,
  amount       numeric(12, 2) not null check (amount > 0),
  slip_path    text,
  message      text,
  status       text not null default 'pending' check (status in ('pending', 'confirmed', 'rejected')),
  confirmed_by uuid references auth.users (id) on delete set null,
  confirmed_at timestamptz,
  is_demo      boolean not null default false,
  created_at   timestamptz not null default now()
);
create index donations_case_idx on public.donations (case_id);

-- ---------------------------------------------------------------------
-- 7) ร้านค้าเพื่อน้อง
-- ---------------------------------------------------------------------
create table public.products (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text,
  price       numeric(10, 2) not null check (price >= 0),
  image_url   text,
  category    text not null default 'food' check (category in ('food', 'medical', 'kit', 'merch')),
  impact_note text,
  stock       int,               -- ว่าง = ไม่จำกัด
  is_active   boolean not null default true,
  sort        int not null default 0,
  is_demo     boolean not null default false,
  created_at  timestamptz not null default now()
);

create table public.orders (
  id           uuid primary key default gen_random_uuid(),
  order_no     bigint generated always as identity,
  buyer_id     uuid references auth.users (id) on delete set null default auth.uid(),
  items        jsonb not null,  -- [{product_id, name, price, qty}]
  total        numeric(12, 2) not null,
  delivery     text not null default 'ship' check (delivery in ('ship', 'donate')),
  ship_name    text,
  ship_phone   text,
  ship_address text,
  slip_path    text,
  status       text not null default 'pending_payment'
               check (status in ('pending_payment', 'paid', 'shipped', 'delivered', 'cancelled')),
  tracking_no  text,
  admin_note   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger orders_touch before update on public.orders
  for each row execute function public.touch_updated_at();

-- สร้างคำสั่งซื้อ: ราคาคิดจากฐานข้อมูลเสมอ (แก้ราคาจากหน้าเว็บไม่ได้)
create or replace function public.create_order(
  p_items jsonb, p_delivery text, p_ship_name text, p_ship_phone text, p_ship_address text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  it jsonb; prod public.products; qty int;
  lines jsonb := '[]'::jsonb; sum_total numeric := 0; new_id uuid;
begin
  if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบ'; end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'ตะกร้าว่าง'; end if;
  if p_delivery = 'ship' and (coalesce(p_ship_address, '') = '' or coalesce(p_ship_name, '') = '') then
    raise exception 'กรุณากรอกชื่อและที่อยู่จัดส่ง';
  end if;

  for it in select * from jsonb_array_elements(p_items) loop
    qty := greatest(1, least(99, (it ->> 'qty')::int));
    select * into prod from public.products where id = (it ->> 'product_id')::uuid and is_active for update;
    if prod.id is null then raise exception 'ไม่พบสินค้า'; end if;
    if prod.stock is not null then
      if prod.stock < qty then raise exception 'สินค้า "%" เหลือไม่พอ', prod.name; end if;
      update public.products set stock = stock - qty where id = prod.id;
    end if;
    lines := lines || jsonb_build_object('product_id', prod.id, 'name', prod.name, 'price', prod.price, 'qty', qty);
    sum_total := sum_total + prod.price * qty;
  end loop;

  insert into public.orders (buyer_id, items, total, delivery, ship_name, ship_phone, ship_address)
  values (auth.uid(), lines, sum_total, coalesce(p_delivery, 'ship'), p_ship_name, p_ship_phone, p_ship_address)
  returning id into new_id;
  return new_id;
end $$;

create or replace function public.attach_order_slip(p_order uuid, p_path text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.orders set slip_path = p_path
   where id = p_order and buyer_id = auth.uid() and status = 'pending_payment';
  if not found then raise exception 'ไม่พบคำสั่งซื้อที่รอชำระ'; end if;
end $$;

create or replace function public.cancel_my_order(p_order uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.orders set status = 'cancelled'
   where id = p_order and buyer_id = auth.uid() and status = 'pending_payment';
  if not found then raise exception 'ยกเลิกไม่ได้'; end if;
end $$;

-- คืนสต็อกเมื่อยกเลิก
create or replace function public.restock_on_cancel()
returns trigger language plpgsql security definer set search_path = public as $$
declare it jsonb;
begin
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    for it in select * from jsonb_array_elements(new.items) loop
      update public.products set stock = stock + (it ->> 'qty')::int
       where id = (it ->> 'product_id')::uuid and stock is not null;
    end loop;
  end if;
  return new;
end $$;

create trigger orders_restock after update of status on public.orders
  for each row execute function public.restock_on_cancel();

-- ---------------------------------------------------------------------
-- 8) ฟังก์ชันสถิติสาธารณะ (คืนเฉพาะตัวเลขรวม ไม่เปิดเผยข้อมูลรายตัว)
-- ---------------------------------------------------------------------
create or replace function public.area_stats(p_level text default 'tambon', p_province text default null)
returns table (
  province text, amphoe text, tambon text,
  lat double precision, lng double precision,
  total int, dogs int, cats int, strays int,
  rabies_ok int, dog_core_ok int, cat_core_ok int,
  sterilized int, aggressive int, open_cases int
)
language sql stable security definer set search_path = public as $$
  with a as (
    select an.*,
      exists (select 1 from public.vaccinations v
               where v.animal_id = an.id and v.vaccine = 'rabies'
                 and coalesce(v.next_due, v.given_on + 365) >= current_date) as is_rabies_ok,
      exists (select 1 from public.vaccinations v
               where v.animal_id = an.id and an.species = 'dog' and v.vaccine = 'dog_core'
                 and coalesce(v.next_due, v.given_on + 365) >= current_date) as is_dog_core_ok,
      exists (select 1 from public.vaccinations v
               where v.animal_id = an.id and an.species = 'cat' and v.vaccine = 'cat_core'
                 and coalesce(v.next_due, v.given_on + 365) >= current_date) as is_cat_core_ok
    from public.animals an
    where not an.is_deceased and an.province is not null
      and (p_province is null or an.province = p_province)
  ),
  g as (
    select
      a.province as g_province,
      case when p_level in ('amphoe', 'tambon') then a.amphoe end as g_amphoe,
      case when p_level = 'tambon' then a.tambon end as g_tambon,
      avg(a.lat) as g_lat, avg(a.lng) as g_lng,
      count(*)::int as g_total,
      count(*) filter (where a.species = 'dog')::int as g_dogs,
      count(*) filter (where a.species = 'cat')::int as g_cats,
      count(*) filter (where a.status <> 'pet')::int as g_strays,
      count(*) filter (where a.is_rabies_ok)::int as g_rabies,
      count(*) filter (where a.is_dog_core_ok)::int as g_dog_core,
      count(*) filter (where a.is_cat_core_ok)::int as g_cat_core,
      count(*) filter (where a.sterilized = 'yes')::int as g_sterilized,
      count(*) filter (where a.temperament = 'aggressive' or a.bite_history)::int as g_aggressive
    from a
    group by 1, 2, 3
  )
  select g.g_province, g.g_amphoe, g.g_tambon, g.g_lat, g.g_lng,
         g.g_total, g.g_dogs, g.g_cats, g.g_strays,
         g.g_rabies, g.g_dog_core, g.g_cat_core, g.g_sterilized, g.g_aggressive,
         (select count(*)::int from public.cases c
           where c.province = g.g_province
             and (g.g_amphoe is null or c.amphoe = g.g_amphoe)
             and (g.g_tambon is null or c.tambon = g.g_tambon)
             and c.status in ('submitted', 'reviewing', 'verified', 'forwarded', 'fundraising', 'in_progress'))
  from g
  order by g.g_province, g.g_amphoe, g.g_tambon
$$;

create or replace function public.public_summary()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'animals', (select count(*) from public.animals where not is_deceased),
    'dogs', (select count(*) from public.animals where not is_deceased and species = 'dog'),
    'cats', (select count(*) from public.animals where not is_deceased and species = 'cat'),
    'rabies_ok', (select count(*) from public.animals an where not an.is_deceased and exists (
        select 1 from public.vaccinations v where v.animal_id = an.id and v.vaccine = 'rabies'
          and coalesce(v.next_due, v.given_on + 365) >= current_date)),
    'sterilized', (select count(*) from public.animals where not is_deceased and sterilized = 'yes'),
    'provinces', (select count(distinct province) from public.animals where province is not null),
    'volunteers', (select count(*) from public.profiles where role in ('volunteer', 'co_admin', 'admin')),
    'cases_public', (select count(*) from public.cases where status in ('verified', 'forwarded', 'fundraising', 'in_progress', 'resolved')),
    'cases_resolved', (select count(*) from public.cases where status = 'resolved'),
    'funds_raised', (select coalesce(sum(amount), 0) from public.donations where status = 'confirmed')
  )
$$;

create or replace function public.case_funding()
returns table (case_id uuid, raised numeric, donors int)
language sql stable security definer set search_path = public as $$
  select d.case_id, sum(d.amount), count(*)::int
  from public.donations d
  where d.status = 'confirmed' and d.case_id is not null
  group by d.case_id
$$;

create or replace function public.case_donors(p_case uuid)
returns table (name text, amount numeric, message text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select case when d.is_anonymous or coalesce(d.donor_name, '') = '' then 'ผู้ใจดีไม่ประสงค์ออกนาม' else d.donor_name end,
         d.amount, d.message, d.created_at
  from public.donations d
  where d.status = 'confirmed' and d.case_id = p_case
  order by d.created_at desc
  limit 50
$$;

create or replace function public.case_volunteer_count(p_case uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.case_volunteers where case_id = p_case
$$;

-- แอดมิน: ค้นหาผู้ใช้ (รวมอีเมล)
create or replace function public.admin_list_users(p_query text default null)
returns table (id uuid, email text, display_name text, phone text, role public.user_role,
               staff_province text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'เฉพาะแอดมิน'; end if;
  return query
    select p.id, u.email::text, p.display_name, p.phone, p.role, p.staff_province, p.created_at
    from public.profiles p join auth.users u on u.id = p.id
    where p_query is null or p_query = ''
       or u.email ilike '%' || p_query || '%' or p.display_name ilike '%' || p_query || '%'
    order by p.created_at desc
    limit 200;
end $$;

-- แอดมิน: ลบข้อมูลตัวอย่างทั้งหมด
create or replace function public.clear_demo_data()
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'เฉพาะแอดมิน'; end if;
  delete from public.donations where is_demo;
  delete from public.cases where is_demo;
  delete from public.animals where is_demo;
  delete from public.products where is_demo;
end $$;

-- ---------------------------------------------------------------------
-- 9) สิทธิ์การเข้าถึง (Row Level Security)
-- ---------------------------------------------------------------------
alter table public.profiles               enable row level security;
alter table public.agencies               enable row level security;
alter table public.animals                enable row level security;
alter table public.vaccinations           enable row level security;
alter table public.cases                  enable row level security;
alter table public.case_contacts          enable row level security;
alter table public.case_updates           enable row level security;
alter table public.case_volunteers        enable row level security;
alter table public.volunteer_applications enable row level security;
alter table public.donations              enable row level security;
alter table public.products               enable row level security;
alter table public.orders                 enable row level security;

-- profiles
create policy "profiles: read own or staff" on public.profiles
  for select using (id = auth.uid() or public.is_staff());
create policy "profiles: insert own" on public.profiles
  for insert with check (id = auth.uid());
create policy "profiles: update own or admin" on public.profiles
  for update using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- agencies: ทุกคนดูได้ / staff แก้ไข
create policy "agencies: public read" on public.agencies for select using (true);
create policy "agencies: staff write" on public.agencies for all
  using (public.is_staff()) with check (public.is_staff());

-- animals: เจ้าของ + แอดมินเท่านั้น
create policy "animals: owner or admin read" on public.animals
  for select using (owner_id = auth.uid() or public.is_admin());
create policy "animals: owner insert" on public.animals
  for insert with check (auth.uid() is not null and owner_id = auth.uid() and not is_demo);
create policy "animals: owner or admin update" on public.animals
  for update using (owner_id = auth.uid() or public.is_admin())
  with check (owner_id = auth.uid() or public.is_admin());
create policy "animals: owner or admin delete" on public.animals
  for delete using (owner_id = auth.uid() or public.is_admin());

-- vaccinations: ตามสิทธิ์ของสัตว์ตัวนั้น
create policy "vaccinations: via animal" on public.vaccinations for all
  using (exists (select 1 from public.animals a where a.id = animal_id and (a.owner_id = auth.uid() or public.is_admin())))
  with check (exists (select 1 from public.animals a where a.id = animal_id and (a.owner_id = auth.uid() or public.is_admin())));

-- cases
create policy "cases: read" on public.cases for select using (
  status in ('verified', 'forwarded', 'fundraising', 'in_progress', 'resolved')
  or reporter_id = auth.uid()
  or public.staff_can_case(province)
  or (public.is_volunteer() and status <> 'rejected')
);
create policy "cases: report" on public.cases for insert with check (
  auth.uid() is not null and reporter_id = auth.uid() and status = 'submitted'
  and not is_urgent and not is_demo and goal_amount is null and forwarded_agency_id is null and reviewed_by is null
);
create policy "cases: update" on public.cases for update
  using (public.staff_can_case(province) or (reporter_id = auth.uid() and status = 'submitted'))
  with check (
    public.staff_can_case(province)
    or (reporter_id = auth.uid() and status = 'submitted' and not is_urgent
        and goal_amount is null and forwarded_agency_id is null and reviewed_by is null)
  );
create policy "cases: admin delete" on public.cases for delete using (public.is_admin());

-- case_contacts
create policy "case_contacts: read" on public.case_contacts for select using (
  exists (select 1 from public.cases c where c.id = case_id
          and (c.reporter_id = auth.uid() or public.staff_can_case(c.province)))
  or exists (select 1 from public.case_volunteers cv where cv.case_id = case_contacts.case_id and cv.volunteer_id = auth.uid())
);
create policy "case_contacts: reporter insert" on public.case_contacts for insert with check (
  exists (select 1 from public.cases c where c.id = case_id and c.reporter_id = auth.uid())
);
create policy "case_contacts: reporter or staff update" on public.case_contacts for update using (
  exists (select 1 from public.cases c where c.id = case_id
          and (c.reporter_id = auth.uid() or public.staff_can_case(c.province)))
);

-- case_updates
create policy "case_updates: read" on public.case_updates for select using (
  (is_public and exists (select 1 from public.cases c where c.id = case_id))
  or exists (select 1 from public.cases c where c.id = case_id and public.staff_can_case(c.province))
);
create policy "case_updates: staff or assigned volunteer insert" on public.case_updates for insert with check (
  author_id = auth.uid() and (
    exists (select 1 from public.cases c where c.id = case_id and public.staff_can_case(c.province))
    or exists (select 1 from public.case_volunteers cv where cv.case_id = case_updates.case_id and cv.volunteer_id = auth.uid())
  )
);
create policy "case_updates: staff delete" on public.case_updates for delete using (
  exists (select 1 from public.cases c where c.id = case_id and public.staff_can_case(c.province))
);

-- case_volunteers
create policy "case_volunteers: read" on public.case_volunteers for select using (
  volunteer_id = auth.uid()
  or exists (select 1 from public.cases c where c.id = case_id and public.staff_can_case(c.province))
);
create policy "case_volunteers: volunteer join" on public.case_volunteers for insert with check (
  volunteer_id = auth.uid() and public.is_volunteer()
  and exists (select 1 from public.cases c where c.id = case_id
              and c.status in ('verified', 'forwarded', 'fundraising', 'in_progress'))
);
create policy "case_volunteers: leave or staff remove" on public.case_volunteers for delete using (
  volunteer_id = auth.uid()
  or exists (select 1 from public.cases c where c.id = case_id and public.staff_can_case(c.province))
);

-- volunteer_applications: ผู้สมัครดูของตัวเอง / แอดมินจัดการ (สมัครผ่านฟังก์ชันเท่านั้น)
create policy "volunteer: read own or admin" on public.volunteer_applications
  for select using (user_id = auth.uid() or public.is_admin());
create policy "volunteer: admin update" on public.volunteer_applications
  for update using (public.is_admin()) with check (public.is_admin());

-- donations
create policy "donations: read own or admin" on public.donations
  for select using (donor_id = auth.uid() or public.is_admin());
create policy "donations: donor insert pending" on public.donations for insert with check (
  auth.uid() is not null and donor_id = auth.uid() and status = 'pending'
  and confirmed_by is null and confirmed_at is null and not is_demo
);
create policy "donations: admin update" on public.donations
  for update using (public.is_admin()) with check (public.is_admin());
create policy "donations: admin delete" on public.donations
  for delete using (public.is_admin());

-- products
create policy "products: public read active" on public.products
  for select using (is_active or public.is_admin());
create policy "products: admin write" on public.products for all
  using (public.is_admin()) with check (public.is_admin());

-- orders (สร้างผ่านฟังก์ชัน create_order เท่านั้น)
create policy "orders: read own or admin" on public.orders
  for select using (buyer_id = auth.uid() or public.is_admin());
create policy "orders: admin update" on public.orders
  for update using (public.is_admin()) with check (public.is_admin());

-- สิทธิ์ระดับตาราง (RLS ด้านบนเป็นตัวคุมจริง)
grant usage on schema public to anon, authenticated;
grant select on all tables in schema public to anon, authenticated;
grant insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant execute on all functions in schema public to anon, authenticated;

-- ---------------------------------------------------------------------
-- 10) ที่เก็บรูปภาพ (Supabase Storage)
--     รูปสัตว์ / รูปเคส / รูปสินค้า = สาธารณะ   สลิปโอนเงิน = ส่วนตัว (เจ้าของ + แอดมิน)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('animal-photos', 'animal-photos', true),
  ('case-photos', 'case-photos', true),
  ('product-images', 'product-images', true),
  ('slips', 'slips', false)
on conflict (id) do nothing;

create policy "storage: upload own folder" on storage.objects for insert to authenticated
  with check (
    bucket_id in ('animal-photos', 'case-photos', 'slips')
    and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "storage: manage own files" on storage.objects for delete to authenticated
  using (
    bucket_id in ('animal-photos', 'case-photos', 'slips')
    and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "storage: read own slips or admin" on storage.objects for select to authenticated
  using (
    bucket_id = 'slips' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );
create policy "storage: admin product images" on storage.objects for all to authenticated
  using (bucket_id = 'product-images' and public.is_admin())
  with check (bucket_id = 'product-images' and public.is_admin());
