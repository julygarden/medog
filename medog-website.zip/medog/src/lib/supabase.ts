import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const key =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

/** true เมื่อใส่ค่า Supabase ใน .env แล้ว */
export const isConfigured = Boolean(url && key);

export const supabase = createClient(url || "https://not-configured.supabase.co", key || "not-configured", {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

export function publicUrl(bucket: string, path: string) {
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

/** แปลงข้อความ error ของ Supabase ให้อ่านง่าย */
export function errorText(err: unknown): string {
  if (!err) return "";
  const msg = typeof err === "string" ? err : (err as { message?: string }).message ?? String(err);
  if (msg.includes("Invalid login credentials")) return "อีเมลหรือรหัสผ่านไม่ถูกต้อง";
  if (msg.includes("Email not confirmed")) return "กรุณายืนยันอีเมลก่อน (ตรวจสอบกล่องจดหมาย)";
  if (msg.includes("User already registered")) return "อีเมลนี้สมัครไว้แล้ว ลองเข้าสู่ระบบ";
  if (msg.includes("row-level security")) return "คุณไม่มีสิทธิ์ทำรายการนี้";
  if (msg.includes("Failed to fetch")) return "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง";
  if (msg.includes("Password should be")) return "รหัสผ่านต้องยาวอย่างน้อย 6 ตัวอักษร";
  return msg;
}
