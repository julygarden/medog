/**
 * สร้างข้อความ QR พร้อมเพย์ (มาตรฐาน EMVCo / Thai QR Payment)
 * รองรับ: เบอร์มือถือ 10 หลัก, เลขบัตรประชาชน/เลขผู้เสียภาษี 13 หลัก, e-Wallet 15 หลัก
 */
function tlv(id: string, value: string) {
  return id + String(value.length).padStart(2, "0") + value;
}

function crc16(data: string) {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1;
      crc &= 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

export function promptPayPayload(target: string, amount?: number) {
  const id = target.replace(/\D/g, "");
  let account: string;
  if (id.length >= 15) account = tlv("03", id);
  else if (id.length >= 13) account = tlv("02", id);
  else account = tlv("01", ("0000000000000" + id.replace(/^0/, "66")).slice(-13));

  const merchant = tlv("00", "A000000677010111") + account;
  let payload =
    tlv("00", "01") +
    tlv("01", amount ? "12" : "11") +
    tlv("29", merchant) +
    tlv("58", "TH") +
    tlv("53", "764");
  if (amount && amount > 0) payload += tlv("54", amount.toFixed(2));
  payload += "6304";
  return payload + crc16(payload);
}

export function isValidPromptPay(target: string) {
  const id = target.replace(/\D/g, "");
  return id.length === 10 || id.length === 13 || id.length === 15;
}
