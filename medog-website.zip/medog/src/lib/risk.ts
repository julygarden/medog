import type { AreaStat } from "./types";

export type Disease = "overall" | "rabies" | "dog_core" | "cat_core" | "sterilize";

export const DISEASES: { key: Disease; label: string; desc: string }[] = [
  {
    key: "overall",
    label: "ภาพรวม",
    desc: "ดัชนีรวม = พิษสุนัขบ้า 40% + วัคซีนรวม 30% + ยังไม่ทำหมัน 30%",
  },
  {
    key: "rabies",
    label: "พิษสุนัขบ้า",
    desc: "สัดส่วนสุนัขและแมวที่ยังไม่ได้รับวัคซีนพิษสุนัขบ้าในรอบ 1 ปี (เป้าหมายครอบคลุม ≥ 70%)",
  },
  {
    key: "dog_core",
    label: "ไข้หัด/ลำไส้อักเสบ (สุนัข)",
    desc: "สัดส่วนสุนัขที่ยังไม่ได้รับวัคซีนรวม (DHPPi-L) ในรอบ 1 ปี",
  },
  {
    key: "cat_core",
    label: "ไข้หัดแมว/หวัดแมว",
    desc: "สัดส่วนแมวที่ยังไม่ได้รับวัคซีนรวมแมว (FVRCP) ในรอบ 1 ปี",
  },
  {
    key: "sterilize",
    label: "ประชากรล้น (ไม่ทำหมัน)",
    desc: "สัดส่วนสัตว์ที่ยังไม่ได้ทำหมัน — ยิ่งสูง ยิ่งเสี่ยงสัตว์จรเพิ่ม",
  },
];

export const MIN_SAMPLE = 3;
/** เป้าหมายความครอบคลุมวัคซีนพิษสุนัขบ้าที่ใช้ควบคุมโรคในชุมชน */
export const COVERAGE_TARGET = 0.7;

export type RiskLevel = "safe" | "watch" | "high" | "nodata";

export const LEVEL_META: Record<RiskLevel, { label: string; color: string; soft: string; text: string }> = {
  safe: { label: "ปลอดภัย", color: "#16A34A", soft: "#DCFCE7", text: "#166534" },
  watch: { label: "เฝ้าระวัง", color: "#EAB308", soft: "#FEF9C3", text: "#854D0E" },
  high: { label: "เสี่ยงสูง", color: "#DC2626", soft: "#FEE2E2", text: "#991B1B" },
  nodata: { label: "ข้อมูลไม่พอ", color: "#9CA3AF", soft: "#F3F4F6", text: "#4B5563" },
};

const pctRisk = (ok: number, n: number) => (n > 0 ? 100 - (ok / n) * 100 : null);

export function riskOf(s: AreaStat, d: Disease): { risk: number | null; n: number } {
  switch (d) {
    case "rabies":
      return { risk: pctRisk(s.rabies_ok, s.total), n: s.total };
    case "dog_core":
      return { risk: pctRisk(s.dog_core_ok, s.dogs), n: s.dogs };
    case "cat_core":
      return { risk: pctRisk(s.cat_core_ok, s.cats), n: s.cats };
    case "sterilize":
      return { risk: pctRisk(s.sterilized, s.total), n: s.total };
    case "overall": {
      const rab = pctRisk(s.rabies_ok, s.total);
      const core = pctRisk(s.dog_core_ok + s.cat_core_ok, s.dogs + s.cats);
      const ster = pctRisk(s.sterilized, s.total);
      if (rab === null) return { risk: null, n: 0 };
      return { risk: rab * 0.4 + (core ?? rab) * 0.3 + (ster ?? 0) * 0.3, n: s.total };
    }
  }
}

export function levelOf(risk: number | null, n: number): RiskLevel {
  if (risk === null || n < MIN_SAMPLE) return "nodata";
  if (risk <= 30) return "safe";
  if (risk <= 60) return "watch";
  return "high";
}

/** จำนวนตัวที่ต้องฉีดเพิ่มเพื่อให้ถึงเป้าหมาย */
export function neededForTarget(n: number, ok: number, target = COVERAGE_TARGET) {
  return Math.max(0, Math.ceil(n * target - ok));
}

export function areaName(s: Pick<AreaStat, "province" | "amphoe" | "tambon">) {
  if (s.tambon) return `ต.${s.tambon} อ.${s.amphoe} จ.${s.province}`;
  if (s.amphoe) return `อ.${s.amphoe} จ.${s.province}`;
  return `จ.${s.province}`;
}

export function pct(n: number, d: number) {
  return d > 0 ? Math.round((n / d) * 100) : 0;
}
