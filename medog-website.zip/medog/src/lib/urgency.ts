import type { Case } from "./types";

/** สูตรคะแนนความเร่งด่วน Me Dog (ตรงกับฟังก์ชันในฐานข้อมูล) */
export const URGENCY_WEIGHTS = { proximity: 0.4, aggression: 0.3, vaccination: 0.3 };

const PROX = { very_near: 100, near: 60, far: 20 } as const;
const AGGR = { high: 100, medium: 67, low: 33, none: 0 } as const;
const VACC = { none: 100, unknown: 80, partial: 50, vaccinated: 0 } as const;

export function urgencyBreakdown(c: Pick<Case, "proximity" | "aggression" | "vaccination_status">) {
  const p = PROX[c.proximity];
  const a = AGGR[c.aggression];
  const v = VACC[c.vaccination_status];
  return {
    proximity: p,
    aggression: a,
    vaccination: v,
    score: Math.round(p * URGENCY_WEIGHTS.proximity + a * URGENCY_WEIGHTS.aggression + v * URGENCY_WEIGHTS.vaccination),
  };
}
