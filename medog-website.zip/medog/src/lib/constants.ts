import type { CaseStatus, Role, Species, VaccineKey } from "./types";

export const SITE = {
  name: "Me Dog",
  tagline: "ทะเบียนและแผนที่สุขภาพสัตว์ชุมชน",
  description:
    "ลงทะเบียนสัตว์เลี้ยงและสัตว์จร ติดตามวัคซีนและการทำหมัน ดูแผนที่ความเสี่ยงโรคทั่วไทย แจ้งเคสขอความช่วยเหลือ และร่วมบริจาคอย่างโปร่งใส",
};

export const SPECIES: Record<Species, string> = { dog: "สุนัข", cat: "แมว", other: "อื่นๆ" };

export const ANIMAL_STATUS = {
  pet: "สัตว์เลี้ยง (มีเจ้าของ)",
  community: "สัตว์ชุมชน (มีคนดูแล)",
  stray: "สัตว์จร (ไม่มีเจ้าของ)",
} as const;

export const SEX = { male: "เพศผู้", female: "เพศเมีย", unknown: "ไม่ทราบ" } as const;

export const STERILIZED = { yes: "ทำหมันแล้ว", no: "ยังไม่ทำหมัน", unknown: "ไม่ทราบ" } as const;

export const TEMPERAMENT = {
  friendly: "เป็นมิตร เข้าหาคน",
  shy: "ขี้กลัว หลบหนี",
  guarding: "หวงถิ่น เห่าไล่",
  aggressive: "ดุ / เคยทำร้าย",
} as const;

export const VACCINES: Record<VaccineKey, { label: string; short: string; species: Species[] }> = {
  rabies: { label: "พิษสุนัขบ้า (Rabies)", short: "พิษสุนัขบ้า", species: ["dog", "cat", "other"] },
  dog_core: {
    label: "วัคซีนรวมสุนัข (DHPPi-L) — ไข้หัด ลำไส้อักเสบ ตับอักเสบ ฉี่หนู",
    short: "วัคซีนรวมสุนัข",
    species: ["dog"],
  },
  kennel_cough: { label: "หวัดสุนัข / คอติดเชื้อ (Kennel cough)", short: "หวัดสุนัข", species: ["dog"] },
  cat_core: { label: "วัคซีนรวมแมว (FVRCP) — ไข้หัดแมว หวัดแมว", short: "วัคซีนรวมแมว", species: ["cat"] },
  felv: { label: "ลิวคีเมียแมว (FeLV)", short: "ลิวคีเมียแมว", species: ["cat"] },
  other: { label: "อื่นๆ (ระบุชื่อ)", short: "อื่นๆ", species: ["dog", "cat", "other"] },
};

export const CASE_CATEGORY = {
  injured: "บาดเจ็บ",
  sick: "ป่วย",
  aggressive: "ดุ / ทำร้ายคน",
  puppies: "แม่และลูกอ่อน",
  sterilize: "ต้องการทำหมัน",
  food: "ขาดอาหาร",
  abuse: "ถูกทารุณ",
  other: "อื่นๆ",
} as const;

export const CASE_STATUS: Record<CaseStatus, { label: string; tone: Tone }> = {
  submitted: { label: "รอตรวจสอบ", tone: "gray" },
  reviewing: { label: "กำลังตรวจสอบ", tone: "blue" },
  verified: { label: "ยืนยันแล้ว", tone: "blue" },
  forwarded: { label: "ส่งต่อหน่วยงานแล้ว", tone: "violet" },
  fundraising: { label: "เปิดรับบริจาค", tone: "brand" },
  in_progress: { label: "กำลังช่วยเหลือ", tone: "amber" },
  resolved: { label: "ช่วยเหลือสำเร็จ", tone: "green" },
  rejected: { label: "ไม่ผ่านการตรวจสอบ", tone: "red" },
};

export const PUBLIC_CASE_STATUSES: CaseStatus[] = ["verified", "forwarded", "fundraising", "in_progress", "resolved"];

export const PROXIMITY = {
  very_near: "ติดโรงเรียน / ตลาด / ชุมชน (ไม่เกิน 100 ม.)",
  near: "ใกล้ชุมชน (100–500 ม.)",
  far: "ห่างชุมชน (เกิน 500 ม.)",
} as const;

export const AGGRESSION = {
  none: "ไม่ดุ",
  low: "เห่าแต่ไม่เข้าหา",
  medium: "เห่าไล่ / ขู่",
  high: "เคยกัด / ทำร้ายคน",
} as const;

export const VAX_STATUS = {
  vaccinated: "ฉีดวัคซีนครบแล้ว",
  partial: "ฉีดบางตัว / ไม่ครบ",
  unknown: "ไม่ทราบ",
  none: "ยังไม่ได้ฉีด",
} as const;

export const AGENCY_KIND = {
  sao: "อบต.",
  municipality: "เทศบาล",
  livestock: "ปศุสัตว์",
  foundation: "มูลนิธิ / ศูนย์พักพิง",
  hospital: "โรงพยาบาลสัตว์ / คลินิก",
  other: "อื่นๆ",
} as const;

export const ROLE: Record<Role, string> = {
  user: "ผู้ใช้ทั่วไป",
  volunteer: "อาสาสมัคร",
  co_admin: "ผู้ช่วยแอดมิน (เคส)",
  admin: "แอดมิน",
};

export const DONATION_STATUS = {
  pending: { label: "รอตรวจสลิป", tone: "amber" as Tone },
  confirmed: { label: "ยืนยันแล้ว", tone: "green" as Tone },
  rejected: { label: "ไม่ผ่าน", tone: "red" as Tone },
};

export const ORDER_STATUS = {
  pending_payment: { label: "รอชำระเงิน", tone: "amber" as Tone },
  paid: { label: "ชำระแล้ว", tone: "blue" as Tone },
  shipped: { label: "จัดส่งแล้ว", tone: "violet" as Tone },
  delivered: { label: "ส่งถึงแล้ว", tone: "green" as Tone },
  cancelled: { label: "ยกเลิก", tone: "gray" as Tone },
};

export const PRODUCT_CATEGORY = {
  food: "อาหาร",
  medical: "เวชภัณฑ์",
  kit: "สนับสนุนการรักษา",
  merch: "ของที่ระลึก",
} as const;

export const VOLUNTEER_SKILLS = {
  first_aid: "ปฐมพยาบาลสัตว์",
  transport: "รับ-ส่งสัตว์ไปคลินิก",
  feeding: "ให้อาหารสัตว์ชุมชน",
  catching: "จับ/ต้อนสัตว์อย่างปลอดภัย",
  foster: "รับเลี้ยงชั่วคราว",
  photo: "ถ่ายภาพ/ทำคอนเทนต์",
  survey: "สำรวจข้อมูลในพื้นที่",
  coordination: "ประสานงานหน่วยงาน",
} as const;

export type Tone = "gray" | "blue" | "violet" | "brand" | "amber" | "green" | "red";

// ---------------- สายพันธุ์ ----------------
export interface BreedOption {
  th: string;
  en: string;
}

export const DOG_BREEDS: BreedOption[] = [
  { th: "พันธุ์ไทย/พันธุ์ผสม", en: "Thai native / Mixed breed" },
  { th: "ไทยหลังอาน", en: "Thai Ridgeback" },
  { th: "บางแก้ว", en: "Thai Bangkaew" },
  { th: "ชิวาวา", en: "Chihuahua" },
  { th: "ปอมเมอเรเนียน", en: "Pomeranian" },
  { th: "ชิห์สุ", en: "Shih Tzu" },
  { th: "พุดเดิ้ล", en: "Poodle" },
  { th: "มอลทีส", en: "Maltese" },
  { th: "ยอร์คเชียร์ เทอร์เรีย", en: "Yorkshire Terrier" },
  { th: "ปั๊ก", en: "Pug" },
  { th: "เฟรนช์ บูลด็อก", en: "French Bulldog" },
  { th: "อิงลิช บูลด็อก", en: "English Bulldog" },
  { th: "บีเกิ้ล", en: "Beagle" },
  { th: "ดัชชุนด์", en: "Dachshund" },
  { th: "คอร์กี้", en: "Welsh Corgi" },
  { th: "ชิบะ อินุ", en: "Shiba Inu" },
  { th: "อากิตะ", en: "Akita" },
  { th: "ไซบีเรียน ฮัสกี้", en: "Siberian Husky" },
  { th: "อลาสกัน มาลามิวท์", en: "Alaskan Malamute" },
  { th: "ซามอยด์", en: "Samoyed" },
  { th: "โกลเด้น รีทรีฟเวอร์", en: "Golden Retriever" },
  { th: "ลาบราดอร์ รีทรีฟเวอร์", en: "Labrador Retriever" },
  { th: "เยอรมัน เชพเพิร์ด", en: "German Shepherd" },
  { th: "เบลเยียม มาลินอยส์", en: "Belgian Malinois" },
  { th: "บอร์เดอร์ คอลลี่", en: "Border Collie" },
  { th: "เชทแลนด์ ชีพด็อก", en: "Shetland Sheepdog" },
  { th: "ร็อตไวเลอร์", en: "Rottweiler" },
  { th: "ดอเบอร์แมน", en: "Dobermann" },
  { th: "พิทบูล", en: "American Pit Bull Terrier" },
  { th: "อเมริกัน บูลลี่", en: "American Bully" },
  { th: "ดัลเมเชียน", en: "Dalmatian" },
  { th: "เชาเชา", en: "Chow Chow" },
  { th: "ชาร์เป่ย์", en: "Shar Pei" },
  { th: "ปักกิ่ง", en: "Pekingese" },
  { th: "ลาซา แอปโซ", en: "Lhasa Apso" },
  { th: "ชเนาเซอร์", en: "Schnauzer" },
  { th: "มินิเจอร์ พินเชอร์", en: "Miniature Pinscher" },
  { th: "แจ็ค รัสเซลล์ เทอร์เรีย", en: "Jack Russell Terrier" },
  { th: "คาวาเลียร์ คิง ชาร์ลส์ สแปเนียล", en: "Cavalier King Charles Spaniel" },
  { th: "ค็อกเกอร์ สแปเนียล", en: "Cocker Spaniel" },
  { th: "บาเซนจิ", en: "Basenji" },
  { th: "เกรท เดน", en: "Great Dane" },
  { th: "เซนต์เบอร์นาร์ด", en: "Saint Bernard" },
  { th: "เกรย์ฮาวด์", en: "Greyhound" },
];

export const CAT_BREEDS: BreedOption[] = [
  { th: "แมวไทยพื้นบ้าน/พันธุ์ผสม", en: "Domestic / Mixed breed" },
  { th: "วิเชียรมาศ", en: "Siamese (Wichien Maat)" },
  { th: "ขาวมณี", en: "Khao Manee" },
  { th: "โคราช (สีสวาด)", en: "Korat" },
  { th: "ศุภลักษณ์", en: "Suphalak" },
  { th: "เปอร์เซีย", en: "Persian" },
  { th: "เอ็กโซติก ชอร์ตแฮร์", en: "Exotic Shorthair" },
  { th: "สก็อตติช โฟลด์", en: "Scottish Fold" },
  { th: "บริติช ชอร์ตแฮร์", en: "British Shorthair" },
  { th: "อเมริกัน ชอร์ตแฮร์", en: "American Shorthair" },
  { th: "เมนคูน", en: "Maine Coon" },
  { th: "แร็กดอลล์", en: "Ragdoll" },
  { th: "เบงกอล", en: "Bengal" },
  { th: "สฟิงซ์", en: "Sphynx" },
  { th: "มันช์กิ้น", en: "Munchkin" },
  { th: "รัสเซียน บลู", en: "Russian Blue" },
  { th: "นอร์วีเจียน ฟอเรสต์", en: "Norwegian Forest Cat" },
  { th: "ไซบีเรียน", en: "Siberian" },
  { th: "อะบิสซิเนียน", en: "Abyssinian" },
  { th: "เบอร์มีส", en: "Burmese" },
  { th: "ฮิมาลายัน", en: "Himalayan" },
  { th: "เดวอน เร็กซ์", en: "Devon Rex" },
];

export function breedsFor(species: Species): BreedOption[] {
  if (species === "dog") return DOG_BREEDS;
  if (species === "cat") return CAT_BREEDS;
  return [];
}

export const PROMPTPAY_ID = process.env.NEXT_PUBLIC_PROMPTPAY_ID ?? "";
export const PROMPTPAY_NAME = process.env.NEXT_PUBLIC_PROMPTPAY_NAME ?? "";
