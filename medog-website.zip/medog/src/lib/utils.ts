// ---------------- วันที่ / อายุ ----------------
export function toISODate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseISODate(s: string | null | undefined): Date | null {
  if (!s) return null;
  const [y, m, d] = s.slice(0, 10).split("-").map(Number);
  if (!y || !m) return null;
  return new Date(y, m - 1, d || 1);
}

export function ageParts(birth: Date, now = new Date()) {
  let months = (now.getFullYear() - birth.getFullYear()) * 12 + (now.getMonth() - birth.getMonth());
  if (now.getDate() < birth.getDate()) months -= 1;
  months = Math.max(0, months);
  return { years: Math.floor(months / 12), months: months % 12 };
}

export function birthFromAge(years: number, months: number, now = new Date()) {
  const total = Math.max(0, Math.round(years * 12 + months));
  return new Date(now.getFullYear(), now.getMonth() - total, 1);
}

export function formatAge(birthISO: string | null | undefined, estimated = false) {
  const b = parseISODate(birthISO);
  if (!b) return "ไม่ระบุ";
  const { years, months } = ageParts(b);
  const parts = [];
  if (years) parts.push(`${years} ปี`);
  if (months || !years) parts.push(`${months} เดือน`);
  return (estimated ? "ประมาณ " : "") + parts.join(" ");
}

export function formatDate(iso: string | null | undefined, opts: Intl.DateTimeFormatOptions = {}) {
  if (!iso) return "-";
  const d = iso.length <= 10 ? parseISODate(iso) : new Date(iso);
  if (!d || isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "2-digit", ...opts });
}

export function formatDateTime(iso: string | null | undefined) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleString("th-TH", { day: "numeric", month: "short", year: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export function addDays(iso: string, days: number) {
  const d = parseISODate(iso);
  if (!d) return "";
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

// ---------------- ตัวเลข / เงิน ----------------
export function baht(n: number | null | undefined) {
  return "฿" + Number(n ?? 0).toLocaleString("th-TH", { maximumFractionDigits: 2 });
}

export function num(n: number | null | undefined) {
  return Number(n ?? 0).toLocaleString("th-TH");
}

export function caseCode(n: number) {
  return "MD-" + String(n).padStart(5, "0");
}

export function orderCode(n: number) {
  return "OR-" + String(n).padStart(5, "0");
}

export function cls(...xs: (string | false | null | undefined)[]) {
  return xs.filter(Boolean).join(" ");
}

// ---------------- รูปภาพ ----------------
/** ย่อรูปก่อนอัปโหลด เพื่อประหยัดพื้นที่และโหลดเร็ว */
export async function resizeImage(file: File | Blob, maxSize = 1280, quality = 0.85): Promise<Blob> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("อ่านไฟล์รูปไม่ได้"));
      el.src = url;
    });
    const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
    return await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("แปลงรูปไม่สำเร็จ"))), "image/jpeg", quality),
    );
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export function randomId() {
  return Math.random().toString(36).slice(2, 10);
}

export function downloadText(filename: string, text: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob(["﻿" + text], { type: mime });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
