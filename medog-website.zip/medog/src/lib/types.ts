export type Role = "user" | "volunteer" | "co_admin" | "admin";
export type Species = "dog" | "cat" | "other";

export interface Profile {
  id: string;
  display_name: string | null;
  phone: string | null;
  line_id: string | null;
  province: string | null;
  amphoe: string | null;
  tambon: string | null;
  role: Role;
  staff_province: string | null;
  created_at: string;
}

export interface BreedGuess {
  name_th: string;
  name_en?: string;
  percent: number;
}

export interface BreedAI {
  species?: Species | "none";
  breeds: BreedGuess[];
  is_mixed?: boolean;
  confidence?: "high" | "medium" | "low";
  note_th?: string;
  analyzed_at?: string;
}

export interface Animal {
  id: string;
  owner_id: string | null;
  is_demo: boolean;
  species: Species;
  status: "pet" | "community" | "stray";
  name: string | null;
  sex: "male" | "female" | "unknown";
  breed: string | null;
  breed_ai: BreedAI | null;
  color: string | null;
  markings: string | null;
  birth_date: string | null;
  birth_date_estimated: boolean;
  weight_kg: number | null;
  microchip: string | null;
  sterilized: "yes" | "no" | "unknown";
  sterilized_date: string | null;
  sterilized_place: string | null;
  temperament: "friendly" | "shy" | "guarding" | "aggressive";
  bite_history: boolean;
  health_notes: string | null;
  photo_urls: string[];
  province: string | null;
  amphoe: string | null;
  tambon: string | null;
  address_note: string | null;
  lat: number | null;
  lng: number | null;
  caretaker_name: string | null;
  caretaker_phone: string | null;
  is_deceased: boolean;
  created_at: string;
  updated_at: string;
  vaccinations?: Vaccination[];
}

export type VaccineKey = "rabies" | "dog_core" | "kennel_cough" | "cat_core" | "felv" | "other";

export interface Vaccination {
  id?: string;
  animal_id?: string;
  vaccine: VaccineKey;
  vaccine_name: string | null;
  given_on: string;
  next_due: string | null;
  clinic: string | null;
}

export type CaseStatus =
  | "submitted"
  | "reviewing"
  | "verified"
  | "forwarded"
  | "fundraising"
  | "in_progress"
  | "resolved"
  | "rejected";

export interface Case {
  id: string;
  case_no: number;
  reporter_id: string | null;
  is_demo: boolean;
  title: string;
  category: "injured" | "sick" | "aggressive" | "puppies" | "sterilize" | "food" | "abuse" | "other";
  species: Species;
  animal_count: number;
  description: string | null;
  photo_urls: string[];
  province: string | null;
  amphoe: string | null;
  tambon: string | null;
  location_note: string | null;
  lat: number | null;
  lng: number | null;
  proximity: "very_near" | "near" | "far";
  aggression: "none" | "low" | "medium" | "high";
  vaccination_status: "vaccinated" | "partial" | "unknown" | "none";
  urgency_score: number;
  status: CaseStatus;
  is_urgent: boolean;
  forwarded_agency_id: string | null;
  forwarded_at: string | null;
  goal_amount: number | null;
  fund_purpose: string | null;
  promptpay_id: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  public_note: string | null;
  created_at: string;
  updated_at: string;
}

export interface CaseContact {
  case_id: string;
  reporter_name: string | null;
  phone: string | null;
  line_id: string | null;
}

export interface CaseUpdate {
  id: string;
  case_id: string;
  author_id: string | null;
  status: CaseStatus | null;
  note: string | null;
  is_public: boolean;
  created_at: string;
}

export interface Agency {
  id: string;
  name: string;
  kind: "sao" | "municipality" | "livestock" | "foundation" | "hospital" | "other";
  province: string | null;
  amphoe: string | null;
  tambon: string | null;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  line_id: string | null;
  notes: string | null;
}

export interface VolunteerApplication {
  user_id: string;
  full_name: string | null;
  phone: string | null;
  province: string | null;
  amphoe: string | null;
  skills: string[];
  motivation: string | null;
  availability: string | null;
  has_transport: boolean;
  quiz_score: number | null;
  quiz_passed_at: string | null;
  status: "draft" | "pending" | "approved" | "rejected";
  review_note: string | null;
  created_at: string;
  updated_at: string;
}

export interface Donation {
  id: string;
  case_id: string | null;
  donor_id: string | null;
  donor_name: string | null;
  is_anonymous: boolean;
  amount: number;
  slip_path: string | null;
  message: string | null;
  status: "pending" | "confirmed" | "rejected";
  confirmed_at: string | null;
  is_demo: boolean;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  category: "food" | "medical" | "kit" | "merch";
  impact_note: string | null;
  stock: number | null;
  is_active: boolean;
  sort: number;
  is_demo: boolean;
}

export interface OrderItem {
  product_id: string;
  name: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  order_no: number;
  buyer_id: string | null;
  items: OrderItem[];
  total: number;
  delivery: "ship" | "donate";
  ship_name: string | null;
  ship_phone: string | null;
  ship_address: string | null;
  slip_path: string | null;
  status: "pending_payment" | "paid" | "shipped" | "delivered" | "cancelled";
  tracking_no: string | null;
  admin_note: string | null;
  created_at: string;
}

export interface AreaStat {
  province: string;
  amphoe: string | null;
  tambon: string | null;
  lat: number | null;
  lng: number | null;
  total: number;
  dogs: number;
  cats: number;
  strays: number;
  rabies_ok: number;
  dog_core_ok: number;
  cat_core_ok: number;
  sterilized: number;
  aggressive: number;
  open_cases: number;
}

export interface PublicSummary {
  animals: number;
  dogs: number;
  cats: number;
  rabies_ok: number;
  sterilized: number;
  provinces: number;
  volunteers: number;
  cases_public: number;
  cases_resolved: number;
  funds_raised: number;
}
