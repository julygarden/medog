"use client";

import { BadgeCheck, HandHeart, Receipt, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { CaseCard } from "@/components/cases/CaseCard";
import { DonateForm } from "@/components/payment/DonateForm";
import { Card, Container, Empty, PageHeader, Spinner } from "@/components/ui";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Case, PublicSummary } from "@/lib/types";
import { baht } from "@/lib/utils";

export default function DonatePage() {
  const [cases, setCases] = useState<Case[]>([]);
  const [funding, setFunding] = useState<Record<string, number>>({});
  const [summary, setSummary] = useState<PublicSummary | null>(null);
  const [loading, setLoading] = useState(isConfigured);

  useEffect(() => {
    if (!isConfigured) return;
    Promise.all([
      supabase.from("cases").select("*").eq("status", "fundraising").order("is_urgent", { ascending: false }).order("urgency_score", { ascending: false }),
      supabase.rpc("case_funding"),
      supabase.rpc("public_summary"),
    ]).then(([c, f, s]) => {
      setCases((c.data as Case[]) ?? []);
      const map: Record<string, number> = {};
      ((f.data as { case_id: string; raised: number }[]) ?? []).forEach((x) => (map[x.case_id] = Number(x.raised)));
      setFunding(map);
      setSummary(s.data as PublicSummary);
      setLoading(false);
    });
  }, []);

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="บริจาค"
        title="ช่วยน้องได้ตรงเคส โปร่งใสทุกบาท"
        desc="เปิดรับบริจาคเฉพาะเคสที่แอดมินตรวจสอบแล้วว่าเร่งด่วนจริง ทุกยอดตรวจสลิปก่อนนับรวม และอัปเดตความคืบหน้าให้ดูได้"
      />

      <div className="mb-10 grid gap-3 sm:grid-cols-3">
        {[
          { icon: <ShieldCheck className="size-5" />, t: "ตรวจเคสก่อนเปิดรับ", d: "แอดมิน/ผู้ช่วยแอดมินลงตรวจข้อมูลและประเมินความเร่งด่วน" },
          { icon: <Receipt className="size-5" />, t: "ตรวจสลิปทุกยอด", d: "ยอดที่แสดงคือยอดที่ยืนยันสลิปแล้วเท่านั้น" },
          { icon: <BadgeCheck className="size-5" />, t: "รายงานผลให้เห็น", d: "ทุกเคสมีไทม์ไลน์ความคืบหน้าจากอาสาและทีมงาน" },
        ].map((x) => (
          <Card key={x.t} className="flex gap-3 p-4">
            <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-dark">{x.icon}</div>
            <div>
              <p className="font-semibold">{x.t}</p>
              <p className="text-sm text-muted">{x.d}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        <div>
          <h2 className="mb-4 text-xl font-bold">เคสที่เปิดรับบริจาค</h2>
          {loading ? (
            <Spinner />
          ) : cases.length === 0 ? (
            <Empty icon={<HandHeart className="size-6" />} title="ตอนนี้ยังไม่มีเคสเปิดรับบริจาค" desc="คุณยังร่วมสมทบกองทุนกลางได้ เพื่อใช้กับเคสเร่งด่วนครั้งถัดไป" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {cases.map((c) => (
                <CaseCard key={c.id} c={c} raised={funding[c.id]} />
              ))}
            </div>
          )}
        </div>

        <div>
          <Card className="sticky top-20 p-5">
            <p className="flex items-center gap-2 text-lg font-semibold">
              <HandHeart className="size-5 text-brand" /> กองทุนกลาง Me Dog
            </p>
            <p className="mt-1 text-sm text-muted">ใช้สำหรับวัคซีน ทำหมัน และเคสฉุกเฉินที่ยังไม่มีผู้สนับสนุน</p>
            {summary && (
              <p className="mt-3 rounded-xl bg-sand px-3 py-2 text-sm">
                ยอดบริจาคที่ยืนยันแล้วทั้งหมด <b>{baht(summary.funds_raised)}</b>
              </p>
            )}
            <div className="mt-5 border-t border-line pt-5">
              <DonateForm caseId={null} />
            </div>
          </Card>
        </div>
      </div>
    </Container>
  );
}
