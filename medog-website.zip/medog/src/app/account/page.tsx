"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { HandHeart, KeyRound, Package, UserRound } from "lucide-react";
import { AddressSelect } from "@/components/AddressSelect";
import { useAuth } from "@/components/AuthProvider";
import { PromptPayBox } from "@/components/payment/PromptPayBox";
import { SlipInput, uploadSlip } from "@/components/payment/SlipInput";
import { RequireAuth } from "@/components/RequireAuth";
import { Alert, Badge, Button, Container, Field, Input, Modal, PageHeader, Section } from "@/components/ui";
import { DONATION_STATUS, ORDER_STATUS, ROLE } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Donation, Order } from "@/lib/types";
import { baht, formatDate, orderCode } from "@/lib/utils";

export default function AccountPage() {
  return (
    <RequireAuth>
      <Account />
    </RequireAuth>
  );
}

function Account() {
  const { user, profile, refreshProfile } = useAuth();
  const [f, setF] = useState({ display_name: "", phone: "", line_id: "", province: null as string | null, amphoe: null as string | null, tambon: null as string | null });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ tone: "green" | "red"; text: string } | null>(null);
  const [pw, setPw] = useState("");
  const [pwMsg, setPwMsg] = useState<{ tone: "green" | "red"; text: string } | null>(null);
  const [donations, setDonations] = useState<(Donation & { cases: { title: string } | null })[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payOrder, setPayOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (profile)
      setF({
        display_name: profile.display_name ?? "",
        phone: profile.phone ?? "",
        line_id: profile.line_id ?? "",
        province: profile.province,
        amphoe: profile.amphoe,
        tambon: profile.tambon,
      });
  }, [profile]);

  const loadActivity = useCallback(async () => {
    if (!isConfigured || !user) return;
    const [d, o] = await Promise.all([
      supabase.from("donations").select("*, cases(title)").eq("donor_id", user.id).order("created_at", { ascending: false }),
      supabase.from("orders").select("*").eq("buyer_id", user.id).order("created_at", { ascending: false }),
    ]);
    setDonations((d.data as typeof donations) ?? []);
    setOrders((o.data as Order[]) ?? []);
  }, [user]);

  useEffect(() => {
    loadActivity();
  }, [loadActivity]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update(f).eq("id", user.id);
    setSaving(false);
    setMsg(error ? { tone: "red", text: errorText(error) } : { tone: "green", text: "บันทึกแล้ว" });
    if (!error) refreshProfile();
  };

  const changePw = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password: pw });
    setPwMsg(error ? { tone: "red", text: errorText(error) } : { tone: "green", text: "เปลี่ยนรหัสผ่านแล้ว" });
    if (!error) setPw("");
  };

  const cancelOrder = async (o: Order) => {
    if (!confirm(`ยกเลิกคำสั่งซื้อ ${orderCode(o.order_no)}?`)) return;
    const { error } = await supabase.rpc("cancel_my_order", { p_order: o.id });
    if (error) alert(errorText(error));
    loadActivity();
  };

  return (
    <Container className="max-w-4xl py-10">
      <PageHeader
        eyebrow={ROLE[profile?.role ?? "user"]}
        title="บัญชีของฉัน"
        desc={user?.email}
      />

      <div className="space-y-6">
        <Section title="ข้อมูลส่วนตัว" icon={<UserRound className="size-5" />}>
          <form onSubmit={save} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="ชื่อที่แสดง">
                <Input value={f.display_name} onChange={(e) => setF({ ...f, display_name: e.target.value })} />
              </Field>
              <Field label="เบอร์โทร">
                <Input type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
              </Field>
              <Field label="LINE ID">
                <Input value={f.line_id} onChange={(e) => setF({ ...f, line_id: e.target.value })} />
              </Field>
            </div>
            <AddressSelect value={f} onChange={(a) => setF({ ...f, ...a })} />
            {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
            <Button type="submit" loading={saving}>บันทึก</Button>
          </form>
        </Section>

        <Section title="การบริจาคของฉัน" icon={<HandHeart className="size-5" />}>
          {donations.length === 0 ? (
            <p className="text-sm text-muted">ยังไม่มีรายการ — <Link href="/donate" className="underline">ดูเคสที่เปิดรับบริจาค</Link></p>
          ) : (
            <ul className="divide-y divide-line">
              {donations.map((d) => (
                <li key={d.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                  <div>
                    <p className="font-medium">{d.cases?.title ?? "กองทุนกลาง Me Dog"}</p>
                    <p className="text-muted">{formatDate(d.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold tabular-nums">{baht(d.amount)}</span>
                    <Badge tone={DONATION_STATUS[d.status].tone}>{DONATION_STATUS[d.status].label}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="คำสั่งซื้อ" icon={<Package className="size-5" />}>
          {orders.length === 0 ? (
            <p className="text-sm text-muted">ยังไม่มีคำสั่งซื้อ — <Link href="/shop" className="underline">ไปที่ร้านค้าเพื่อน้อง</Link></p>
          ) : (
            <ul className="divide-y divide-line">
              {orders.map((o) => (
                <li key={o.id} className="py-3 text-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-semibold">
                      {orderCode(o.order_no)} <span className="font-normal text-muted">· {formatDate(o.created_at)} · {o.delivery === "donate" ? "บริจาคให้โครงการ" : "จัดส่ง"}</span>
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{baht(o.total)}</span>
                      <Badge tone={ORDER_STATUS[o.status].tone}>
                        {o.status === "pending_payment" && o.slip_path ? "รอตรวจสลิป" : ORDER_STATUS[o.status].label}
                      </Badge>
                    </div>
                  </div>
                  <p className="mt-1 text-muted">{o.items.map((i) => `${i.name} ×${i.qty}`).join(", ")}</p>
                  {o.tracking_no && <p className="mt-1">เลขพัสดุ: <b>{o.tracking_no}</b></p>}
                  {o.status === "pending_payment" && (
                    <div className="mt-2 flex gap-2">
                      {!o.slip_path && <Button size="sm" variant="brand" onClick={() => setPayOrder(o)}>ชำระเงิน / แนบสลิป</Button>}
                      <Button size="sm" variant="ghost" onClick={() => cancelOrder(o)}>ยกเลิก</Button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="เปลี่ยนรหัสผ่าน" icon={<KeyRound className="size-5" />}>
          <form onSubmit={changePw} className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <Field label="รหัสผ่านใหม่" className="flex-1">
              <Input type="password" minLength={6} required value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" />
            </Field>
            <Button type="submit" variant="secondary">เปลี่ยนรหัสผ่าน</Button>
          </form>
          {pwMsg && <Alert tone={pwMsg.tone} className="mt-3">{pwMsg.text}</Alert>}
        </Section>
      </div>

      <PayLater order={payOrder} userId={user?.id ?? ""} onClose={() => setPayOrder(null)} onDone={loadActivity} />
    </Container>
  );
}

function PayLater({ order, userId, onClose, onDone }: { order: Order | null; userId: string; onClose: () => void; onDone: () => void }) {
  const [slip, setSlip] = useState<Blob | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  if (!order) return null;
  const submit = async () => {
    if (!slip) return setErr("กรุณาแนบสลิป");
    setBusy(true);
    try {
      const path = await uploadSlip(slip, userId);
      const { error } = await supabase.rpc("attach_order_slip", { p_order: order.id, p_path: path });
      if (error) throw error;
      setSlip(null);
      onClose();
      onDone();
    } catch (e) {
      setErr(errorText(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal open onClose={onClose} title={`ชำระเงิน ${orderCode(order.order_no)}`}>
      <div className="space-y-4">
        <PromptPayBox amount={Number(order.total)} />
        <SlipInput file={slip} onChange={setSlip} />
        {err && <Alert tone="red">{err}</Alert>}
        <Button className="w-full" variant="brand" onClick={submit} loading={busy}>ส่งสลิป</Button>
      </div>
    </Modal>
  );
}
