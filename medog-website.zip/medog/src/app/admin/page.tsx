"use client";

import { useEffect, useState } from "react";
import { Building2, ClipboardList, HandCoins, LayoutDashboard, Package, PawPrint, ShoppingCart, UserCog, Users } from "lucide-react";
import { AdminAgencies } from "@/components/admin/AdminAgencies";
import { AdminAnimals } from "@/components/admin/AdminAnimals";
import { AdminCases } from "@/components/admin/AdminCases";
import { AdminDonations } from "@/components/admin/AdminDonations";
import { AdminOrders } from "@/components/admin/AdminOrders";
import { AdminOverview } from "@/components/admin/AdminOverview";
import { AdminProducts } from "@/components/admin/AdminProducts";
import { AdminUsers } from "@/components/admin/AdminUsers";
import { AdminVolunteers } from "@/components/admin/AdminVolunteers";
import type { AdminTab } from "@/components/admin/types";
import { useAuth } from "@/components/AuthProvider";
import { RequireAuth } from "@/components/RequireAuth";
import { Container } from "@/components/ui";
import { ROLE } from "@/lib/constants";
import { cls } from "@/lib/utils";


const TABS: { key: AdminTab; label: string; icon: React.ReactNode; adminOnly: boolean }[] = [
  { key: "overview", label: "ภาพรวม", icon: <LayoutDashboard className="size-4" />, adminOnly: true },
  { key: "cases", label: "เคส", icon: <ClipboardList className="size-4" />, adminOnly: false },
  { key: "agencies", label: "หน่วยงาน", icon: <Building2 className="size-4" />, adminOnly: false },
  { key: "animals", label: "ข้อมูลสัตว์รายตัว", icon: <PawPrint className="size-4" />, adminOnly: true },
  { key: "volunteers", label: "อาสาสมัคร", icon: <Users className="size-4" />, adminOnly: true },
  { key: "donations", label: "ตรวจสลิปบริจาค", icon: <HandCoins className="size-4" />, adminOnly: true },
  { key: "orders", label: "คำสั่งซื้อ", icon: <ShoppingCart className="size-4" />, adminOnly: true },
  { key: "products", label: "สินค้า", icon: <Package className="size-4" />, adminOnly: true },
  { key: "users", label: "ผู้ใช้และสิทธิ์", icon: <UserCog className="size-4" />, adminOnly: true },
];

export default function AdminPage() {
  return (
    <RequireAuth staff>
      <Admin />
    </RequireAuth>
  );
}

function Admin() {
  const { isAdmin, profile } = useAuth();
  const [tab, setTab] = useState<AdminTab>("cases");
  const [focusCase, setFocusCase] = useState<string | null>(null);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const t = p.get("tab") as AdminTab | null;
    if (t && TABS.some((x) => x.key === t)) setTab(t);
    else if (isAdmin) setTab("overview");
    setFocusCase(p.get("case"));
  }, [isAdmin]);

  const tabs = TABS.filter((t) => isAdmin || !t.adminOnly);
  const go = (t: AdminTab) => {
    setTab(t);
    window.history.replaceState(null, "", `/admin?tab=${t}`);
  };

  return (
    <Container className="py-8">
      <div className="mb-6">
        <p className="text-sm font-semibold text-brand-dark">ระบบผู้ดูแล · {ROLE[profile?.role ?? "user"]}</p>
        <h1 className="text-2xl font-bold sm:text-3xl">แผงควบคุม Me Dog</h1>
        {profile?.role === "co_admin" && (
          <p className="mt-1 text-sm text-muted">
            คุณดูแลเฉพาะเคส{profile.staff_province ? ` ในจังหวัด${profile.staff_province}` : "ทุกจังหวัด"}
          </p>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        <nav className="flex gap-1 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => go(t.key)}
              className={cls(
                "flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-medium",
                tab === t.key ? "bg-ink text-white" : "text-ink-soft hover:bg-white",
              )}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </nav>
        <div className="min-w-0">
          {tab === "overview" && isAdmin && <AdminOverview go={go} />}
          {tab === "cases" && <AdminCases focusId={focusCase} />}
          {tab === "agencies" && <AdminAgencies />}
          {tab === "animals" && isAdmin && <AdminAnimals />}
          {tab === "volunteers" && isAdmin && <AdminVolunteers />}
          {tab === "donations" && isAdmin && <AdminDonations />}
          {tab === "orders" && isAdmin && <AdminOrders />}
          {tab === "products" && isAdmin && <AdminProducts />}
          {tab === "users" && isAdmin && <AdminUsers />}
        </div>
      </div>
    </Container>
  );
}
