"use client";

import { Camera, MapPin, ShieldAlert, User } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AddressSelect } from "@/components/AddressSelect";
import { useAuth } from "@/components/AuthProvider";
import { UrgencyMeter } from "@/components/cases/UrgencyMeter";
import { LocationPicker } from "@/components/map/LocationPicker";
import { PhotoUploader } from "@/components/PhotoUploader";
import { RequireAuth } from "@/components/RequireAuth";
import { Alert, Button, Container, Field, Input, PageHeader, Section, Segmented, Select, Textarea } from "@/components/ui";
import { AGGRESSION, CASE_CATEGORY, PROXIMITY, SPECIES, VAX_STATUS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Case } from "@/lib/types";

export default function NewCasePage() {
  return (
    <RequireAuth message="เข้าสู่ระบบเพื่อแจ้งเคส ทีมงานจะติดต่อกลับและแจ้งความคืบหน้าให้คุณทราบ">
      <NewCaseForm />
    </RequireAuth>
  );
}

function NewCaseForm() {
  const router = useRouter();
  const { user, profile } = useAuth();
  const [f, setF] = useState({
    title: "",
    category: "injured" as Case["category"],
    species: "dog" as Case["species"],
    animal_count: 1,
    description: "",
    photo_urls: [] as string[],
    province: null as string | null,
    amphoe: null as string | null,
    tambon: null as string | null,
    location_note: "",
    lat: null as number | null,
    lng: null as number | null,
    proximity: "near" as Case["proximity"],
    aggression: "none" as Case["aggression"],
    vaccination_status: "unknown" as Case["vaccination_status"],
  });
  const [contact, setContact] = useState({ reporter_name: "", phone: "", line_id: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (profile)
      setContact((c) => ({
        reporter_name: c.reporter_name || profile.display_name || "",
        phone: c.phone || profile.phone || "",
        line_id: c.line_id || profile.line_id || "",
      }));
  }, [profile]);

  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((s) => ({ ...s, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!isConfigured) return setErr("ยังไม่ได้เชื่อมฐานข้อมูล");
    if (!user) return;
    if (!f.province || !f.amphoe) return setErr("กรุณาระบุจังหวัดและอำเภอ เพื่อส่งต่อหน่วยงานในพื้นที่ได้ถูกต้อง");
    if (!contact.phone.trim()) return setErr("กรุณาใส่เบอร์โทรติดต่อกลับ");
    setSaving(true);
    try {
      const { data, error } = await supabase
        .from("cases")
        .insert({ ...f, title: f.title.trim(), reporter_id: user.id })
        .select("id")
        .single();
      if (error) throw error;
      await supabase.from("case_contacts").insert({ case_id: data.id, ...contact });
      router.push(`/cases/${data.id}?new=1`);
    } catch (e2) {
      setErr(errorText(e2));
      setSaving(false);
    }
  };

  return (
    <Container className="max-w-3xl py-10">
      <PageHeader
        eyebrow="แจ้งเคส"
        title="แจ้งสัตว์ที่ต้องการความช่วยเหลือ"
        desc="แอดมินจะตรวจสอบข้อมูล ประเมินความเร่งด่วน และส่งต่อไปยังหน่วยงานหรืออาสาในพื้นที่"
      />
      <Alert tone="amber" className="mb-6" title="กรณีฉุกเฉิน">
        ถ้ามีคนถูกกัด ให้ล้างแผลด้วยน้ำสะอาดและสบู่นานอย่างน้อย 15 นาที แล้วรีบไปโรงพยาบาลทันที
      </Alert>

      <form onSubmit={submit} className="space-y-6">
        <Section title="เกิดอะไรขึ้น" icon={<ShieldAlert className="size-5" />}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="หัวข้อเคส" required className="sm:col-span-2">
              <Input
                required
                value={f.title}
                onChange={(e) => set("title", e.target.value)}
                placeholder="เช่น สุนัขขาหลังบาดเจ็บ หน้าตลาดเช้า"
                maxLength={120}
              />
            </Field>
            <Field label="ประเภทเคส" required>
              <Select value={f.category} onChange={(e) => set("category", e.target.value as Case["category"])} options={CASE_CATEGORY} />
            </Field>
            <Field label="ชนิดสัตว์ / จำนวน">
              <div className="flex gap-2">
                <Select value={f.species} onChange={(e) => set("species", e.target.value as Case["species"])} options={SPECIES} />
                <Input
                  type="number"
                  min={1}
                  className="w-24"
                  value={f.animal_count}
                  onChange={(e) => set("animal_count", Math.max(1, Number(e.target.value) || 1))}
                />
              </div>
            </Field>
            <Field label="รายละเอียด" className="sm:col-span-2" hint="อาการ ลักษณะสัตว์ ช่วงเวลาที่พบ สิ่งที่ต้องการ">
              <Textarea rows={4} value={f.description} onChange={(e) => set("description", e.target.value)} />
            </Field>
          </div>
        </Section>

        <Section title="รูปภาพ" desc="รูปช่วยให้แอดมินประเมินเคสได้เร็วขึ้น" icon={<Camera className="size-5" />}>
          <PhotoUploader bucket="case-photos" value={f.photo_urls} onChange={(v) => set("photo_urls", v)} />
        </Section>

        <Section title="สถานที่และความเสี่ยง" icon={<MapPin className="size-5" />}>
          <AddressSelect
            required
            value={{ province: f.province, amphoe: f.amphoe, tambon: f.tambon }}
            onChange={(a) => setF((s) => ({ ...s, ...a }))}
          />
          <Field label="จุดสังเกต" className="mt-4">
            <Input value={f.location_note} onChange={(e) => set("location_note", e.target.value)} placeholder="เช่น ข้างเซเว่น ซอย 5" />
          </Field>
          <div className="mt-4">
            <LocationPicker lat={f.lat} lng={f.lng} onChange={(lat, lng) => setF((s) => ({ ...s, lat, lng }))} />
          </div>

          <div className="mt-6 space-y-5">
            <Field label="ใกล้โรงเรียน ตลาด หรือชุมชนแค่ไหน">
              <Segmented value={f.proximity} onChange={(v) => set("proximity", v)} options={PROXIMITY} />
            </Field>
            <Field label="ความก้าวร้าว">
              <Segmented value={f.aggression} onChange={(v) => set("aggression", v)} options={AGGRESSION} />
            </Field>
            <Field label="สถานะวัคซีน">
              <Segmented value={f.vaccination_status} onChange={(v) => set("vaccination_status", v)} options={VAX_STATUS} />
            </Field>
            <UrgencyMeter c={f} />
          </div>
        </Section>

        <Section title="ข้อมูลติดต่อกลับ" desc="เห็นเฉพาะแอดมินและอาสาที่รับเคส ไม่แสดงต่อสาธารณะ" icon={<User className="size-5" />}>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="ชื่อ">
              <Input value={contact.reporter_name} onChange={(e) => setContact({ ...contact, reporter_name: e.target.value })} />
            </Field>
            <Field label="เบอร์โทร" required>
              <Input type="tel" required value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
            </Field>
            <Field label="LINE ID">
              <Input value={contact.line_id} onChange={(e) => setContact({ ...contact, line_id: e.target.value })} />
            </Field>
          </div>
        </Section>

        {err && <Alert tone="red">{err}</Alert>}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="secondary" onClick={() => router.back()}>
            ยกเลิก
          </Button>
          <Button type="submit" variant="brand" size="lg" loading={saving}>
            ส่งเคส
          </Button>
        </div>
      </form>
    </Container>
  );
}
