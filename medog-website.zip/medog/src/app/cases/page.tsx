"use client";

import { LifeBuoy, Plus } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useThaiAddress } from "@/components/AddressSelect";
import { useAuth } from "@/components/AuthProvider";
import { CaseCard } from "@/components/cases/CaseCard";
import { Container, Empty, LinkButton, PageHeader, Segmented, Select, Spinner } from "@/components/ui";
import { CASE_CATEGORY } from "@/lib/constants";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Case } from "@/lib/types";

type Tab = "open" | "fundraising" | "resolved" | "mine";

export default function CasesPage() {
  const { user, isVolunteer } = useAuth();
  const tree = useThaiAddress();
  const [tab, setTab] = useState<Tab>("open");
  const [province, setProvince] = useState("");
  const [category, setCategory] = useState("");
  const [rows, setRows] = useState<Case[]>([]);
  const [funding, setFunding] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(isConfigured);

  useEffect(() => {
    if (!isConfigured) return;
    Promise.all([
      supabase.from("cases").select("*").order("created_at", { ascending: false }).limit(300),
      supabase.rpc("case_funding"),
    ]).then(([c, f]) => {
      setRows((c.data as Case[]) ?? []);
      const map: Record<string, number> = {};
      ((f.data as { case_id: string; raised: number }[]) ?? []).forEach((x) => (map[x.case_id] = Number(x.raised)));
      setFunding(map);
      setLoading(false);
    });
  }, [user]);

  const filtered = useMemo(() => {
    return rows
      .filter((c) => {
        if (tab === "mine") return c.reporter_id === user?.id;
        if (tab === "fundraising") return c.status === "fundraising";
        if (tab === "resolved") return c.status === "resolved";
        return c.status !== "resolved" && c.status !== "rejected" && (isVolunteer || !["submitted", "reviewing"].includes(c.status) || c.reporter_id === user?.id);
      })
      .filter((c) => !province || c.province === province)
      .filter((c) => !category || c.category === category)
      .sort((a, b) => Number(b.is_urgent) - Number(a.is_urgent) || b.urgency_score - a.urgency_score);
  }, [rows, tab, province, category, user, isVolunteer]);

  const tabs: { value: Tab; label: string }[] = [
    { value: "open", label: "กำลังดำเนินการ" },
    { value: "fundraising", label: "เปิดรับบริจาค" },
    { value: "resolved", label: "ช่วยเหลือสำเร็จ" },
    ...(user ? [{ value: "mine" as Tab, label: "เคสที่ฉันแจ้ง" }] : []),
  ];

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="เคสช่วยเหลือ"
        title="เคสที่ต้องการความช่วยเหลือ"
        desc="ทุกเคสผ่านการตรวจสอบโดยแอดมินก่อนเผยแพร่ และส่งต่อหน่วยงานในพื้นที่ เรียงตามคะแนนความเร่งด่วน"
        actions={
          <LinkButton href="/cases/new" variant="brand">
            <Plus className="size-4" /> แจ้งเคสใหม่
          </LinkButton>
        }
      />

      <div className="mb-6 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <Segmented value={tab} onChange={setTab} options={tabs} />
        <div className="flex gap-2">
          <Select value={category} onChange={(e) => setCategory(e.target.value)} placeholder="ทุกประเภท" options={CASE_CATEGORY} className="w-40" />
          <Select
            value={province}
            onChange={(e) => setProvince(e.target.value)}
            placeholder="ทุกจังหวัด"
            options={(tree ? Object.keys(tree) : []).map((p) => ({ value: p, label: p }))}
            className="w-40"
          />
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <Empty
          icon={<LifeBuoy className="size-6" />}
          title="ยังไม่มีเคสในหมวดนี้"
          desc="พบสัตว์ที่ต้องการความช่วยเหลือ? แจ้งเคสเข้ามา ทีมแอดมินจะตรวจสอบและส่งต่อหน่วยงานในพื้นที่"
          action={<LinkButton href="/cases/new">แจ้งเคส</LinkButton>}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <CaseCard key={c.id} c={c} raised={funding[c.id]} />
          ))}
        </div>
      )}
    </Container>
  );
}
