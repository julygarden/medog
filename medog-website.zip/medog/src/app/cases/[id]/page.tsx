"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, Building2, HandHeart, MapPin, Phone, Settings2, Siren, Users } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { UrgencyMeter } from "@/components/cases/UrgencyMeter";
import { MiniMap } from "@/components/map/LocationPicker";
import { DonateForm } from "@/components/payment/DonateForm";
import { Alert, Badge, Button, Card, Container, Empty, LinkButton, Progress, Spinner, Textarea } from "@/components/ui";
import { AGENCY_KIND, AGGRESSION, CASE_CATEGORY, CASE_STATUS, PROXIMITY, SPECIES, VAX_STATUS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Agency, Case, CaseContact, CaseUpdate } from "@/lib/types";
import { baht, caseCode, formatDate, formatDateTime } from "@/lib/utils";

interface Donor {
  name: string;
  amount: number;
  message: string | null;
  created_at: string;
}

export default function CaseDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user, isVolunteer, isStaff } = useAuth();
  const [c, setC] = useState<Case | null>(null);
  const [loading, setLoading] = useState(isConfigured);
  const [raised, setRaised] = useState(0);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [updates, setUpdates] = useState<CaseUpdate[]>([]);
  const [contact, setContact] = useState<CaseContact | null>(null);
  const [agency, setAgency] = useState<Agency | null>(null);
  const [volCount, setVolCount] = useState(0);
  const [joined, setJoined] = useState(false);
  const [photo, setPhoto] = useState(0);
  const [isNew, setIsNew] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const load = useCallback(async () => {
    if (!isConfigured) return;
    const { data } = await supabase.from("cases").select("*").eq("id", id).maybeSingle();
    const cs = data as Case | null;
    setC(cs);
    setLoading(false);
    if (!cs) return;
    const [f, d, u, ct, vc] = await Promise.all([
      supabase.rpc("case_funding"),
      supabase.rpc("case_donors", { p_case: id }),
      supabase.from("case_updates").select("*").eq("case_id", id).order("created_at", { ascending: false }),
      supabase.from("case_contacts").select("*").eq("case_id", id).maybeSingle(),
      supabase.rpc("case_volunteer_count", { p_case: id }),
    ]);
    setRaised(Number(((f.data as { case_id: string; raised: number }[]) ?? []).find((x) => x.case_id === id)?.raised ?? 0));
    setDonors((d.data as Donor[]) ?? []);
    setUpdates((u.data as CaseUpdate[]) ?? []);
    setContact((ct.data as CaseContact) ?? null);
    setVolCount(Number(vc.data ?? 0));
    if (cs.forwarded_agency_id) {
      const { data: ag } = await supabase.from("agencies").select("*").eq("id", cs.forwarded_agency_id).maybeSingle();
      setAgency(ag as Agency | null);
    }
  }, [id]);

  useEffect(() => {
    load();
    setIsNew(new URLSearchParams(window.location.search).has("new"));
  }, [load]);

  useEffect(() => {
    if (!user || !isConfigured) return;
    supabase
      .from("case_volunteers")
      .select("case_id")
      .eq("case_id", id)
      .eq("volunteer_id", user.id)
      .maybeSingle()
      .then(({ data }) => setJoined(Boolean(data)));
  }, [id, user]);

  if (loading) return <Spinner />;
  if (!c)
    return (
      <Container className="py-16">
        <Empty title="ไม่พบเคสนี้" desc="เคสอาจยังไม่ผ่านการตรวจสอบ หรือถูกลบไปแล้ว" action={<LinkButton href="/cases">ดูเคสทั้งหมด</LinkButton>} />
      </Container>
    );

  const st = CASE_STATUS[c.status];
  const canJoin = isVolunteer && ["verified", "forwarded", "fundraising", "in_progress"].includes(c.status);

  const toggleJoin = async () => {
    if (!user) return;
    setBusy(true);
    setErr("");
    const res = joined
      ? await supabase.from("case_volunteers").delete().eq("case_id", c.id).eq("volunteer_id", user.id)
      : await supabase.from("case_volunteers").insert({ case_id: c.id, volunteer_id: user.id });
    if (res.error) setErr(errorText(res.error));
    else {
      setJoined(!joined);
      await load();
    }
    setBusy(false);
  };

  const postUpdate = async () => {
    if (!note.trim() || !user) return;
    setBusy(true);
    const { error } = await supabase.from("case_updates").insert({ case_id: c.id, author_id: user.id, note: note.trim(), is_public: true });
    if (error) setErr(errorText(error));
    else {
      setNote("");
      await load();
    }
    setBusy(false);
  };

  return (
    <Container className="py-8">
      <Link href="/cases" className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink">
        <ArrowLeft className="size-4" /> เคสทั้งหมด
      </Link>

      {isNew && (
        <Alert tone="green" className="mb-6" title="ส่งเคสเรียบร้อย">
          แอดมินจะตรวจสอบและติดต่อกลับ คุณติดตามสถานะได้ที่หน้านี้ หรือเมนู “เคสที่ฉันแจ้ง”
        </Alert>
      )}
      {c.is_demo && <Alert tone="amber" className="mb-4">เคสตัวอย่างสำหรับสาธิตระบบ</Alert>}

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={st.tone}>{st.label}</Badge>
              {c.is_urgent && (
                <Badge tone="red">
                  <Siren className="size-3" /> แอดมินประเมิน: เร่งด่วน
                </Badge>
              )}
              <span className="text-sm text-muted">
                {caseCode(c.case_no)} · แจ้งเมื่อ {formatDate(c.created_at)}
              </span>
            </div>
            <h1 className="mt-2 text-2xl font-bold leading-snug sm:text-3xl">{c.title}</h1>
            <p className="mt-2 flex items-center gap-1.5 text-muted">
              <MapPin className="size-4" />
              {[c.location_note, c.tambon && `ต.${c.tambon}`, c.amphoe && `อ.${c.amphoe}`, c.province && `จ.${c.province}`].filter(Boolean).join(" ")}
            </p>
          </div>

          {c.photo_urls.length > 0 && (
            <Card className="overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={c.photo_urls[photo]} alt="" className="aspect-[16/10] w-full bg-sand object-cover" />
              {c.photo_urls.length > 1 && (
                <div className="flex gap-2 overflow-x-auto p-3">
                  {c.photo_urls.map((u, i) => (
                    <button key={u} onClick={() => setPhoto(i)} className={`size-16 shrink-0 overflow-hidden rounded-lg ring-2 ${i === photo ? "ring-ink" : "ring-transparent"}`}>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={u} alt="" className="size-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </Card>
          )}

          <Card className="p-5 sm:p-6">
            <div className="grid gap-3 text-sm sm:grid-cols-2">
              <p><span className="text-muted">ประเภท:</span> {CASE_CATEGORY[c.category]}</p>
              <p><span className="text-muted">สัตว์:</span> {SPECIES[c.species]} {c.animal_count} ตัว</p>
              <p><span className="text-muted">ระยะจากชุมชน:</span> {PROXIMITY[c.proximity]}</p>
              <p><span className="text-muted">ความก้าวร้าว:</span> {AGGRESSION[c.aggression]}</p>
              <p><span className="text-muted">วัคซีน:</span> {VAX_STATUS[c.vaccination_status]}</p>
            </div>
            {c.description && <p className="mt-4 whitespace-pre-line leading-relaxed">{c.description}</p>}
            {c.public_note && (
              <Alert tone="blue" className="mt-4" title="หมายเหตุจากทีมงาน">
                {c.public_note}
              </Alert>
            )}
          </Card>

          <UrgencyMeter c={c} />

          {c.lat != null && c.lng != null && <MiniMap lat={c.lat} lng={c.lng} className="h-64" />}

          <Card className="p-5 sm:p-6">
            <p className="mb-4 font-semibold">ความคืบหน้า</p>
            {(joined || isStaff) && (
              <div className="mb-5 flex gap-2">
                <Textarea rows={2} placeholder="อัปเดตความคืบหน้า เช่น พาไปคลินิกแล้ว" value={note} onChange={(e) => setNote(e.target.value)} />
                <Button onClick={postUpdate} loading={busy} disabled={!note.trim()} className="self-end">
                  โพสต์
                </Button>
              </div>
            )}
            {updates.length === 0 ? (
              <p className="text-sm text-muted">ยังไม่มีการอัปเดต</p>
            ) : (
              <ol className="relative space-y-4 border-l-2 border-line pl-5">
                {updates.map((u) => (
                  <li key={u.id} className="relative">
                    <span className="absolute -left-[27px] top-1.5 size-3 rounded-full border-2 border-white bg-ink ring-2 ring-ink/10" />
                    {u.status && <p className="text-sm font-semibold">{CASE_STATUS[u.status]?.label ?? u.status}</p>}
                    {u.note && <p className="text-sm">{u.note}</p>}
                    <p className="text-xs text-muted">{formatDateTime(u.created_at)}</p>
                  </li>
                ))}
              </ol>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          {c.status === "fundraising" && c.goal_amount ? (
            <Card className="p-5">
              <p className="flex items-center gap-2 font-semibold">
                <HandHeart className="size-5 text-brand" /> ร่วมบริจาคเคสนี้
              </p>
              {c.fund_purpose && <p className="mt-1 text-sm text-muted">ใช้สำหรับ: {c.fund_purpose}</p>}
              <div className="mt-4">
                <Progress value={(raised / c.goal_amount) * 100} />
                <div className="mt-2 flex items-end justify-between">
                  <p className="text-2xl font-bold">{baht(raised)}</p>
                  <p className="text-sm text-muted">จาก {baht(c.goal_amount)}</p>
                </div>
                <p className="text-xs text-muted">ยอดที่แอดมินตรวจสลิปแล้ว · ผู้บริจาค {donors.length} ราย</p>
              </div>
              <div className="mt-5 border-t border-line pt-5">
                <DonateForm caseId={c.id} promptpayId={c.promptpay_id} />
              </div>
            </Card>
          ) : (
            <Card className="p-5 text-sm">
              <p className="font-semibold">สนับสนุนการช่วยเหลือ</p>
              <p className="mt-1 text-muted">
                {c.status === "resolved"
                  ? "เคสนี้ช่วยเหลือสำเร็จแล้ว ขอบคุณทุกแรงสนับสนุน"
                  : "เคสนี้ยังไม่เปิดรับบริจาค คุณช่วยได้ผ่านกองทุนกลาง หรือร้านค้าเพื่อน้อง"}
              </p>
              <div className="mt-4 flex gap-2">
                <LinkButton href="/donate" variant="brand" size="sm">บริจาคกองทุนกลาง</LinkButton>
                <LinkButton href="/shop" variant="secondary" size="sm">ร้านค้าเพื่อน้อง</LinkButton>
              </div>
            </Card>
          )}

          {donors.length > 0 && (
            <Card className="p-5">
              <p className="mb-3 font-semibold">ผู้ร่วมบริจาค</p>
              <ul className="max-h-72 space-y-3 overflow-y-auto">
                {donors.map((d, i) => (
                  <li key={i} className="text-sm">
                    <div className="flex justify-between gap-2">
                      <span className="font-medium">{d.name}</span>
                      <span className="tabular-nums">{baht(d.amount)}</span>
                    </div>
                    {d.message && <p className="text-muted">“{d.message}”</p>}
                  </li>
                ))}
              </ul>
            </Card>
          )}

          <Card className="p-5">
            <p className="flex items-center gap-2 font-semibold">
              <Users className="size-5" /> อาสาที่รับเคส: {volCount} คน
            </p>
            {canJoin ? (
              <>
                <p className="mt-1 text-sm text-muted">
                  {joined ? "คุณรับเคสนี้แล้ว — ดูข้อมูลติดต่อผู้แจ้งด้านล่าง และโพสต์ความคืบหน้าได้" : "อาสาที่ผ่านการอบรมสามารถรับเคสเพื่อลงพื้นที่ช่วยเหลือ"}
                </p>
                <Button variant={joined ? "secondary" : "primary"} className="mt-3 w-full" onClick={toggleJoin} loading={busy}>
                  {joined ? "ถอนตัวจากเคส" : "รับเคสนี้"}
                </Button>
              </>
            ) : (
              !isVolunteer && (
                <p className="mt-1 text-sm text-muted">
                  อยากลงพื้นที่ช่วย? <Link href="/volunteer" className="font-medium text-ink underline">สมัครอาสาสมัคร</Link>
                </p>
              )
            )}
            {err && <Alert tone="red" className="mt-3">{err}</Alert>}
          </Card>

          {agency && (
            <Card className="p-5 text-sm">
              <p className="flex items-center gap-2 font-semibold">
                <Building2 className="size-5" /> ส่งต่อหน่วยงานแล้ว
              </p>
              <p className="mt-2 font-medium">{agency.name}</p>
              <p className="text-muted">
                {AGENCY_KIND[agency.kind]} · ส่งเมื่อ {formatDate(c.forwarded_at)}
              </p>
            </Card>
          )}

          {contact && (
            <Card className="border-sky-200 bg-sky-50/50 p-5 text-sm">
              <p className="flex items-center gap-2 font-semibold">
                <Phone className="size-4" /> ข้อมูลติดต่อผู้แจ้ง (ไม่เปิดเผยต่อสาธารณะ)
              </p>
              <p className="mt-2">{contact.reporter_name || "-"}</p>
              {contact.phone && <a href={`tel:${contact.phone}`} className="font-medium text-sky-800 underline">{contact.phone}</a>}
              {contact.line_id && <p>LINE: {contact.line_id}</p>}
            </Card>
          )}

          {isStaff && (
            <LinkButton href={`/admin?tab=cases&case=${c.id}`} variant="secondary" className="w-full">
              <Settings2 className="size-4" /> จัดการเคสนี้ (แอดมิน)
            </LinkButton>
          )}
        </div>
      </div>
    </Container>
  );
}
