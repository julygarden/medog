import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@supabase/supabase-js";
import { CAT_BREEDS, DOG_BREEDS } from "@/lib/constants";

export const runtime = "nodejs";
export const maxDuration = 30;

const MODEL = process.env.ANTHROPIC_MODEL || "claude-haiku-4-5";

const PROMPT = `คุณคือผู้เชี่ยวชาญด้านสายพันธุ์สุนัขและแมว วิเคราะห์ใบหน้า รูปร่าง ขน และสัดส่วนของสัตว์ในรูป
แล้วประเมินว่าน่าจะเป็นสายพันธุ์อะไร เป็นเปอร์เซ็นต์ (สูงสุด 4 สายพันธุ์ รวมกัน = 100)

กติกา:
- ถ้าเป็นสุนัข/แมวบ้านไทยหรือพันธุ์ผสมที่ไม่ชัด ให้ใช้ "พันธุ์ไทย/พันธุ์ผสม" (สุนัข) หรือ "แมวไทยพื้นบ้าน/พันธุ์ผสม" (แมว)
- ใช้ชื่อภาษาไทยจากรายการนี้ถ้าตรงกัน:
  สุนัข: ${DOG_BREEDS.map((b) => b.th).join(", ")}
  แมว: ${CAT_BREEDS.map((b) => b.th).join(", ")}
- ถ้าไม่มีสุนัขหรือแมวในรูป ให้ species = "none" และ breeds = []
- note_th: อธิบายสั้นๆ 1 ประโยคว่าสังเกตจากลักษณะใด

ตอบเป็น JSON อย่างเดียว ไม่ต้องมีข้อความอื่น ตามรูปแบบ:
{"species":"dog|cat|other|none","breeds":[{"name_th":"...","name_en":"...","percent":70}],"is_mixed":true,"confidence":"high|medium|low","note_th":"..."}`;

type Guess = { name_th?: string; name_en?: string; percent?: number };

function normalize(raw: unknown) {
  const r = (raw ?? {}) as { species?: string; breeds?: Guess[]; is_mixed?: boolean; confidence?: string; note_th?: string };
  const breeds = (Array.isArray(r.breeds) ? r.breeds : [])
    .filter((b) => b && typeof b.name_th === "string" && b.name_th.trim())
    .slice(0, 4)
    .map((b) => ({ name_th: b.name_th!.trim(), name_en: b.name_en?.trim() || undefined, percent: Math.max(0, Number(b.percent) || 0) }));
  const sum = breeds.reduce((s, b) => s + b.percent, 0);
  if (breeds.length && sum > 0) {
    breeds.forEach((b) => (b.percent = Math.round((b.percent / sum) * 100)));
    const diff = 100 - breeds.reduce((s, b) => s + b.percent, 0);
    breeds[0].percent += diff;
  }
  breeds.sort((a, b) => b.percent - a.percent);
  const species = ["dog", "cat", "other", "none"].includes(r.species ?? "") ? r.species : "other";
  const confidence = ["high", "medium", "low"].includes(r.confidence ?? "") ? r.confidence : "medium";
  return { species, breeds, is_mixed: Boolean(r.is_mixed), confidence, note_th: r.note_th };
}

export async function POST(req: Request) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "ยังไม่ได้เปิดใช้ AI วิเคราะห์สายพันธุ์ (ผู้ดูแลต้องตั้งค่า ANTHROPIC_API_KEY) — เลือกสายพันธุ์เองได้เลย" },
      { status: 503 },
    );
  }

  // อนุญาตเฉพาะผู้ใช้ที่เข้าสู่ระบบ เพื่อป้องกันการใช้งานเกินจำเป็น
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (url && anon) {
    const sb = createClient(url, anon, { auth: { persistSession: false } });
    const { data, error } = await sb.auth.getUser(token);
    if (error || !data.user) return Response.json({ error: "กรุณาเข้าสู่ระบบก่อนใช้ AI" }, { status: 401 });
  }

  let body: { image?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "ข้อมูลไม่ถูกต้อง" }, { status: 400 });
  }
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,(.+)$/.exec(body.image ?? "");
  if (!m) return Response.json({ error: "ไฟล์รูปไม่ถูกต้อง" }, { status: 400 });
  if (m[2].length > 6_000_000) return Response.json({ error: "รูปใหญ่เกินไป" }, { status: 413 });

  try {
    const client = new Anthropic({ apiKey });
    const msg = await client.messages.create({
      model: MODEL,
      max_tokens: 700,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: m[1] as "image/jpeg" | "image/png" | "image/webp" | "image/gif", data: m[2] },
            },
            { type: "text", text: PROMPT },
          ],
        },
      ],
    });
    const text = msg.content.map((b) => (b.type === "text" ? b.text : "")).join("");
    const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
    return Response.json(normalize(JSON.parse(json)));
  } catch (e) {
    console.error("breed AI error", e);
    return Response.json({ error: "AI วิเคราะห์ไม่สำเร็จ ลองใหม่อีกครั้ง หรือเลือกสายพันธุ์เอง" }, { status: 502 });
  }
}
