import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  Camera,
  FileBarChart,
  HandHeart,
  LifeBuoy,
  Lock,
  MapPinned,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Syringe,
  Users,
} from "lucide-react";
import { HomeStats, UrgentCases } from "@/components/home/HomeLive";

function HeroMap() {
  // ภาพประกอบแผนที่ความเสี่ยงแบบไฟจราจร (วาดด้วย SVG)
  const dots = [
    { x: 118, y: 92, r: 30, c: "#16A34A" },
    { x: 212, y: 150, r: 22, c: "#EAB308" },
    { x: 300, y: 88, r: 18, c: "#16A34A" },
    { x: 332, y: 214, r: 34, c: "#DC2626" },
    { x: 150, y: 236, r: 20, c: "#EAB308" },
    { x: 246, y: 292, r: 16, c: "#16A34A" },
    { x: 84, y: 178, r: 14, c: "#DC2626" },
  ];
  return (
    <div className="relative">
      <div className="overflow-hidden rounded-[28px] border border-line bg-white p-3 shadow-[0_20px_60px_-20px_rgba(29,43,58,0.25)]">
        <svg viewBox="0 0 420 360" className="w-full rounded-[20px] bg-[#EEF2EC]">
          <path d="M0 250 C 80 220, 120 300, 210 270 S 340 300, 420 250 L420 360 L0 360Z" fill="#DCE8E2" />
          <path d="M-10 120 C 90 140, 150 60, 250 110 S 380 60, 430 120" stroke="#C9DCEB" strokeWidth="14" fill="none" strokeLinecap="round" />
          <path d="M40 0 L 110 360" stroke="#fff" strokeWidth="7" />
          <path d="M0 200 L 420 170" stroke="#fff" strokeWidth="6" />
          <path d="M270 0 L 230 360" stroke="#fff" strokeWidth="5" />
          <path d="M360 0 C 330 120, 400 220, 350 360" stroke="#fff" strokeWidth="4" fill="none" />
          {dots.map((d, i) => (
            <g key={i}>
              <circle cx={d.x} cy={d.y} r={d.r + 8} fill={d.c} opacity="0.18" />
              <circle cx={d.x} cy={d.y} r={d.r} fill={d.c} opacity="0.85" stroke="#fff" strokeWidth="3" />
            </g>
          ))}
        </svg>
      </div>
      <div className="absolute -bottom-6 -left-4 w-56 rounded-2xl border border-line bg-white p-4 shadow-lg sm:-left-8">
        <p className="text-xs text-muted">ตัวอย่างการแสดงผล · ระดับตำบล</p>
        <div className="mt-1 flex items-center gap-2">
          <span className="size-2.5 rounded-full bg-safe" />
          <span className="font-semibold">ปลอดภัย</span>
          <span className="ml-auto text-lg font-bold">วัคซีน 83%</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-sand">
          <div className="h-full w-[83%] rounded-full bg-safe" />
        </div>
      </div>
      <div className="absolute -right-2 -top-5 rounded-2xl border border-line bg-white px-4 py-3 shadow-lg sm:-right-6">
        <p className="flex items-center gap-1.5 text-xs font-semibold text-violet-700">
          <Sparkles className="size-3.5" /> AI วิเคราะห์สายพันธุ์
        </p>
        <p className="mt-0.5 text-sm">
          บางแก้ว <b>62%</b> · ไทย <b>38%</b>
        </p>
      </div>
    </div>
  );
}

const FEATURES = [
  { icon: <Camera className="size-5" />, t: "ทะเบียนสัตว์ละเอียด", d: "รูปถ่าย วันเกิดแน่นอนหรือโดยประมาณ วัคซีน ทำหมัน นิสัย แก้ไขได้ตลอด" },
  { icon: <Sparkles className="size-5" />, t: "AI เดาสายพันธุ์จากรูป", d: "แนบรูปแล้วระบบวิเคราะห์เป็นเปอร์เซ็นต์ กรอกให้อัตโนมัติ แก้ได้ถ้าไม่ตรง" },
  { icon: <MapPinned className="size-5" />, t: "แผนที่ความเสี่ยงสีจราจร", d: "พิษสุนัขบ้า ไข้หัด ประชากรล้น ดูได้ทุกจังหวัด ถึงระดับตำบล" },
  { icon: <LifeBuoy className="size-5" />, t: "แจ้งเคส ส่งต่อหน่วยงาน", d: "แอดมินตรวจสอบ ให้คะแนนเร่งด่วน แล้วส่งต่อ อบต./เทศบาล/ปศุสัตว์ในพื้นที่" },
  { icon: <HandHeart className="size-5" />, t: "บริจาคตรงเคส โปร่งใส", d: "เปิดรับเฉพาะเคสที่ประเมินแล้วว่าเร่งด่วน ตรวจสลิปทุกยอด มีไทม์ไลน์ให้ดู" },
  { icon: <ShoppingBag className="size-5" />, t: "ร้านค้าเพื่อน้อง", d: "ซื้ออาหาร เวชภัณฑ์ ของที่ระลึก ส่งถึงบ้าน หรือบริจาคให้โครงการ" },
];

export default function Home() {
  return (
    <>
      <section className="mx-auto grid max-w-6xl items-center gap-14 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:pt-20">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1 text-sm font-medium text-ink-soft">
            <span className="size-2 rounded-full bg-safe" /> ข้อมูลสัตว์ชุมชน คำนวณได้ทั่วประเทศ
          </p>
          <h1 className="mt-5 text-4xl font-bold leading-[1.15] tracking-tight sm:text-5xl">
            รู้ว่าน้องหมาแมวในชุมชน
            <br />
            <span className="text-brand">ปลอดภัยแค่ไหน</span> ในแผนที่เดียว
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-soft">
            ลงทะเบียนสัตว์เลี้ยงและสัตว์จร บันทึกวัคซีนและการทำหมัน แล้วระบบจะคำนวณความเสี่ยงโรคของแต่ละพื้นที่
            เป็นสีเขียว เหลือง แดง — พร้อมรายงานสำหรับเสนอ อบต. และเทศบาล
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/animals/new" className="inline-flex h-12 items-center gap-2 rounded-xl bg-ink px-6 font-semibold text-white hover:bg-ink-soft">
              ลงทะเบียนสัตว์ <ArrowRight className="size-4" />
            </Link>
            <Link href="/map" className="inline-flex h-12 items-center gap-2 rounded-xl border border-line bg-white px-6 font-semibold hover:bg-sand">
              <MapPinned className="size-4" /> ดูแผนที่ความเสี่ยง
            </Link>
          </div>
          <p className="mt-6 flex items-center gap-2 text-sm text-muted">
            <Lock className="size-4" /> ข้อมูลรายตัวเห็นเฉพาะเจ้าของและผู้ดูแลระบบ
          </p>
        </div>
        <div className="px-4 sm:px-8">
          <HeroMap />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6">
        <HomeStats />
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold text-brand-dark">ทำอะไรได้บ้าง</p>
          <h2 className="mt-1 text-2xl font-bold sm:text-3xl">ตั้งแต่ลงทะเบียน จนถึงช่วยเหลือจริงในพื้นที่</h2>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.t} className="rounded-2xl border border-line bg-white p-6">
              <div className="grid size-11 place-items-center rounded-xl bg-brand-soft text-brand-dark">{f.icon}</div>
              <p className="mt-4 text-lg font-semibold">{f.t}</p>
              <p className="mt-1.5 text-[15px] leading-relaxed text-muted">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-sm font-semibold text-brand-dark">ขั้นตอนการช่วยเหลือ</p>
          <h2 className="mt-1 text-2xl font-bold sm:text-3xl">เคสหนึ่งเคส ผ่านมือใครบ้าง</h2>
          <ol className="mt-10 grid gap-6 md:grid-cols-4">
            {[
              { n: "1", t: "ประชาชนแจ้งเคส", d: "ถ่ายรูป ปักหมุด ระบุความใกล้ชุมชน ความก้าวร้าว และวัคซีน" },
              { n: "2", t: "ระบบให้คะแนน", d: "ใกล้ชุมชน 40% + ความก้าวร้าว 30% + ไม่ได้วัคซีน 30%" },
              { n: "3", t: "แอดมินตรวจสอบ", d: "ยืนยันข้อมูล ส่งต่อหน่วยงานในพื้นที่ และเปิดรับบริจาคหากเร่งด่วน" },
              { n: "4", t: "อาสาลงพื้นที่", d: "อาสาที่ผ่านการอบรมรับเคส อัปเดตความคืบหน้าจนปิดเคส" },
            ].map((s) => (
              <li key={s.n} className="relative rounded-2xl bg-cream p-6">
                <span className="grid size-9 place-items-center rounded-full bg-ink text-sm font-bold text-white">{s.n}</span>
                <p className="mt-4 font-semibold">{s.t}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted">{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <UrgentCases />

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="grid items-center gap-10 overflow-hidden rounded-[28px] bg-ink p-8 text-white sm:p-12 lg:grid-cols-2">
          <div>
            <p className="inline-flex items-center gap-2 text-sm font-semibold text-brand">
              <Building2 className="size-4" /> สำหรับ อบต. / เทศบาล / ปศุสัตว์
            </p>
            <h2 className="mt-3 text-2xl font-bold leading-snug sm:text-3xl">รายงานพร้อมใช้ เสนอโครงการวัคซีนและทำหมันได้ทันที</h2>
            <p className="mt-4 leading-relaxed text-white/75">
              เลือกจังหวัด อำเภอ ตำบล ระบบสรุปจำนวนสัตว์ ความครอบคลุมวัคซีน จำนวนที่ต้องฉีดเพิ่มเพื่อถึงเป้าหมาย 70%
              และพื้นที่เสี่ยงสูงที่ควรลงก่อน — พิมพ์เป็น PDF หรือดาวน์โหลด Excel
            </p>
            <Link href="/report" className="mt-7 inline-flex h-12 items-center gap-2 rounded-xl bg-brand px-6 font-semibold text-white hover:bg-brand-dark">
              <FileBarChart className="size-4" /> สร้างรายงานพื้นที่
            </Link>
          </div>
          <div className="rounded-2xl bg-white p-5 text-ink">
            <p className="text-xs text-muted">รายงาน · อำเภอเมือง (ตัวอย่าง)</p>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              {[
                { v: "203", l: "ตัว" },
                { v: "61%", l: "วัคซีน" },
                { v: "38%", l: "ทำหมัน" },
              ].map((x) => (
                <div key={x.l} className="rounded-xl bg-sand p-3">
                  <p className="text-xl font-bold">{x.v}</p>
                  <p className="text-xs text-muted">{x.l}</p>
                </div>
              ))}
            </div>
            <ul className="mt-4 space-y-2 text-sm">
              {[
                { c: "#DC2626", t: "ต.ตะเบาะ", v: "เสี่ยงสูง 79%" },
                { c: "#DC2626", t: "ต.นางั่ว", v: "เสี่ยงสูง 72%" },
                { c: "#EAB308", t: "ต.บ้านโตก", v: "เฝ้าระวัง 48%" },
                { c: "#16A34A", t: "ต.ในเมือง", v: "ปลอดภัย 21%" },
              ].map((r) => (
                <li key={r.t} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2">
                  <span className="size-2.5 rounded-full" style={{ background: r.c }} />
                  {r.t}
                  <span className="ml-auto font-semibold">{r.v}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 rounded-lg bg-brand-soft px-3 py-2 text-sm text-brand-dark">
              ต้องฉีดวัคซีนพิษสุนัขบ้าเพิ่มอย่างน้อย <b>19 ตัว</b> เพื่อถึงเป้าหมาย 70%
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-8 pt-4 sm:px-6">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: <ShieldCheck className="size-5" />, t: "ความเป็นส่วนตัว", d: "สาธารณะเห็นเพียงตัวเลขรวมของพื้นที่ ข้อมูลรายตัวและเบอร์โทรไม่ถูกเปิดเผย" },
            { icon: <BadgeCheck className="size-5" />, t: "อาสาผ่านการอบรม", d: "เรียน 5 บท ทำแบบทดสอบ และแอดมินอนุมัติ ก่อนรับเคสลงพื้นที่" },
            { icon: <Syringe className="size-5" />, t: "ใช้เกณฑ์ที่ตรวจสอบได้", d: "เป้าหมายวัคซีนพิษสุนัขบ้า 70% ของประชากรสุนัข ตามแนวทางควบคุมโรคในชุมชน" },
          ].map((x) => (
            <div key={x.t} className="flex gap-4 rounded-2xl border border-line bg-white p-5">
              <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-sand">{x.icon}</div>
              <div>
                <p className="font-semibold">{x.t}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted">{x.d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="flex flex-col items-center rounded-[28px] border border-line bg-brand-soft px-6 py-14 text-center">
          <Users className="size-10 text-brand-dark" />
          <h2 className="mt-4 text-2xl font-bold sm:text-3xl">ร่วมเป็นส่วนหนึ่งของ Me Dog</h2>
          <p className="mt-3 max-w-xl text-ink-soft">สมัครอาสา ลงทะเบียนน้องในซอยบ้านคุณ หรือสนับสนุนเคสเร่งด่วน — ทุกข้อมูลช่วยให้ชุมชนปลอดภัยขึ้น</p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/volunteer" className="inline-flex h-12 items-center rounded-xl bg-ink px-6 font-semibold text-white hover:bg-ink-soft">
              สมัครอาสาสมัคร
            </Link>
            <Link href="/donate" className="inline-flex h-12 items-center rounded-xl bg-brand px-6 font-semibold text-white hover:bg-brand-dark">
              บริจาคช่วยน้อง
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
