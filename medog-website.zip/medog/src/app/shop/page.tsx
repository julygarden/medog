"use client";

import { CheckCircle2, Minus, Package, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { ProductArt } from "@/components/ProductArt";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { PromptPayBox } from "@/components/payment/PromptPayBox";
import { SlipInput, uploadSlip } from "@/components/payment/SlipInput";
import { Alert, Badge, Button, Card, Container, Empty, Field, Input, LinkButton, Modal, PageHeader, Segmented, Spinner, Textarea } from "@/components/ui";
import { PRODUCT_CATEGORY } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Product } from "@/lib/types";
import { baht } from "@/lib/utils";

type Cart = Record<string, number>;
const CART_KEY = "medog-cart";

export default function ShopPage() {
  const { user, profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [cat, setCat] = useState<"all" | Product["category"]>("all");
  const [cart, setCart] = useState<Cart>({});
  const [checkout, setCheckout] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CART_KEY);
      if (saved) setCart(JSON.parse(saved));
    } catch {}
    if (!isConfigured) return;
    supabase
      .from("products")
      .select("*")
      .eq("is_active", true)
      .order("sort")
      .then(({ data }) => {
        setProducts((data as Product[]) ?? []);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {}
  }, [cart]);

  const lines = useMemo(
    () => products.filter((p) => cart[p.id]).map((p) => ({ p, qty: cart[p.id] })),
    [products, cart],
  );
  const total = lines.reduce((s, l) => s + l.p.price * l.qty, 0);
  const count = lines.reduce((s, l) => s + l.qty, 0);

  const setQty = (id: string, q: number) =>
    setCart((c) => {
      const n = { ...c };
      if (q <= 0) delete n[id];
      else n[id] = Math.min(99, q);
      return n;
    });

  const shown = products.filter((p) => cat === "all" || p.category === cat);

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="ร้านค้าเพื่อน้อง"
        title="ซื้อของ = ช่วยน้อง"
        desc="เลือกซื้ออาหาร เวชภัณฑ์ หรือของที่ระลึก ส่งถึงบ้านคุณ หรือเลือก “บริจาคให้โครงการ” ทีมงานจะนำไปใช้กับสัตว์ชุมชนในพื้นที่เสี่ยง"
      />

      <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
        <div>
          <Segmented
            className="mb-5"
            value={cat}
            onChange={setCat}
            options={[{ value: "all", label: "ทั้งหมด" }, ...Object.entries(PRODUCT_CATEGORY).map(([value, label]) => ({ value: value as Product["category"], label }))]}
          />
          {loading ? (
            <Spinner />
          ) : shown.length === 0 ? (
            <Empty icon={<Package className="size-6" />} title="ยังไม่มีสินค้า" desc="แอดมินเพิ่มสินค้าได้ที่ ระบบแอดมิน → สินค้า" />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {shown.map((p) => {
                const soldOut = p.stock !== null && p.stock <= 0;
                return (
                  <Card key={p.id} className="flex flex-col overflow-hidden">
                    {p.image_url ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image_url} alt={p.name} className="aspect-square w-full object-cover" />
                    ) : (
                      <ProductArt category={p.category} className="aspect-square w-full" />
                    )}
                    <div className="flex flex-1 flex-col p-4">
                      <Badge tone="gray" className="self-start">{PRODUCT_CATEGORY[p.category]}</Badge>
                      <p className="mt-2 font-semibold leading-snug">{p.name}</p>
                      {p.description && <p className="mt-1 line-clamp-2 text-sm text-muted">{p.description}</p>}
                      {p.impact_note && (
                        <p className="mt-2 rounded-lg bg-green-50 px-2.5 py-1.5 text-xs font-medium text-green-800">{p.impact_note}</p>
                      )}
                      <div className="mt-auto flex items-center justify-between pt-4">
                        <p className="text-lg font-bold">{baht(p.price)}</p>
                        {soldOut ? (
                          <Badge tone="gray">หมด</Badge>
                        ) : cart[p.id] ? (
                          <div className="flex items-center gap-1">
                            <button onClick={() => setQty(p.id, cart[p.id] - 1)} className="grid size-8 place-items-center rounded-lg border border-line" aria-label="ลด">
                              <Minus className="size-4" />
                            </button>
                            <span className="w-7 text-center font-semibold tabular-nums">{cart[p.id]}</span>
                            <button onClick={() => setQty(p.id, cart[p.id] + 1)} className="grid size-8 place-items-center rounded-lg border border-line" aria-label="เพิ่ม">
                              <Plus className="size-4" />
                            </button>
                          </div>
                        ) : (
                          <Button size="sm" onClick={() => setQty(p.id, 1)}>
                            <Plus className="size-4" /> ใส่ตะกร้า
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        <Card className="h-fit p-5 lg:sticky lg:top-20">
          <p className="flex items-center gap-2 text-lg font-semibold">
            <ShoppingBag className="size-5" /> ตะกร้า {count > 0 && <span className="text-muted">({count})</span>}
          </p>
          {lines.length === 0 ? (
            <p className="mt-3 text-sm text-muted">ยังไม่มีสินค้าในตะกร้า</p>
          ) : (
            <>
              <ul className="mt-4 space-y-3">
                {lines.map(({ p, qty }) => (
                  <li key={p.id} className="flex items-start justify-between gap-3 text-sm">
                    <div>
                      <p className="font-medium leading-snug">{p.name}</p>
                      <p className="text-muted">
                        {qty} × {baht(p.price)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold tabular-nums">{baht(p.price * qty)}</span>
                      <button onClick={() => setQty(p.id, 0)} className="text-muted hover:text-red-700" aria-label="ลบ">
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex justify-between border-t border-line pt-4 text-lg font-bold">
                <span>รวม</span>
                <span>{baht(total)}</span>
              </div>
              {user ? (
                <Button className="mt-4 w-full" variant="brand" size="lg" onClick={() => setCheckout(true)}>
                  สั่งซื้อ
                </Button>
              ) : (
                <LinkButton href="/login?next=/shop" className="mt-4 w-full" size="lg">
                  เข้าสู่ระบบเพื่อสั่งซื้อ
                </LinkButton>
              )}
            </>
          )}
        </Card>
      </div>

      <Checkout
        open={checkout}
        onClose={() => setCheckout(false)}
        lines={lines}
        total={total}
        defaultName={profile?.display_name ?? ""}
        defaultPhone={profile?.phone ?? ""}
        userId={user?.id ?? ""}
        onPlaced={() => setCart({})}
      />
    </Container>
  );
}

function Checkout({
  open,
  onClose,
  lines,
  total,
  defaultName,
  defaultPhone,
  userId,
  onPlaced,
}: {
  open: boolean;
  onClose: () => void;
  lines: { p: Product; qty: number }[];
  total: number;
  defaultName: string;
  defaultPhone: string;
  userId: string;
  onPlaced: () => void;
}) {
  const [delivery, setDelivery] = useState<"donate" | "ship">("donate");
  const [ship, setShip] = useState({ name: "", phone: "", address: "" });
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderTotal, setOrderTotal] = useState(0);
  const [slip, setSlip] = useState<Blob | null>(null);
  const [step, setStep] = useState<"info" | "pay" | "done">("info");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open && step === "info") setShip((s) => ({ ...s, name: s.name || defaultName, phone: s.phone || defaultPhone }));
  }, [open, step, defaultName, defaultPhone]);

  const close = () => {
    onClose();
    if (step === "done") {
      setStep("info");
      setOrderId(null);
      setSlip(null);
    }
  };

  const place = async () => {
    setErr("");
    setBusy(true);
    const { data, error } = await supabase.rpc("create_order", {
      p_items: lines.map((l) => ({ product_id: l.p.id, qty: l.qty })),
      p_delivery: delivery,
      p_ship_name: ship.name,
      p_ship_phone: ship.phone,
      p_ship_address: delivery === "ship" ? ship.address : null,
    });
    setBusy(false);
    if (error) return setErr(errorText(error));
    setOrderId(data as string);
    setOrderTotal(total);
    onPlaced();
    setStep("pay");
  };

  const pay = async () => {
    if (!slip || !orderId) return setErr("กรุณาแนบสลิป");
    setErr("");
    setBusy(true);
    try {
      const path = await uploadSlip(slip, userId);
      const { error } = await supabase.rpc("attach_order_slip", { p_order: orderId, p_path: path });
      if (error) throw error;
      setStep("done");
    } catch (e) {
      setErr(errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={close} title={step === "pay" ? "ชำระเงิน" : step === "done" ? "สั่งซื้อสำเร็จ" : "ยืนยันคำสั่งซื้อ"}>
      {step === "info" && (
        <div className="space-y-4">
          <Field label="รูปแบบการรับสินค้า">
            <Segmented
              value={delivery}
              onChange={setDelivery}
              options={{ donate: "บริจาคให้โครงการ (ไม่ต้องจัดส่ง)", ship: "ส่งถึงบ้านฉัน" }}
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="ชื่อผู้สั่งซื้อ" required={delivery === "ship"}>
              <Input value={ship.name} onChange={(e) => setShip({ ...ship, name: e.target.value })} />
            </Field>
            <Field label="เบอร์โทร">
              <Input type="tel" value={ship.phone} onChange={(e) => setShip({ ...ship, phone: e.target.value })} />
            </Field>
          </div>
          {delivery === "ship" && (
            <Field label="ที่อยู่จัดส่ง" required>
              <Textarea value={ship.address} onChange={(e) => setShip({ ...ship, address: e.target.value })} />
            </Field>
          )}
          <div className="flex justify-between rounded-xl bg-sand px-4 py-3 font-semibold">
            <span>ยอดชำระ</span>
            <span>{baht(total)}</span>
          </div>
          {!isConfigured && <Alert tone="amber">ยังไม่ได้เชื่อมฐานข้อมูล</Alert>}
          {err && <Alert tone="red">{err}</Alert>}
          <Button className="w-full" size="lg" onClick={place} loading={busy} disabled={!isConfigured || lines.length === 0}>
            ยืนยันและไปชำระเงิน
          </Button>
        </div>
      )}
      {step === "pay" && (
        <div className="space-y-4">
          <PromptPayBox amount={orderTotal} />
          <Field label="แนบสลิป" required>
            <SlipInput file={slip} onChange={setSlip} />
          </Field>
          {err && <Alert tone="red">{err}</Alert>}
          <Button className="w-full" size="lg" variant="brand" onClick={pay} loading={busy}>
            ส่งสลิป
          </Button>
          <p className="text-center text-xs text-muted">ชำระภายหลังได้ที่ บัญชีของฉัน → คำสั่งซื้อ</p>
        </div>
      )}
      {step === "done" && (
        <div className="flex flex-col items-center py-4 text-center">
          <CheckCircle2 className="size-12 text-safe" />
          <p className="mt-3 text-lg font-semibold">ขอบคุณที่ช่วยน้อง!</p>
          <p className="mt-1 text-sm text-muted">
            แอดมินจะตรวจสลิปและอัปเดตสถานะ ติดตามได้ที่{" "}
            <Link href="/account" className="font-medium text-ink underline">บัญชีของฉัน</Link>
          </p>
        </div>
      )}
    </Modal>
  );
}
