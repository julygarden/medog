"use client";

import dynamic from "next/dynamic";
import { Info, MapPinned } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useThaiAddress } from "@/components/AddressSelect";
import { AreaDetail } from "@/components/map/AreaDetail";
import { Card, Container, Empty, LinkButton, PageHeader, Segmented, Select } from "@/components/ui";
import { DISEASES, type Disease, LEVEL_META, type RiskLevel, areaName, levelOf, riskOf } from "@/lib/risk";
import { isConfigured, supabase } from "@/lib/supabase";
import type { AreaStat } from "@/lib/types";
import { cls } from "@/lib/utils";

const RiskMapInner = dynamic(() => import("@/components/map/RiskMapInner"), {
  ssr: false,
  loading: () => <div className="grid h-full place-items-center bg-sand text-sm text-muted">กำลังโหลดแผนที่…</div>,
});

type Level = "province" | "amphoe" | "tambon";

export default function MapPage() {
  const tree = useThaiAddress();
  const [disease, setDisease] = useState<Disease>("overall");
  const [level, setLevel] = useState<Level>("tambon");
  const [province, setProvince] = useState("");
  const [stats, setStats] = useState<AreaStat[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [selected, setSelected] = useState<AreaStat | null>(null);

  useEffect(() => {
    if (!isConfigured) return;
    setLoading(true);
    supabase
      .rpc("area_stats", { p_level: level, p_province: province || null })
      .then(({ data }) => {
        setStats((data as AreaStat[]) ?? []);
        setSelected(null);
        setLoading(false);
      });
  }, [level, province]);

  const ranked = useMemo(
    () =>
      stats
        .map((s) => ({ s, ...riskOf(s, disease) }))
        .map((x) => ({ ...x, level: levelOf(x.risk, x.n) }))
        .sort(
          (a, b) =>
            (a.level === "nodata" ? 1 : 0) - (b.level === "nodata" ? 1 : 0) || (b.risk ?? -1) - (a.risk ?? -1),
        ),
    [stats, disease],
  );

  const counts = ranked.reduce(
    (acc, x) => ({ ...acc, [x.level]: (acc[x.level] ?? 0) + 1 }),
    {} as Partial<Record<RiskLevel, number>>,
  );
  const dz = DISEASES.find((d) => d.key === disease)!;

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="แผนที่ความเสี่ยงโรค"
        title="พื้นที่ไหนปลอดภัย พื้นที่ไหนต้องเร่งช่วย"
        desc="คำนวณจากข้อมูลสัตว์ที่ลงทะเบียนในแต่ละพื้นที่ทั่วประเทศ สีเหมือนไฟจราจร: เขียว = ปลอดภัย, เหลือง = เฝ้าระวัง, แดง = เสี่ยงสูง"
      />

      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <Segmented
          value={disease}
          onChange={setDisease}
          options={DISEASES.map((d) => ({ value: d.key, label: d.label }))}
        />
        <div className="flex gap-2">
          <Select
            value={level}
            onChange={(e) => setLevel(e.target.value as Level)}
            options={{ province: "ระดับจังหวัด", amphoe: "ระดับอำเภอ", tambon: "ระดับตำบล" }}
            className="w-40"
          />
          <Select
            value={province}
            onChange={(e) => setProvince(e.target.value)}
            placeholder="ทั่วประเทศ"
            options={(tree ? Object.keys(tree) : []).map((p) => ({ value: p, label: p }))}
            className="w-44"
          />
        </div>
      </div>

      <p className="mb-4 flex items-start gap-1.5 text-sm text-muted">
        <Info className="mt-0.5 size-4 shrink-0" /> {dz.desc}
      </p>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card className="relative h-[480px] overflow-hidden lg:h-[600px]">
          <RiskMapInner
            stats={stats}
            disease={disease}
            selected={selected}
            onSelect={setSelected}
            label={areaName}
          />
          <div className="pointer-events-none absolute bottom-3 left-3 z-[400] rounded-xl border border-line bg-white/95 px-3 py-2 text-xs shadow-sm">
            {(["safe", "watch", "high", "nodata"] as RiskLevel[]).map((l) => (
              <div key={l} className="flex items-center gap-2 py-0.5">
                <span className="size-2.5 rounded-full" style={{ background: LEVEL_META[l].color }} />
                {LEVEL_META[l].label}
                <span className="text-muted">
                  {l === "safe" ? "≤30%" : l === "watch" ? "31–60%" : l === "high" ? ">60%" : "<3 ตัว"}
                </span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          {selected ? (
            <AreaDetail s={selected} disease={disease} />
          ) : (
            <div>
              <p className="font-semibold">สรุปภาพรวม</p>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                {(["high", "watch", "safe"] as RiskLevel[]).map((l) => (
                  <div key={l} className="rounded-xl p-3" style={{ background: LEVEL_META[l].soft, color: LEVEL_META[l].text }}>
                    <p className="text-2xl font-bold">{counts[l] ?? 0}</p>
                    <p className="text-xs font-medium">{LEVEL_META[l].label}</p>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-sm text-muted">แตะวงกลมบนแผนที่ หรือเลือกจากรายการด้านล่างเพื่อดูรายละเอียดพื้นที่</p>
              <ul className="mt-4 max-h-[380px] space-y-1 overflow-y-auto pr-1">
                {ranked.map(({ s, risk, n, level: l }) => (
                  <li key={areaName(s)}>
                    <button
                      onClick={() => setSelected(s)}
                      className="flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left text-sm hover:bg-sand"
                    >
                      <span className="size-2.5 shrink-0 rounded-full" style={{ background: LEVEL_META[l].color }} />
                      <span className="flex-1 truncate">{s.tambon ?? s.amphoe ?? s.province}</span>
                      <span className={cls("tabular-nums", l === "nodata" ? "text-muted" : "font-semibold")}>
                        {risk !== null && n >= 3 ? `${Math.round(risk)}%` : "–"}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {selected && (
            <button onClick={() => setSelected(null)} className="mt-3 w-full text-center text-sm text-muted hover:text-ink">
              ← กลับไปภาพรวม
            </button>
          )}
        </Card>
      </div>

      {!loading && stats.length === 0 && (
        <div className="mt-6">
          <Empty
            icon={<MapPinned className="size-6" />}
            title="ยังไม่มีข้อมูลในพื้นที่นี้"
            desc="เมื่อมีคนลงทะเบียนสัตว์ในพื้นที่ แผนที่จะแสดงระดับความเสี่ยงให้อัตโนมัติ"
            action={<LinkButton href="/animals/new">ลงทะเบียนสัตว์ในพื้นที่ของคุณ</LinkButton>}
          />
        </div>
      )}
    </Container>
  );
}
