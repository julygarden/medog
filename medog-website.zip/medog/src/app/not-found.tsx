import Link from "next/link";
import { NoseMark } from "@/components/Logo";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
      <NoseMark size={56} />
      <h1 className="mt-5 text-2xl font-bold">ดมหาแล้ว ไม่เจอหน้านี้</h1>
      <p className="mt-2 text-muted">ลิงก์อาจไม่ถูกต้อง หรือหน้านี้ถูกย้ายไปแล้ว</p>
      <Link href="/" className="mt-6 inline-flex h-11 items-center rounded-xl bg-ink px-5 font-semibold text-white">
        กลับหน้าแรก
      </Link>
    </div>
  );
}
