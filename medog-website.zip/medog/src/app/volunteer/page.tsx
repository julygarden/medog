"use client";

import { Award, BookOpen, CheckCircle2, ChevronDown, ClipboardCheck, Clock, GraduationCap, ShieldCheck, XCircle } from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { AddressSelect } from "@/components/AddressSelect";
import { useAuth } from "@/components/AuthProvider";
import { Alert, Badge, Button, Card, Container, Field, Input, LinkButton, PageHeader, Section, Textarea } from "@/components/ui";
import { VOLUNTEER_SKILLS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import { LESSONS, PASS_SCORE, QUIZ } from "@/lib/training";
import type { VolunteerApplication } from "@/lib/types";
import { cls, formatDate } from "@/lib/utils";

export default function VolunteerPage() {
  const { user, profile, isVolunteer, refreshProfile } = useAuth();
  const [app, setApp] = useState<VolunteerApplication | null>(null);
  const [openLesson, setOpenLesson] = useState<number | null>(0);
  const [read, setRead] = useState<Set<number>>(new Set([0]));

  const load = useCallback(async () => {
    if (!isConfigured || !user) return;
    const { data } = await supabase.from("volunteer_applications").select("*").eq("user_id", user.id).maybeSingle();
    setApp(data as VolunteerApplication | null);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const allRead = read.size === LESSONS.length;
  const passed = Boolean(app?.quiz_passed_at);

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="อาสาสมัคร Me Dog"
        title="อาสาที่ผ่านการอบรม — เพื่อความเชื่อมั่นของชุมชน"
        desc="อาสาทุกคนต้องเรียนบทเรียนพื้นฐาน ผ่านแบบทดสอบ และได้รับการอนุมัติจากแอดมิน ก่อนรับเคสลงพื้นที่"
      />

      <div className="mb-10 grid gap-3 sm:grid-cols-4">
        {[
          { icon: <BookOpen className="size-5" />, t: "เรียน 5 บทเรียน", done: allRead || passed },
          { icon: <ClipboardCheck className="size-5" />, t: `แบบทดสอบ ผ่าน ${PASS_SCORE}/10`, done: passed },
          { icon: <GraduationCap className="size-5" />, t: "กรอกใบสมัคร", done: app?.status === "pending" || app?.status === "approved" },
          { icon: <Award className="size-5" />, t: "แอดมินอนุมัติ", done: isVolunteer },
        ].map((s, i) => (
          <Card key={s.t} className={cls("flex items-center gap-3 p-4", s.done && "border-green-200 bg-green-50/60")}>
            <div className={cls("grid size-10 shrink-0 place-items-center rounded-xl", s.done ? "bg-safe text-white" : "bg-sand text-muted")}>
              {s.done ? <CheckCircle2 className="size-5" /> : s.icon}
            </div>
            <div>
              <p className="text-xs text-muted">ขั้นที่ {i + 1}</p>
              <p className="text-sm font-semibold">{s.t}</p>
            </div>
          </Card>
        ))}
      </div>

      {isVolunteer && (
        <Alert tone="green" className="mb-8" title="คุณเป็นอาสาสมัคร Me Dog แล้ว">
          ไปที่ <Link href="/cases" className="font-semibold underline">เคสช่วยเหลือ</Link> เพื่อรับเคสในพื้นที่ของคุณ
        </Alert>
      )}

      <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
        <Section title="บทเรียนพื้นฐาน" desc="อ่านให้ครบทุกบทก่อนทำแบบทดสอบ" icon={<BookOpen className="size-5" />}>
          <div className="space-y-2">
            {LESSONS.map((l, i) => (
              <div key={l.title} className="overflow-hidden rounded-xl border border-line">
                <button
                  className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left font-medium hover:bg-sand"
                  onClick={() => {
                    setOpenLesson(openLesson === i ? null : i);
                    setRead((r) => new Set(r).add(i));
                  }}
                >
                  <span className="flex items-center gap-2">
                    {read.has(i) ? <CheckCircle2 className="size-4 text-safe" /> : <span className="size-4 rounded-full border-2 border-line" />}
                    {l.title}
                  </span>
                  <ChevronDown className={cls("size-4 text-muted transition", openLesson === i && "rotate-180")} />
                </button>
                {openLesson === i && (
                  <ul className="space-y-2 border-t border-line bg-cream px-5 py-4 text-sm leading-relaxed">
                    {l.points.map((p) => (
                      <li key={p} className="flex gap-2">
                        <span className="mt-2 size-1.5 shrink-0 rounded-full bg-brand" />
                        {p}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </Section>

        <div className="space-y-8">
          {!user ? (
            <Card className="p-6 text-center">
              <ShieldCheck className="mx-auto size-10 text-brand" />
              <p className="mt-3 font-semibold">เข้าสู่ระบบเพื่อทำแบบทดสอบและสมัครอาสา</p>
              <LinkButton href="/login?next=/volunteer" className="mt-4">เข้าสู่ระบบ</LinkButton>
            </Card>
          ) : passed ? (
            <ApplicationPanel app={app} profileName={profile?.display_name ?? ""} onSaved={async () => { await load(); await refreshProfile(); }} />
          ) : (
            <QuizPanel enabled={allRead} lastScore={app?.quiz_score ?? null} onDone={load} />
          )}
        </div>
      </div>
    </Container>
  );
}

function QuizPanel({ enabled, lastScore, onDone }: { enabled: boolean; lastScore: number | null; onDone: () => void }) {
  const [answers, setAnswers] = useState<(number | null)[]>(Array(QUIZ.length).fill(null));
  const [busy, setBusy] = useState(false);
  const [score, setScore] = useState<number | null>(null);
  const [err, setErr] = useState("");

  const submit = async () => {
    if (answers.some((a) => a === null)) return setErr("กรุณาตอบให้ครบทุกข้อ");
    setErr("");
    setBusy(true);
    const { data, error } = await supabase.rpc("submit_volunteer_quiz", { answers });
    setBusy(false);
    if (error) return setErr(errorText(error));
    setScore(Number(data));
    if (Number(data) >= PASS_SCORE) setTimeout(onDone, 1200);
  };

  return (
    <Section title="แบบทดสอบ" desc={`10 ข้อ ต้องได้อย่างน้อย ${PASS_SCORE} คะแนน ทำซ้ำได้ไม่จำกัด`} icon={<ClipboardCheck className="size-5" />}>
      {!enabled && <Alert tone="amber" className="mb-4">เปิดอ่านบทเรียนให้ครบทั้ง 5 บทก่อน</Alert>}
      {lastScore !== null && score === null && <p className="mb-4 text-sm text-muted">ครั้งล่าสุดได้ {lastScore}/10</p>}
      <ol className={cls("space-y-5", !enabled && "pointer-events-none opacity-50")}>
        {QUIZ.map((q, i) => (
          <li key={i}>
            <p className="mb-2 text-sm font-semibold">
              {i + 1}. {q.q}
            </p>
            <div className="space-y-1.5">
              {q.choices.map((c, j) => (
                <label
                  key={j}
                  className={cls(
                    "flex cursor-pointer items-start gap-2.5 rounded-xl border px-3 py-2 text-sm",
                    answers[i] === j ? "border-ink bg-sand" : "border-line hover:bg-cream",
                  )}
                >
                  <input
                    type="radio"
                    name={`q${i}`}
                    className="mt-1"
                    checked={answers[i] === j}
                    onChange={() => setAnswers((a) => a.map((x, k) => (k === i ? j : x)))}
                  />
                  {c}
                </label>
              ))}
            </div>
          </li>
        ))}
      </ol>
      {err && <Alert tone="red" className="mt-4">{err}</Alert>}
      {score !== null && (
        <Alert tone={score >= PASS_SCORE ? "green" : "red"} className="mt-4" title={`ได้ ${score}/10 คะแนน`}>
          {score >= PASS_SCORE ? "ผ่านแล้ว! กำลังเปิดใบสมัคร…" : "ยังไม่ผ่าน ลองทบทวนบทเรียนแล้วทำใหม่อีกครั้ง"}
        </Alert>
      )}
      <Button className="mt-5 w-full" size="lg" onClick={submit} loading={busy} disabled={!enabled}>
        ส่งคำตอบ
      </Button>
    </Section>
  );
}

function ApplicationPanel({
  app,
  profileName,
  onSaved,
}: {
  app: VolunteerApplication | null;
  profileName: string;
  onSaved: () => void;
}) {
  const [f, setF] = useState({
    full_name: app?.full_name ?? profileName,
    phone: app?.phone ?? "",
    province: app?.province ?? null,
    amphoe: app?.amphoe ?? null,
    skills: app?.skills ?? [],
    motivation: app?.motivation ?? "",
    availability: app?.availability ?? "",
    has_transport: app?.has_transport ?? false,
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [editing, setEditing] = useState(!app || app.status === "draft");

  if (app && !editing) {
    const map = {
      pending: { icon: <Clock className="size-8 text-amber-600" />, t: "ส่งใบสมัครแล้ว รอแอดมินตรวจสอบ", tone: "amber" as const },
      approved: { icon: <Award className="size-8 text-safe" />, t: "อนุมัติแล้ว ยินดีต้อนรับอาสา!", tone: "green" as const },
      rejected: { icon: <XCircle className="size-8 text-red-600" />, t: "ใบสมัครยังไม่ผ่าน", tone: "red" as const },
      draft: { icon: null, t: "", tone: "gray" as const },
    }[app.status];
    return (
      <Card className="p-6">
        <div className="flex items-center gap-3">
          {map.icon}
          <div>
            <p className="font-semibold">{map.t}</p>
            <p className="text-sm text-muted">
              คะแนนแบบทดสอบ {app.quiz_score}/10 · ผ่านเมื่อ {formatDate(app.quiz_passed_at)}
            </p>
          </div>
        </div>
        {app.review_note && <Alert tone={map.tone} className="mt-4">หมายเหตุจากแอดมิน: {app.review_note}</Alert>}
        {app.status !== "approved" && (
          <Button variant="secondary" className="mt-4" onClick={() => setEditing(true)}>
            แก้ไข / ส่งใบสมัครอีกครั้ง
          </Button>
        )}
      </Card>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!f.province) return setErr("กรุณาเลือกจังหวัดที่สะดวกลงพื้นที่");
    setBusy(true);
    const { error } = await supabase.rpc("submit_volunteer_application", {
      p_full_name: f.full_name,
      p_phone: f.phone,
      p_province: f.province,
      p_amphoe: f.amphoe,
      p_skills: f.skills,
      p_motivation: f.motivation,
      p_availability: f.availability,
      p_has_transport: f.has_transport,
    });
    setBusy(false);
    if (error) return setErr(errorText(error));
    setEditing(false);
    onSaved();
  };

  return (
    <Section title="ใบสมัครอาสาสมัคร" desc="ผ่านแบบทดสอบแล้ว! กรอกข้อมูลเพื่อให้แอดมินพิจารณา" icon={<GraduationCap className="size-5" />}>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="ชื่อ-นามสกุล" required>
            <Input required value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
          </Field>
          <Field label="เบอร์โทร" required>
            <Input required type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
          </Field>
        </div>
        <AddressSelect
          level="amphoe"
          className="grid gap-4 sm:grid-cols-2"
          value={{ province: f.province, amphoe: f.amphoe, tambon: null }}
          onChange={(a) => setF({ ...f, province: a.province, amphoe: a.amphoe })}
        />
        <Field label="ทักษะที่ช่วยได้">
          <div className="flex flex-wrap gap-2">
            {Object.entries(VOLUNTEER_SKILLS).map(([k, label]) => {
              const on = f.skills.includes(k);
              return (
                <button
                  type="button"
                  key={k}
                  onClick={() => setF({ ...f, skills: on ? f.skills.filter((s) => s !== k) : [...f.skills, k] })}
                  className={cls("rounded-full border px-3 py-1.5 text-sm", on ? "border-ink bg-ink text-white" : "border-line bg-white hover:bg-sand")}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </Field>
        <Field label="ทำไมถึงอยากเป็นอาสา" required>
          <Textarea required value={f.motivation} onChange={(e) => setF({ ...f, motivation: e.target.value })} />
        </Field>
        <Field label="ช่วงเวลาที่สะดวก">
          <Input value={f.availability} onChange={(e) => setF({ ...f, availability: e.target.value })} placeholder="เช่น เสาร์-อาทิตย์ / หลัง 5 โมงเย็น" />
        </Field>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" className="size-4" checked={f.has_transport} onChange={(e) => setF({ ...f, has_transport: e.target.checked })} />
          มียานพาหนะสำหรับรับ-ส่งสัตว์
        </label>
        {err && <Alert tone="red">{err}</Alert>}
        <Button type="submit" size="lg" className="w-full" loading={busy}>
          ส่งใบสมัคร
        </Button>
        <p className="text-center text-xs text-muted">
          <Badge tone="gray">ความเป็นส่วนตัว</Badge> ข้อมูลใบสมัครเห็นเฉพาะคุณและแอดมิน
        </p>
      </form>
    </Section>
  );
}
