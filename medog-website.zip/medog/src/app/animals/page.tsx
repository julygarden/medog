"use client";

import { PawPrint, Plus, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { AnimalCard } from "@/components/animals/AnimalCard";
import { useAuth } from "@/components/AuthProvider";
import { RequireAuth } from "@/components/RequireAuth";
import { Container, Empty, Input, LinkButton, PageHeader, Segmented, Spinner } from "@/components/ui";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Animal } from "@/lib/types";

export default function AnimalsPage() {
  return (
    <RequireAuth message="เข้าสู่ระบบเพื่อดูและจัดการสัตว์ที่คุณลงทะเบียนไว้">
      <AnimalsList />
    </RequireAuth>
  );
}

function AnimalsList() {
  const { user, isAdmin } = useAuth();
  const [scope, setScope] = useState<"mine" | "all">("mine");
  const [rows, setRows] = useState<Animal[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!isConfigured || !user) return;
    setLoading(true);
    let query = supabase.from("animals").select("*, vaccinations(*)").order("created_at", { ascending: false }).limit(500);
    if (scope === "mine") query = query.eq("owner_id", user.id);
    query.then(({ data }) => {
      setRows((data as Animal[]) ?? []);
      setLoading(false);
    });
  }, [user, scope]);

  const filtered = useMemo(() => {
    const k = q.trim();
    if (!k) return rows;
    return rows.filter((a) =>
      [a.name, a.breed, a.tambon, a.amphoe, a.province, a.microchip].some((x) => x?.includes(k)),
    );
  }, [rows, q]);

  return (
    <Container className="py-10">
      <PageHeader
        eyebrow="ทะเบียนสัตว์"
        title={scope === "mine" ? "สัตว์ที่ฉันลงทะเบียน" : "ทะเบียนสัตว์ทั้งหมด (แอดมิน)"}
        desc="บันทึกสัตว์เลี้ยงของคุณ หรือสัตว์จร/สัตว์ชุมชนที่คุณดูแล ข้อมูลนี้ช่วยคำนวณแผนที่ความเสี่ยงโรคในพื้นที่"
        actions={
          <LinkButton href="/animals/new" variant="brand">
            <Plus className="size-4" /> ลงทะเบียนสัตว์
          </LinkButton>
        }
      />

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {isAdmin ? (
          <Segmented value={scope} onChange={setScope} options={{ mine: "ของฉัน", all: "ทั้งหมดในระบบ" }} />
        ) : (
          <span />
        )}
        <div className="relative sm:w-72">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <Input className="pl-9" placeholder="ค้นหาชื่อ สายพันธุ์ ตำบล" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <Empty
          icon={<PawPrint className="size-6" />}
          title={rows.length ? "ไม่พบรายการที่ค้นหา" : "ยังไม่มีสัตว์ที่ลงทะเบียน"}
          desc="เริ่มจากถ่ายรูปน้อง แล้วกรอกข้อมูลพื้นฐาน ใช้เวลาไม่ถึง 3 นาที"
          action={<LinkButton href="/animals/new">ลงทะเบียนตัวแรก</LinkButton>}
        />
      ) : (
        <>
          <p className="mb-3 text-sm text-muted">{filtered.length} ตัว</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((a) => (
              <AnimalCard key={a.id} a={a} />
            ))}
          </div>
        </>
      )}
    </Container>
  );
}
