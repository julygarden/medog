"use client";

import { AnimalForm } from "@/components/animals/AnimalForm";
import { RequireAuth } from "@/components/RequireAuth";
import { Container, PageHeader } from "@/components/ui";

export default function NewAnimalPage() {
  return (
    <RequireAuth message="เข้าสู่ระบบเพื่อลงทะเบียนสัตว์ คุณจะกลับมาแก้ไขข้อมูลได้ตลอด">
      <Container className="max-w-3xl py-10">
        <PageHeader
          eyebrow="ทะเบียนสัตว์"
          title="ลงทะเบียนสัตว์"
          desc="ช่องที่มี * จำเป็นต้องกรอก ที่เหลือกรอกเท่าที่ทราบ แก้ไขเพิ่มเติมภายหลังได้"
        />
        <AnimalForm />
      </Container>
    </RequireAuth>
  );
}
