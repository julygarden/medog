"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimalForm } from "@/components/animals/AnimalForm";
import { RequireAuth } from "@/components/RequireAuth";
import { Container, Empty, PageHeader, Spinner } from "@/components/ui";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Animal } from "@/lib/types";

export default function EditAnimalPage() {
  return (
    <RequireAuth>
      <EditAnimal />
    </RequireAuth>
  );
}

function EditAnimal() {
  const { id } = useParams<{ id: string }>();
  const [a, setA] = useState<Animal | null>(null);
  const [loading, setLoading] = useState(isConfigured);

  useEffect(() => {
    if (!isConfigured) return;
    supabase
      .from("animals")
      .select("*, vaccinations(*)")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => {
        setA(data as Animal | null);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <Spinner />;
  if (!a)
    return (
      <Container className="py-16">
        <Empty title="ไม่พบข้อมูล หรือไม่มีสิทธิ์แก้ไข" />
      </Container>
    );

  return (
    <Container className="max-w-3xl py-10">
      <PageHeader eyebrow="แก้ไขข้อมูล" title={a.name || "สัตว์ไม่มีชื่อ"} />
      <AnimalForm initial={a} />
    </Container>
  );
}
