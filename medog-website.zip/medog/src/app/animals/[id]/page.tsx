"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowLeft, CalendarClock, Pencil, Printer, Sparkles, Syringe, Trash2 } from "lucide-react";
import { SpeciesIcon } from "@/components/animals/AnimalCard";
import { useAuth } from "@/components/AuthProvider";
import { MiniMap } from "@/components/map/LocationPicker";
import { RequireAuth } from "@/components/RequireAuth";
import { Alert, Badge, Button, Card, Container, Empty, LinkButton, Spinner } from "@/components/ui";
import { ANIMAL_STATUS, SEX, SPECIES, STERILIZED, TEMPERAMENT, VACCINES } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Animal } from "@/lib/types";
import { formatAge, formatDate } from "@/lib/utils";

export default function AnimalDetailPage() {
  return (
    <RequireAuth>
      <AnimalDetail />
    </RequireAuth>
  );
}

function AnimalDetail() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const [a, setA] = useState<Animal | null>(null);
  const [loading, setLoading] = useState(isConfigured);
  const [photo, setPhoto] = useState(0);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!isConfigured) return;
    supabase
      .from("animals")
      .select("*, vaccinations(*)")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => {
        setA(data as Animal | null);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <Spinner />;
  if (!a)
    return (
      <Container className="py-16">
        <Empty title="ไม่พบข้อมูล" desc="สัตว์ตัวนี้อาจถูกลบ หรือคุณไม่มีสิทธิ์ดูข้อมูล" action={<LinkButton href="/animals">กลับไปทะเบียน</LinkButton>} />
      </Container>
    );

  // เห็นหน้านี้ได้ = เป็นเจ้าของหรือแอดมิน (RLS คุมอยู่แล้ว) จึงแก้ไขได้
  const canEdit = Boolean(user);
  const vax = [...(a.vaccinations ?? [])].sort((x, y) => y.given_on.localeCompare(x.given_on));
  const today = new Date().toISOString().slice(0, 10);
  const upcoming = vax.filter((v) => v.next_due && v.next_due >= today).sort((x, y) => x.next_due!.localeCompare(y.next_due!));
  const overdue = vax.filter((v) => v.next_due && v.next_due < today);

  const remove = async () => {
    if (!confirm(`ลบข้อมูล "${a.name || "สัตว์ตัวนี้"}" ถาวร?`)) return;
    const { error } = await supabase.from("animals").delete().eq("id", a.id);
    if (error) return setErr(errorText(error));
    router.push("/animals");
  };

  const rows: [string, React.ReactNode][] = [
    ["ชนิด", SPECIES[a.species]],
    ["ประเภท", ANIMAL_STATUS[a.status]],
    ["สายพันธุ์", a.breed || "-"],
    ["เพศ", SEX[a.sex]],
    ["อายุ", formatAge(a.birth_date, a.birth_date_estimated)],
    ["วันเกิด", a.birth_date ? `${formatDate(a.birth_date, { day: a.birth_date_estimated ? undefined : "numeric", month: "long", year: "numeric" })}${a.birth_date_estimated ? " (ประมาณ)" : ""}` : "-"],
    ["สีขน", a.color || "-"],
    ["ตำหนิ", a.markings || "-"],
    ["น้ำหนัก", a.weight_kg ? `${a.weight_kg} กก.` : "-"],
    ["ไมโครชิป", a.microchip || "-"],
    ["ทำหมัน", `${STERILIZED[a.sterilized]}${a.sterilized_date ? ` · ${formatDate(a.sterilized_date)}` : ""}${a.sterilized_place ? ` · ${a.sterilized_place}` : ""}`],
    ["นิสัย", `${TEMPERAMENT[a.temperament]}${a.bite_history && a.temperament !== "aggressive" ? " · เคยกัด/ทำร้ายคน" : ""}`],
  ];

  return (
    <Container className="py-8">
      <div className="no-print mb-6 flex items-center justify-between gap-2">
        <Link href="/animals" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink">
          <ArrowLeft className="size-4" /> ทะเบียนสัตว์
        </Link>
        {canEdit && (
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => window.print()}>
              <Printer className="size-4" /> พิมพ์
            </Button>
            <LinkButton href={`/animals/${a.id}/edit`} variant="secondary" size="sm">
              <Pencil className="size-4" /> แก้ไข
            </LinkButton>
            <Button variant="ghost" size="sm" onClick={remove} className="text-red-700">
              <Trash2 className="size-4" />
            </Button>
          </div>
        )}
      </div>
      {err && <Alert tone="red" className="mb-4">{err}</Alert>}
      {a.is_demo && <Alert tone="amber" className="mb-4">ข้อมูลตัวอย่างสำหรับสาธิตระบบ</Alert>}

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <Card className="overflow-hidden">
            <div className="aspect-[4/3] bg-sand">
              {a.photo_urls[photo] ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={a.photo_urls[photo]} alt={a.name ?? ""} className="size-full object-cover" />
              ) : (
                <div className="grid size-full place-items-center text-muted/50">
                  <SpeciesIcon species={a.species} className="size-20" />
                </div>
              )}
            </div>
            {a.photo_urls.length > 1 && (
              <div className="flex gap-2 overflow-x-auto p-3">
                {a.photo_urls.map((u, i) => (
                  <button key={u} onClick={() => setPhoto(i)} className={`size-16 shrink-0 overflow-hidden rounded-lg ring-2 ${i === photo ? "ring-ink" : "ring-transparent"}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={u} alt="" className="size-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </Card>

          {a.breed_ai && a.breed_ai.breeds?.length > 0 && (
            <Card className="mt-6 p-5">
              <p className="mb-3 flex items-center gap-1.5 font-semibold">
                <Sparkles className="size-4 text-violet-600" /> ผลวิเคราะห์สายพันธุ์โดย AI
              </p>
              <ul className="space-y-2.5">
                {a.breed_ai.breeds.map((b) => (
                  <li key={b.name_th}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>{b.name_th}{b.name_en && <span className="text-muted"> · {b.name_en}</span>}</span>
                      <b>{b.percent}%</b>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-sand">
                      <div className="h-full rounded-full bg-violet-500" style={{ width: `${b.percent}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
              {a.breed_ai.note_th && <p className="mt-3 text-xs text-muted">{a.breed_ai.note_th}</p>}
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={a.status === "pet" ? "blue" : a.status === "community" ? "violet" : "amber"}>{ANIMAL_STATUS[a.status]}</Badge>
              {a.is_deceased && <Badge>เสียชีวิตแล้ว</Badge>}
            </div>
            <h1 className="mt-2 text-3xl font-bold">{a.name || "ไม่มีชื่อ"}</h1>
            <p className="mt-1 text-muted">
              {[a.tambon && `ต.${a.tambon}`, a.amphoe && `อ.${a.amphoe}`, a.province && `จ.${a.province}`].filter(Boolean).join(" ")}
            </p>
          </div>

          <Card className="divide-y divide-line">
            {rows.map(([k, v]) => (
              <div key={k} className="grid grid-cols-[110px_1fr] gap-3 px-5 py-3 text-sm">
                <span className="text-muted">{k}</span>
                <span className="font-medium">{v}</span>
              </div>
            ))}
            {a.health_notes && (
              <div className="grid grid-cols-[110px_1fr] gap-3 px-5 py-3 text-sm">
                <span className="text-muted">สุขภาพ</span>
                <span className="whitespace-pre-line">{a.health_notes}</span>
              </div>
            )}
          </Card>

          <Card className="p-5">
            <p className="mb-3 flex items-center gap-1.5 font-semibold">
              <Syringe className="size-4" /> ประวัติวัคซีน
            </p>
            {overdue.length > 0 && (
              <Alert tone="red" className="mb-3">
                เลยกำหนดฉีดซ้ำ: {overdue.map((v) => VACCINES[v.vaccine].short).join(", ")}
              </Alert>
            )}
            {upcoming[0] && (
              <p className="mb-3 flex items-center gap-1.5 rounded-xl bg-sand px-3 py-2 text-sm">
                <CalendarClock className="size-4" /> นัดถัดไป: {VACCINES[upcoming[0].vaccine].short} · {formatDate(upcoming[0].next_due)}
              </p>
            )}
            {vax.length === 0 ? (
              <p className="text-sm text-muted">ยังไม่มีบันทึกวัคซีน</p>
            ) : (
              <ol className="relative space-y-4 border-l-2 border-line pl-5">
                {vax.map((v, i) => (
                  <li key={v.id ?? i} className="relative">
                    <span className="absolute -left-[27px] top-1 size-3 rounded-full border-2 border-white bg-brand ring-2 ring-brand/20" />
                    <p className="text-sm font-semibold">
                      {v.vaccine === "other" ? v.vaccine_name || "อื่นๆ" : VACCINES[v.vaccine].label}
                    </p>
                    <p className="text-xs text-muted">
                      ฉีด {formatDate(v.given_on)}
                      {v.next_due && <> · ครั้งถัดไป {formatDate(v.next_due)}</>}
                      {v.clinic && <> · {v.clinic}</>}
                      {v.vaccine !== "other" && v.vaccine_name && <> · {v.vaccine_name}</>}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </Card>

          {a.lat != null && a.lng != null && (
            <div className="no-print">
              <MiniMap lat={a.lat} lng={a.lng} />
              {a.address_note && <p className="mt-2 text-sm text-muted">{a.address_note}</p>}
            </div>
          )}

          {(a.caretaker_name || a.caretaker_phone) && (
            <Card className="p-5 text-sm">
              <p className="mb-1 font-semibold">ผู้ดูแล / ผู้ติดต่อ</p>
              <p>{a.caretaker_name} {a.caretaker_phone && <a className="text-brand-dark underline" href={`tel:${a.caretaker_phone}`}>{a.caretaker_phone}</a>}</p>
            </Card>
          )}
        </div>
      </div>
    </Container>
  );
}
