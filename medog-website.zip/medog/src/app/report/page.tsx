"use client";

import { Download, FileText, Printer } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { AddressSelect, type AddressValue } from "@/components/AddressSelect";
import { NoseMark } from "@/components/Logo";
import { Alert, Button, Card, Container, Empty, PageHeader, Spinner, Stat } from "@/components/ui";
import { COVERAGE_TARGET, LEVEL_META, levelOf, neededForTarget, pct, riskOf } from "@/lib/risk";
import { isConfigured, supabase } from "@/lib/supabase";
import type { AreaStat } from "@/lib/types";
import { downloadText, num } from "@/lib/utils";

function sumStats(rows: AreaStat[]): AreaStat | null {
  if (!rows.length) return null;
  const keys = ["total", "dogs", "cats", "strays", "rabies_ok", "dog_core_ok", "cat_core_ok", "sterilized", "aggressive", "open_cases"] as const;
  const out = { province: rows[0].province, amphoe: null, tambon: null, lat: null, lng: null } as AreaStat;
  keys.forEach((k) => (out[k] = rows.reduce((s, r) => s + (r[k] ?? 0), 0)));
  return out;
}

export default function ReportPage() {
  const [area, setArea] = useState<AddressValue>({ province: null, amphoe: null, tambon: null });
  const [rows, setRows] = useState<AreaStat[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    if (p.get("province")) setArea({ province: p.get("province"), amphoe: p.get("amphoe"), tambon: p.get("tambon") });
  }, []);

  useEffect(() => {
    if (!isConfigured || !area.province) return;
    setLoading(true);
    supabase.rpc("area_stats", { p_level: "tambon", p_province: area.province }).then(({ data }) => {
      setRows((data as AreaStat[]) ?? []);
      setLoading(false);
    });
  }, [area.province]);

  const shown = useMemo(
    () => rows.filter((r) => (!area.amphoe || r.amphoe === area.amphoe) && (!area.tambon || r.tambon === area.tambon)),
    [rows, area.amphoe, area.tambon],
  );
  const total = sumStats(shown);
  const areaLabel = area.tambon
    ? `ตำบล${area.tambon} อำเภอ${area.amphoe} จังหวัด${area.province}`
    : area.amphoe
      ? `อำเภอ${area.amphoe} จังหวัด${area.province}`
      : area.province
        ? `จังหวัด${area.province}`
        : "";

  const exportCsv = () => {
    const head = ["จังหวัด", "อำเภอ", "ตำบล", "จำนวนทั้งหมด", "สุนัข", "แมว", "สัตว์จร/ชุมชน", "วัคซีนพิษสุนัขบ้า(%)", "ทำหมัน(%)", "ระดับความเสี่ยง", "ความเสี่ยงรวม(%)", `ต้องฉีดเพิ่มเพื่อถึง ${COVERAGE_TARGET * 100}%`, "เคสเปิดอยู่"];
    const lines = shown.map((r) => {
      const { risk, n } = riskOf(r, "overall");
      return [r.province, r.amphoe, r.tambon, r.total, r.dogs, r.cats, r.strays, pct(r.rabies_ok, r.total), pct(r.sterilized, r.total), LEVEL_META[levelOf(risk, n)].label, risk === null ? "" : Math.round(risk), neededForTarget(r.total, r.rabies_ok), r.open_cases];
    });
    const csv = [head, ...lines].map((l) => l.map((x) => `"${String(x ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    downloadText(`medog-report-${area.province}${area.amphoe ? "-" + area.amphoe : ""}.csv`, csv);
  };

  const overall = total ? riskOf(total, "overall") : null;
  const overallLevel = overall ? levelOf(overall.risk, overall.n) : "nodata";
  const rabiesNeed = total ? neededForTarget(total.total, total.rabies_ok) : 0;
  const unsterilized = total ? total.total - total.sterilized : 0;
  const highAreas = shown.filter((r) => {
    const x = riskOf(r, "overall");
    return levelOf(x.risk, x.n) === "high";
  });

  return (
    <Container className="py-10">
      <div className="no-print">
        <PageHeader
          eyebrow="รายงานสำหรับหน่วยงานท้องถิ่น"
          title="รายงานสถานการณ์สุขภาพสัตว์ในพื้นที่"
          desc="เลือกพื้นที่ แล้วพิมพ์หรือดาวน์โหลดเป็นไฟล์ Excel (CSV) เพื่อประกอบการเสนอโครงการฉีดวัคซีนและทำหมันกับ อบต./เทศบาล/ปศุสัตว์"
          actions={
            total && (
              <>
                <Button variant="secondary" onClick={exportCsv}>
                  <Download className="size-4" /> CSV
                </Button>
                <Button onClick={() => window.print()}>
                  <Printer className="size-4" /> พิมพ์ / PDF
                </Button>
              </>
            )
          }
        />
        <Card className="mb-8 p-5">
          <AddressSelect value={area} onChange={setArea} />
          <p className="mt-2 text-xs text-muted">เลือกเฉพาะจังหวัด = รายงานทั้งจังหวัด · เลือกถึงอำเภอ/ตำบล = รายงานเฉพาะพื้นที่</p>
        </Card>
      </div>

      {!area.province ? (
        <Empty icon={<FileText className="size-6" />} title="เลือกจังหวัดเพื่อสร้างรายงาน" />
      ) : loading ? (
        <Spinner />
      ) : !total ? (
        <Empty title="ยังไม่มีข้อมูลสัตว์ที่ลงทะเบียนในพื้นที่นี้" desc="ชวนชุมชนลงทะเบียนสัตว์ เพื่อให้มีข้อมูลประกอบการวางแผน" />
      ) : (
        <article className="rounded-2xl border border-line bg-white p-6 sm:p-10 print:border-0 print:p-0">
          <header className="flex items-start justify-between gap-4 border-b border-line pb-6">
            <div>
              <p className="text-sm text-muted">รายงานสถานการณ์สุขภาพสัตว์เลี้ยงและสัตว์ชุมชน</p>
              <h2 className="mt-1 text-2xl font-bold">{areaLabel}</h2>
              <p className="mt-1 text-sm text-muted">
                ข้อมูล ณ วันที่ {new Date().toLocaleDateString("th-TH", { day: "numeric", month: "long", year: "numeric" })} · ที่มา: ระบบ Me Dog
              </p>
            </div>
            <NoseMark size={44} />
          </header>

          <section className="mt-6 grid gap-3 sm:grid-cols-4">
            <Stat label="สัตว์ที่ลงทะเบียน" value={num(total.total)} sub={`สุนัข ${total.dogs} · แมว ${total.cats}`} />
            <Stat label="สัตว์จร / สัตว์ชุมชน" value={num(total.strays)} sub={`${pct(total.strays, total.total)}% ของทั้งหมด`} />
            <Stat label="วัคซีนพิษสุนัขบ้า" value={`${pct(total.rabies_ok, total.total)}%`} sub={`เป้าหมาย ${COVERAGE_TARGET * 100}%`} />
            <Stat label="ทำหมันแล้ว" value={`${pct(total.sterilized, total.total)}%`} sub={`${num(total.sterilized)} ตัว`} />
          </section>

          <section className="mt-6 rounded-xl p-4" style={{ background: LEVEL_META[overallLevel].soft, color: LEVEL_META[overallLevel].text }}>
            <p className="font-semibold">
              ระดับความเสี่ยงภาพรวม: {LEVEL_META[overallLevel].label}
              {overall?.risk != null && ` (${Math.round(overall.risk)}%)`}
            </p>
            <p className="mt-1 text-sm">ดัชนีรวม = ไม่ได้วัคซีนพิษสุนัขบ้า 40% + ไม่ได้วัคซีนรวม 30% + ไม่ได้ทำหมัน 30%</p>
          </section>

          <section className="mt-8">
            <h3 className="text-lg font-semibold">ข้อเสนอแนะเพื่อการวางแผน</h3>
            <ol className="mt-3 list-decimal space-y-2 pl-5 text-[15px] leading-relaxed">
              {rabiesNeed > 0 ? (
                <li>
                  จัดหน่วยฉีดวัคซีนพิษสุนัขบ้าเพิ่มอย่างน้อย <b>{num(rabiesNeed)} ตัว</b> เพื่อให้ความครอบคลุมถึง {COVERAGE_TARGET * 100}% (ระดับที่ช่วยควบคุมการระบาดในชุมชน)
                </li>
              ) : (
                <li>ความครอบคลุมวัคซีนพิษสุนัขบ้าถึงเป้าหมายแล้ว ควรรักษาระดับด้วยการฉีดกระตุ้นประจำปี</li>
              )}
              {unsterilized > 0 && (
                <li>
                  มีสัตว์ที่ยังไม่ทำหมันหรือไม่ทราบสถานะ <b>{num(unsterilized)} ตัว</b> — เสนอโครงการทำหมันร่วมกับปศุสัตว์ โดยเริ่มจากสัตว์จร/สัตว์ชุมชน
                </li>
              )}
              {highAreas.length > 0 && (
                <li>
                  พื้นที่เสี่ยงสูงที่ควรลงพื้นที่ก่อน: <b>{highAreas.map((r) => `ต.${r.tambon}`).join(", ")}</b>
                </li>
              )}
              {total.aggressive > 0 && <li>มีสัตว์ที่ดุหรือเคยทำร้ายคน {num(total.aggressive)} ตัว — ควรประสานจัดการอย่างปลอดภัยและติดป้ายเตือนในจุดเสี่ยง</li>}
              {total.open_cases > 0 && <li>มีเคสขอความช่วยเหลือที่ยังเปิดอยู่ {num(total.open_cases)} เคส ในระบบ</li>}
            </ol>
          </section>

          <section className="mt-8 print-break">
            <h3 className="text-lg font-semibold">รายละเอียดรายตำบล</h3>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <thead>
                  <tr className="border-b border-line text-left text-muted">
                    <th className="py-2 pr-3 font-medium">ตำบล (อำเภอ)</th>
                    <th className="py-2 pr-3 text-right font-medium">ทั้งหมด</th>
                    <th className="py-2 pr-3 text-right font-medium">วัคซีนพิษสุนัขบ้า</th>
                    <th className="py-2 pr-3 text-right font-medium">ทำหมัน</th>
                    <th className="py-2 pr-3 text-right font-medium">ต้องฉีดเพิ่ม</th>
                    <th className="py-2 font-medium">ระดับ</th>
                  </tr>
                </thead>
                <tbody>
                  {shown
                    .map((r) => ({ r, ...riskOf(r, "overall") }))
                    .sort((a, b) => (b.risk ?? -1) - (a.risk ?? -1))
                    .map(({ r, risk, n }) => {
                      const lv = LEVEL_META[levelOf(risk, n)];
                      return (
                        <tr key={`${r.amphoe}-${r.tambon}`} className="border-b border-line/70">
                          <td className="py-2 pr-3">
                            {r.tambon} <span className="text-muted">({r.amphoe})</span>
                          </td>
                          <td className="py-2 pr-3 text-right tabular-nums">{r.total}</td>
                          <td className="py-2 pr-3 text-right tabular-nums">{pct(r.rabies_ok, r.total)}%</td>
                          <td className="py-2 pr-3 text-right tabular-nums">{pct(r.sterilized, r.total)}%</td>
                          <td className="py-2 pr-3 text-right tabular-nums">{neededForTarget(r.total, r.rabies_ok)}</td>
                          <td className="py-2">
                            <span className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-semibold" style={{ background: lv.soft, color: lv.text }}>
                              <span className="size-2 rounded-full" style={{ background: lv.color }} />
                              {lv.label}
                              {risk !== null && n >= 3 && ` ${Math.round(risk)}%`}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </section>

          <footer className="mt-8 border-t border-line pt-4 text-xs leading-relaxed text-muted">
            หมายเหตุ: ตัวเลขคำนวณจากสัตว์ที่ประชาชนและอาสาลงทะเบียนในระบบ อาจยังไม่ครอบคลุมสัตว์ทุกตัวในพื้นที่ วัคซีนนับเฉพาะที่ฉีดภายใน 1 ปี
            ระดับสี: เขียว ≤30% · เหลือง 31–60% · แดง &gt;60% · พื้นที่ที่มีข้อมูลน้อยกว่า 3 ตัวแสดงเป็น “ข้อมูลไม่พอ”
          </footer>
        </article>
      )}
      {!isConfigured && <Alert tone="amber" className="mt-6">ยังไม่ได้เชื่อมฐานข้อมูล จึงยังไม่มีข้อมูลรายงาน</Alert>}
    </Container>
  );
}
