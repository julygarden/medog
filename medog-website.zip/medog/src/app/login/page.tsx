"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { NoseMark } from "@/components/Logo";
import { Alert, Button, Card, Container, Field, Input, Segmented } from "@/components/ui";
import { errorText, isConfigured, supabase } from "@/lib/supabase";

export default function LoginPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [mode, setMode] = useState<"login" | "signup" | "reset">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [next, setNext] = useState("/animals");

  useEffect(() => {
    const n = new URLSearchParams(window.location.search).get("next");
    if (n && n.startsWith("/")) setNext(n);
  }, []);

  useEffect(() => {
    if (user) router.replace(next);
  }, [user, next, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setInfo("");
    if (!isConfigured) return setErr("ยังไม่ได้เชื่อมฐานข้อมูล Supabase (ดู README)");
    setLoading(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { display_name: name }, emailRedirectTo: `${window.location.origin}${next}` },
        });
        if (error) throw error;
        if (!data.session) setInfo("สมัครสำเร็จ! กรุณาเปิดอีเมลเพื่อกดยืนยัน แล้วกลับมาเข้าสู่ระบบ");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/account?reset=1`,
        });
        if (error) throw error;
        setInfo("ส่งลิงก์ตั้งรหัสผ่านใหม่ไปที่อีเมลแล้ว");
      }
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container className="grid min-h-[70vh] place-items-center py-12">
      <Card className="w-full max-w-md p-6 sm:p-8">
        <div className="mb-6 flex flex-col items-center text-center">
          <NoseMark size={52} />
          <h1 className="mt-4 text-2xl font-bold">
            {mode === "signup" ? "สมัครสมาชิก" : mode === "reset" ? "ลืมรหัสผ่าน" : "เข้าสู่ระบบ"}
          </h1>
          <p className="mt-1 text-sm text-muted">ลงทะเบียนสัตว์ แจ้งเคส และติดตามการช่วยเหลือ</p>
        </div>

        {mode !== "reset" && (
          <Segmented
            className="mb-6 [&>button]:flex-1"
            value={mode}
            onChange={(m) => {
              setMode(m);
              setErr("");
              setInfo("");
            }}
            options={{ login: "เข้าสู่ระบบ", signup: "สมัครใหม่" }}
          />
        )}

        <form onSubmit={submit} className="space-y-4">
          {mode === "signup" && (
            <Field label="ชื่อที่แสดง" required>
              <Input value={name} onChange={(e) => setName(e.target.value)} required placeholder="เช่น ป้าแดง ตลาดเช้า" />
            </Field>
          )}
          <Field label="อีเมล" required>
            <Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          {mode !== "reset" && (
            <Field label="รหัสผ่าน" required hint={mode === "signup" ? "อย่างน้อย 6 ตัวอักษร" : undefined}>
              <Input
                type="password"
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
                required
              />
            </Field>
          )}
          {err && <Alert tone="red">{err}</Alert>}
          {info && <Alert tone="green">{info}</Alert>}
          <Button type="submit" className="w-full" size="lg" loading={loading}>
            {mode === "signup" ? "สมัครสมาชิก" : mode === "reset" ? "ส่งลิงก์ตั้งรหัสใหม่" : "เข้าสู่ระบบ"}
          </Button>
        </form>

        <div className="mt-5 text-center text-sm">
          {mode === "login" && (
            <button onClick={() => setMode("reset")} className="text-muted hover:text-ink hover:underline">
              ลืมรหัสผ่าน?
            </button>
          )}
          {mode === "reset" && (
            <button onClick={() => setMode("login")} className="text-muted hover:text-ink hover:underline">
              ← กลับไปเข้าสู่ระบบ
            </button>
          )}
        </div>
      </Card>
    </Container>
  );
}
