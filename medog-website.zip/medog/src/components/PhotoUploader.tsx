"use client";

import { ImagePlus, Loader2, Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { useAuth } from "./AuthProvider";
import { errorText, isConfigured, publicUrl, supabase } from "@/lib/supabase";
import { randomId, resizeImage } from "@/lib/utils";

/**
 * อัปโหลดรูปทันทีที่เลือก (ย่อรูปอัตโนมัติ) แล้วคืนค่าเป็นลิงก์รูป
 * onFirstPhoto จะถูกเรียกพร้อมไฟล์รูปแรก (ใช้ส่งให้ AI วิเคราะห์สายพันธุ์)
 */
export function PhotoUploader({
  bucket,
  value,
  onChange,
  max = 6,
  onNewPhoto,
}: {
  bucket: "animal-photos" | "case-photos" | "product-images";
  value: string[];
  onChange: (urls: string[]) => void;
  max?: number;
  onNewPhoto?: (file: Blob, isFirst: boolean) => void;
}) {
  const { user } = useAuth();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(0);
  const [err, setErr] = useState("");

  const handleFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setErr("");
    const list = Array.from(files).slice(0, Math.max(0, max - value.length));
    let urls = [...value];
    for (const f of list) {
      if (!f.type.startsWith("image/")) continue;
      setBusy((b) => b + 1);
      try {
        const blob = await resizeImage(f);
        const isFirst = urls.length === 0;
        onNewPhoto?.(blob, isFirst);
        if (!isConfigured || !user) {
          // โหมดตัวอย่าง: แสดงตัวอย่างรูปในเครื่องเท่านั้น
          urls = [...urls, URL.createObjectURL(blob)];
        } else {
          const folder = bucket === "product-images" ? "products" : user.id;
          const path = `${folder}/${Date.now()}-${randomId()}.jpg`;
          const { error } = await supabase.storage.from(bucket).upload(path, blob, { contentType: "image/jpeg" });
          if (error) throw error;
          urls = [...urls, publicUrl(bucket, path)];
        }
        onChange(urls);
      } catch (e) {
        setErr(errorText(e));
      } finally {
        setBusy((b) => b - 1);
      }
    }
    if (input.current) input.current.value = "";
  };

  return (
    <div>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
        {value.map((u, i) => (
          <div key={u} className="group relative aspect-square overflow-hidden rounded-xl border border-line bg-sand">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={u} alt={`รูปที่ ${i + 1}`} className="size-full object-cover" />
            {i === 0 && (
              <span className="absolute left-1.5 top-1.5 rounded-md bg-ink/80 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                รูปหลัก
              </span>
            )}
            <button
              type="button"
              onClick={() => onChange(value.filter((x) => x !== u))}
              className="absolute right-1.5 top-1.5 grid size-7 place-items-center rounded-lg bg-white/90 text-red-700 opacity-100 shadow sm:opacity-0 sm:group-hover:opacity-100"
              aria-label="ลบรูป"
            >
              <Trash2 className="size-4" />
            </button>
          </div>
        ))}
        {value.length < max && (
          <button
            type="button"
            onClick={() => input.current?.click()}
            className="flex aspect-square flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-line bg-cream text-muted hover:border-ink/30 hover:text-ink"
          >
            {busy > 0 ? <Loader2 className="size-6 animate-spin" /> : <ImagePlus className="size-6" />}
            <span className="text-xs font-medium">{busy > 0 ? "กำลังอัปโหลด" : "เพิ่มรูป"}</span>
          </button>
        )}
      </div>
      <input
        ref={input}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      {err && <p className="mt-2 text-sm text-red-700">{err}</p>}
    </div>
  );
}
