"use client";

import QRCode from "qrcode";
import { useEffect, useState } from "react";
import { PROMPTPAY_ID, PROMPTPAY_NAME } from "@/lib/constants";
import { isValidPromptPay, promptPayPayload } from "@/lib/promptpay";
import { baht } from "@/lib/utils";

export function PromptPayBox({ amount, target }: { amount: number; target?: string | null }) {
  const id = (target || PROMPTPAY_ID).trim();
  const [src, setSrc] = useState("");

  useEffect(() => {
    if (!id || !isValidPromptPay(id)) return;
    QRCode.toDataURL(promptPayPayload(id, amount > 0 ? amount : undefined), { margin: 1, width: 360, color: { dark: "#1D2B3A" } })
      .then(setSrc)
      .catch(() => setSrc(""));
  }, [id, amount]);

  if (!id || !isValidPromptPay(id)) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-sand p-4 text-sm text-muted">
        ผู้ดูแลระบบยังไม่ได้ตั้งค่าบัญชีพร้อมเพย์ (NEXT_PUBLIC_PROMPTPAY_ID)
      </div>
    );
  }

  const masked = id.length === 10 ? `${id.slice(0, 3)}-xxx-${id.slice(6)}` : `${id.slice(0, 4)}…${id.slice(-3)}`;

  return (
    <div className="flex flex-col items-center rounded-2xl border border-line bg-white p-4 text-center">
      <div className="mb-2 rounded-lg bg-[#113566] px-3 py-1 text-xs font-bold tracking-wide text-white">THAI QR PAYMENT · พร้อมเพย์</div>
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="QR พร้อมเพย์" className="size-52" />
      ) : (
        <div className="size-52 animate-pulse rounded-lg bg-sand" />
      )}
      <p className="mt-2 text-2xl font-bold">{amount > 0 ? baht(amount) : "ระบุจำนวนเอง"}</p>
      <p className="text-sm text-muted">
        {PROMPTPAY_NAME && !target ? `${PROMPTPAY_NAME} · ` : ""}พร้อมเพย์ {masked}
      </p>
      <p className="mt-2 text-xs text-muted">สแกนด้วยแอปธนาคารใดก็ได้ แล้วแนบสลิปด้านล่าง</p>
    </div>
  );
}
