"use client";

import { CheckCircle2, HeartHandshake } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useAuth } from "../AuthProvider";
import { Alert, Button, Field, Input, LinkButton, Textarea } from "../ui";
import { PromptPayBox } from "./PromptPayBox";
import { SlipInput, uploadSlip } from "./SlipInput";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import { cls } from "@/lib/utils";

const PRESETS = [100, 300, 500, 1000];

export function DonateForm({
  caseId,
  promptpayId,
  onDone,
}: {
  caseId: string | null;
  promptpayId?: string | null;
  onDone?: () => void;
}) {
  const { user, profile } = useAuth();
  const [amount, setAmount] = useState(300);
  const [custom, setCustom] = useState("");
  const [name, setName] = useState("");
  const [anon, setAnon] = useState(false);
  const [message, setMessage] = useState("");
  const [slip, setSlip] = useState<Blob | null>(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);

  const value = custom ? Number(custom) : amount;

  if (done) {
    return (
      <div className="flex flex-col items-center py-6 text-center">
        <CheckCircle2 className="size-12 text-safe" />
        <p className="mt-3 text-lg font-semibold">ขอบคุณที่ร่วมช่วยเหลือ!</p>
        <p className="mt-1 max-w-xs text-sm text-muted">
          แอดมินจะตรวจสอบสลิปและยืนยันยอดภายใน 1–2 วัน ดูสถานะได้ที่{" "}
          <Link href="/account" className="font-medium text-ink underline">บัญชีของฉัน</Link>
        </p>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!isConfigured) return setErr("ยังไม่ได้เชื่อมฐานข้อมูล");
    if (!user) return;
    if (!value || value <= 0) return setErr("กรุณาระบุจำนวนเงิน");
    if (!slip) return setErr("กรุณาแนบสลิปการโอน");
    setSaving(true);
    try {
      const path = await uploadSlip(slip, user.id);
      const { error } = await supabase.from("donations").insert({
        case_id: caseId,
        donor_id: user.id,
        donor_name: name.trim() || profile?.display_name || null,
        is_anonymous: anon,
        amount: value,
        slip_path: path,
        message: message.trim() || null,
      });
      if (error) throw error;
      setDone(true);
      onDone?.();
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <p className="mb-2 text-sm font-medium">จำนวนเงิน</p>
        <div className="grid grid-cols-4 gap-2">
          {PRESETS.map((p) => (
            <button
              type="button"
              key={p}
              onClick={() => {
                setAmount(p);
                setCustom("");
              }}
              className={cls(
                "rounded-xl border py-2.5 text-sm font-semibold",
                !custom && amount === p ? "border-brand bg-brand-soft text-brand-dark" : "border-line bg-white hover:bg-sand",
              )}
            >
              {p.toLocaleString()}
            </button>
          ))}
        </div>
        <Input
          className="mt-2"
          type="number"
          min={1}
          inputMode="decimal"
          placeholder="หรือระบุจำนวนเอง (บาท)"
          value={custom}
          onChange={(e) => setCustom(e.target.value)}
        />
      </div>

      <PromptPayBox amount={value} target={promptpayId} />

      {!user ? (
        <div className="rounded-xl bg-sand p-4 text-center text-sm">
          <p>เข้าสู่ระบบเพื่อแนบสลิปและติดตามยอดบริจาคของคุณ</p>
          <LinkButton href={`/login?next=${encodeURIComponent(typeof window !== "undefined" ? window.location.pathname : "/donate")}`} size="sm" className="mt-3">
            เข้าสู่ระบบ
          </LinkButton>
        </div>
      ) : (
        <>
          <Field label="แนบสลิป" required>
            <SlipInput file={slip} onChange={setSlip} />
          </Field>
          <Field label="ชื่อที่แสดงในรายชื่อผู้บริจาค">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={profile?.display_name ?? ""} disabled={anon} />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" className="size-4" checked={anon} onChange={(e) => setAnon(e.target.checked)} />
            ไม่ประสงค์ออกนาม
          </label>
          <Field label="ข้อความถึงน้องๆ (ไม่บังคับ)">
            <Textarea rows={2} value={message} onChange={(e) => setMessage(e.target.value)} />
          </Field>
          {err && <Alert tone="red">{err}</Alert>}
          <Button type="submit" variant="brand" size="lg" className="w-full" loading={saving}>
            <HeartHandshake className="size-5" /> ยืนยันการบริจาค
          </Button>
        </>
      )}
    </form>
  );
}
