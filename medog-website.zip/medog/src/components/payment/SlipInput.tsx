"use client";

import { Receipt, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/lib/supabase";
import { randomId, resizeImage } from "@/lib/utils";

export function SlipInput({ file, onChange }: { file: Blob | null; onChange: (f: Blob | null) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState("");

  useEffect(() => {
    if (!file) return setPreview("");
    const u = URL.createObjectURL(file);
    setPreview(u);
    return () => URL.revokeObjectURL(u);
  }, [file]);

  return (
    <div>
      {preview ? (
        <div className="relative inline-block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={preview} alt="สลิป" className="max-h-56 rounded-xl border border-line" />
          <button
            type="button"
            onClick={() => onChange(null)}
            className="absolute right-1.5 top-1.5 grid size-7 place-items-center rounded-lg bg-white/90 shadow"
            aria-label="ลบสลิป"
          >
            <X className="size-4" />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => ref.current?.click()}
          className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-line bg-cream py-6 text-sm font-medium text-muted hover:border-ink/30 hover:text-ink"
        >
          <Receipt className="size-5" /> แนบรูปสลิปการโอน
        </button>
      )}
      <input
        ref={ref}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (f) onChange(await resizeImage(f, 1400, 0.85));
          e.target.value = "";
        }}
      />
    </div>
  );
}

/** อัปโหลดสลิปไปที่เก็บส่วนตัว (เห็นเฉพาะเจ้าของและแอดมิน) คืนค่า path */
export async function uploadSlip(blob: Blob, userId: string) {
  const path = `${userId}/${Date.now()}-${randomId()}.jpg`;
  const { error } = await supabase.storage.from("slips").upload(path, blob, { contentType: "image/jpeg" });
  if (error) throw error;
  return path;
}

export async function slipUrl(path: string) {
  const { data } = await supabase.storage.from("slips").createSignedUrl(path, 60 * 10);
  return data?.signedUrl ?? "";
}
