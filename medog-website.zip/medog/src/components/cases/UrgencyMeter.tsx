import type { Case } from "@/lib/types";
import { URGENCY_WEIGHTS, urgencyBreakdown } from "@/lib/urgency";
import { urgencyTone } from "./CaseCard";

export function UrgencyMeter({ c }: { c: Pick<Case, "proximity" | "aggression" | "vaccination_status"> }) {
  const b = urgencyBreakdown(c);
  const t = urgencyTone(b.score);
  const rows = [
    { label: "ความใกล้ชุมชน/โรงเรียน", w: URGENCY_WEIGHTS.proximity, v: b.proximity },
    { label: "ความก้าวร้าว", w: URGENCY_WEIGHTS.aggression, v: b.aggression },
    { label: "ความเสี่ยงจากไม่ได้ฉีดวัคซีน", w: URGENCY_WEIGHTS.vaccination, v: b.vaccination },
  ];
  return (
    <div className="rounded-xl border border-line bg-cream p-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold">คะแนนความเร่งด่วน</p>
        <span className={`rounded-lg px-2.5 py-1 text-sm font-bold ${t.cls}`}>
          {b.score}/100 · {t.label}
        </span>
      </div>
      <ul className="mt-3 space-y-2">
        {rows.map((r) => (
          <li key={r.label} className="text-xs">
            <div className="mb-1 flex justify-between text-muted">
              <span>
                {r.label} ({r.w * 100}%)
              </span>
              <span className="tabular-nums">{Math.round(r.v * r.w)} คะแนน</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white">
              <div className="h-full rounded-full bg-ink/70" style={{ width: `${r.v}%` }} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
