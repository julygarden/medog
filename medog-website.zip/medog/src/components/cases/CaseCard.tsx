import Link from "next/link";
import { MapPin, Siren } from "lucide-react";
import { CASE_CATEGORY, CASE_STATUS } from "@/lib/constants";
import type { Case } from "@/lib/types";
import { baht, caseCode, formatDate } from "@/lib/utils";
import { SpeciesIcon } from "../animals/AnimalCard";
import { Badge, Progress } from "../ui";

export function urgencyTone(score: number) {
  if (score >= 70) return { label: "เร่งด่วนมาก", cls: "bg-red-100 text-red-700" };
  if (score >= 40) return { label: "ปานกลาง", cls: "bg-amber-100 text-amber-800" };
  return { label: "ทั่วไป", cls: "bg-gray-100 text-gray-700" };
}

export function CaseCard({ c, raised }: { c: Case; raised?: number }) {
  const st = CASE_STATUS[c.status];
  const ut = urgencyTone(c.urgency_score);
  const showFund = c.status === "fundraising" && c.goal_amount;
  return (
    <Link
      href={`/cases/${c.id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-white transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative aspect-[16/10] bg-sand">
        {c.photo_urls[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={c.photo_urls[0]} alt="" className="size-full object-cover" />
        ) : (
          <div className="grid size-full place-items-center text-muted/50">
            <SpeciesIcon species={c.species} className="size-12" />
          </div>
        )}
        <div className="absolute left-2 top-2 flex gap-1.5">
          <Badge tone={st.tone}>{st.label}</Badge>
          {c.is_urgent && (
            <Badge tone="red">
              <Siren className="size-3" /> เร่งด่วน
            </Badge>
          )}
        </div>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="text-xs text-muted">
          {caseCode(c.case_no)} · {CASE_CATEGORY[c.category]} · {formatDate(c.created_at)}
        </p>
        <p className="mt-1 line-clamp-2 font-semibold leading-snug">{c.title}</p>
        <p className="mt-1.5 flex items-center gap-1 text-sm text-muted">
          <MapPin className="size-3.5" /> {[c.tambon && `ต.${c.tambon}`, c.amphoe && `อ.${c.amphoe}`, c.province].filter(Boolean).join(" ")}
        </p>
        <div className="mt-auto pt-4">
          {showFund ? (
            <>
              <Progress value={((raised ?? 0) / c.goal_amount!) * 100} />
              <p className="mt-1.5 flex justify-between text-sm">
                <b>{baht(raised ?? 0)}</b>
                <span className="text-muted">เป้าหมาย {baht(c.goal_amount)}</span>
              </p>
            </>
          ) : (
            <span className={`inline-flex rounded-lg px-2 py-1 text-xs font-semibold ${ut.cls}`}>
              คะแนนเร่งด่วน {c.urgency_score} · {ut.label}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
