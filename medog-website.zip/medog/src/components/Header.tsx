"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, LogOut, Menu, Shield, User, X } from "lucide-react";
import { useAuth } from "./AuthProvider";
import { Logo } from "./Logo";
import { ROLE } from "@/lib/constants";
import { cls } from "@/lib/utils";

const NAV = [
  { href: "/map", label: "แผนที่ความเสี่ยง" },
  { href: "/animals", label: "ทะเบียนสัตว์" },
  { href: "/cases", label: "เคสช่วยเหลือ" },
  { href: "/donate", label: "บริจาค" },
  { href: "/shop", label: "ร้านค้าเพื่อน้อง" },
  { href: "/volunteer", label: "อาสาสมัคร" },
];

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, profile, isStaff, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setOpen(false);
    setMenu(false);
  }, [pathname]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenu(false);
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  const active = (href: string) => pathname === href || pathname.startsWith(href + "/");
  const name = profile?.display_name || user?.email?.split("@")[0] || "บัญชี";

  return (
    <header className="no-print sticky top-0 z-[500] border-b border-line bg-cream/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" aria-label="หน้าแรก Me Dog">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cls(
                "rounded-lg px-3 py-2 text-[15px] font-medium transition",
                active(n.href) ? "bg-white text-ink shadow-sm ring-1 ring-line" : "text-ink-soft hover:bg-white/70",
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/cases/new"
            className="hidden h-10 items-center rounded-xl bg-brand px-4 text-sm font-semibold text-white hover:bg-brand-dark sm:inline-flex"
          >
            แจ้งเคส
          </Link>
          {user ? (
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenu((v) => !v)}
                className="flex h-10 items-center gap-2 rounded-xl border border-line bg-white px-2.5 text-sm font-medium hover:bg-sand"
              >
                <span className="grid size-7 place-items-center rounded-lg bg-ink text-xs font-bold text-white">
                  {name.slice(0, 1).toUpperCase()}
                </span>
                <span className="hidden max-w-28 truncate sm:inline">{name}</span>
                <ChevronDown className="size-4 text-muted" />
              </button>
              {menu && (
                <div className="absolute right-0 mt-2 w-60 overflow-hidden rounded-2xl border border-line bg-white py-1 shadow-lg">
                  <div className="border-b border-line px-4 py-3">
                    <p className="truncate font-semibold">{name}</p>
                    <p className="text-xs text-muted">{ROLE[profile?.role ?? "user"]}</p>
                  </div>
                  <Link href="/account" className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-sand">
                    <User className="size-4" /> บัญชีของฉัน
                  </Link>
                  {isStaff && (
                    <Link href="/admin" className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-sand">
                      <Shield className="size-4" /> ระบบแอดมิน
                    </Link>
                  )}
                  <button
                    onClick={async () => {
                      await signOut();
                      router.push("/");
                    }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-red-700 hover:bg-red-50"
                  >
                    <LogOut className="size-4" /> ออกจากระบบ
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              href="/login"
              className="inline-flex h-10 items-center rounded-xl border border-line bg-white px-4 text-sm font-semibold hover:bg-sand"
            >
              เข้าสู่ระบบ
            </Link>
          )}
          <button
            className="grid size-10 place-items-center rounded-xl border border-line bg-white lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="เมนู"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-line bg-cream px-4 pb-4 pt-2 lg:hidden">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cls(
                "block rounded-xl px-3 py-3 text-[15px] font-medium",
                active(n.href) ? "bg-white ring-1 ring-line" : "text-ink-soft",
              )}
            >
              {n.label}
            </Link>
          ))}
          <Link href="/cases/new" className="mt-2 block rounded-xl bg-brand px-3 py-3 text-center font-semibold text-white">
            แจ้งเคสขอความช่วยเหลือ
          </Link>
        </nav>
      )}
    </header>
  );
}
