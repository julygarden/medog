import { isConfigured } from "@/lib/supabase";

/** แสดงแถบเตือนเมื่อยังไม่ได้ตั้งค่า Supabase */
export function SetupNotice() {
  if (isConfigured) return null;
  return (
    <div className="no-print bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">
      โหมดตัวอย่าง: ยังไม่ได้เชื่อมฐานข้อมูล Supabase — ดูวิธีตั้งค่าในไฟล์ <b>README.md</b> (ขั้นตอนที่ 1–4)
    </div>
  );
}
