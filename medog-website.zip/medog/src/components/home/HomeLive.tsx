"use client";

import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { CaseCard } from "../cases/CaseCard";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Case, PublicSummary } from "@/lib/types";
import { baht, num } from "@/lib/utils";

export function HomeStats() {
  const [s, setS] = useState<PublicSummary | null>(null);
  useEffect(() => {
    if (!isConfigured) return;
    supabase.rpc("public_summary").then(({ data }) => setS(data as PublicSummary));
  }, []);
  const items = [
    { v: s ? num(s.animals) : "–", l: "สัตว์ที่ลงทะเบียน" },
    { v: s && s.animals ? `${Math.round((s.rabies_ok / s.animals) * 100)}%` : "–", l: "ได้วัคซีนพิษสุนัขบ้า" },
    { v: s ? num(s.volunteers) : "–", l: "อาสาที่ผ่านการอบรม" },
    { v: s ? baht(s.funds_raised) : "–", l: "ยอดบริจาคที่ตรวจสอบแล้ว" },
  ];
  return (
    <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-4">
      {items.map((x) => (
        <div key={x.l} className="bg-white px-5 py-5">
          <p className="text-2xl font-bold tracking-tight sm:text-3xl">{x.v}</p>
          <p className="mt-0.5 text-sm text-muted">{x.l}</p>
        </div>
      ))}
    </div>
  );
}

export function UrgentCases() {
  const [cases, setCases] = useState<Case[]>([]);
  const [funding, setFunding] = useState<Record<string, number>>({});
  useEffect(() => {
    if (!isConfigured) return;
    Promise.all([
      supabase
        .from("cases")
        .select("*")
        .in("status", ["fundraising", "verified", "forwarded", "in_progress"])
        .order("is_urgent", { ascending: false })
        .order("urgency_score", { ascending: false })
        .limit(3),
      supabase.rpc("case_funding"),
    ]).then(([c, f]) => {
      setCases((c.data as Case[]) ?? []);
      const m: Record<string, number> = {};
      ((f.data as { case_id: string; raised: number }[]) ?? []).forEach((x) => (m[x.case_id] = Number(x.raised)));
      setFunding(m);
    });
  }, []);
  if (cases.length === 0) return null;
  return (
    <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-brand-dark">ต้องการความช่วยเหลือตอนนี้</p>
          <h2 className="mt-1 text-2xl font-bold sm:text-3xl">เคสเร่งด่วน</h2>
        </div>
        <Link href="/cases" className="inline-flex items-center gap-1 text-sm font-semibold hover:underline">
          ดูทั้งหมด <ArrowRight className="size-4" />
        </Link>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cases.map((c) => (
          <CaseCard key={c.id} c={c} raised={funding[c.id]} />
        ))}
      </div>
    </section>
  );
}
