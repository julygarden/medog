"use client";

import dynamic from "next/dynamic";
import { Crosshair, MapPin } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui";

const MapPickerInner = dynamic(() => import("./MapPickerInner"), {
  ssr: false,
  loading: () => <div className="grid h-full place-items-center bg-sand text-sm text-muted">กำลังโหลดแผนที่…</div>,
});

export function LocationPicker({
  lat,
  lng,
  onChange,
}: {
  lat: number | null;
  lng: number | null;
  onChange: (lat: number | null, lng: number | null) => void;
}) {
  const [locating, setLocating] = useState(false);
  const [err, setErr] = useState("");

  const locate = () => {
    if (!navigator.geolocation) return setErr("อุปกรณ์นี้ไม่รองรับการระบุตำแหน่ง");
    setLocating(true);
    setErr("");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        onChange(Number(p.coords.latitude.toFixed(6)), Number(p.coords.longitude.toFixed(6)));
        setLocating(false);
      },
      () => {
        setErr("ไม่สามารถดึงตำแหน่งได้ — กรุณาอนุญาตการเข้าถึงตำแหน่ง หรือแตะบนแผนที่แทน");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-sm text-muted">
          <MapPin className="size-4" /> แตะบนแผนที่เพื่อปักหมุดตำแหน่ง
        </p>
        <div className="flex gap-2">
          {lat != null && (
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange(null, null)}>
              ล้างหมุด
            </Button>
          )}
          <Button type="button" variant="secondary" size="sm" onClick={locate} loading={locating}>
            <Crosshair className="size-4" /> ใช้ตำแหน่งปัจจุบัน
          </Button>
        </div>
      </div>
      <div className="h-72 overflow-hidden rounded-xl border border-line">
        <MapPickerInner lat={lat} lng={lng} onPick={(a, b) => onChange(a, b)} />
      </div>
      {lat != null && lng != null && (
        <p className="mt-1.5 text-xs text-muted">
          พิกัด {lat.toFixed(5)}, {lng.toFixed(5)}
        </p>
      )}
      {err && <p className="mt-1.5 text-xs text-red-700">{err}</p>}
    </div>
  );
}

export function MiniMap({ lat, lng, className = "h-56" }: { lat: number; lng: number; className?: string }) {
  return (
    <div className={`overflow-hidden rounded-xl border border-line ${className}`}>
      <MapPickerInner lat={lat} lng={lng} readOnly />
    </div>
  );
}
