"use client";

import { useEffect } from "react";
import { CircleMarker, MapContainer, TileLayer, Tooltip, useMap } from "react-leaflet";
import type { AreaStat } from "@/lib/types";
import { type Disease, LEVEL_META, levelOf, riskOf } from "@/lib/risk";
import { TILE_ATTR, TILE_URL } from "./MapPickerInner";

function FitBounds({ points }: { points: [number, number][] }) {
  const map = useMap();
  const key = points.map((p) => p.join(",")).join("|");
  useEffect(() => {
    if (points.length === 0) return;
    if (points.length === 1) map.setView(points[0], 12);
    else map.fitBounds(points, { padding: [40, 40], maxZoom: 13 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, map]);
  return null;
}

function FlyToSelected({ s }: { s: AreaStat | null }) {
  const map = useMap();
  useEffect(() => {
    if (s?.lat != null && s?.lng != null) map.flyTo([s.lat, s.lng], Math.max(map.getZoom(), 12), { duration: 0.6 });
  }, [s, map]);
  return null;
}

export default function RiskMapInner({
  stats,
  disease,
  selected,
  onSelect,
  label,
}: {
  stats: AreaStat[];
  disease: Disease;
  selected: AreaStat | null;
  onSelect: (s: AreaStat) => void;
  label: (s: AreaStat) => string;
}) {
  const pts = stats.filter((s) => s.lat != null && s.lng != null);
  const maxTotal = Math.max(1, ...pts.map((s) => s.total));

  return (
    <MapContainer center={[13.4, 101]} zoom={6} style={{ height: "100%", width: "100%" }} scrollWheelZoom>
      <TileLayer url={TILE_URL} attribution={TILE_ATTR} />
      <FitBounds points={pts.map((s) => [s.lat!, s.lng!] as [number, number])} />
      <FlyToSelected s={selected} />
      {pts.map((s) => {
        const { risk, n } = riskOf(s, disease);
        const level = levelOf(risk, n);
        const meta = LEVEL_META[level];
        const isSel = selected && label(selected) === label(s);
        const radius = 8 + Math.sqrt(s.total / maxTotal) * 14;
        return (
          <CircleMarker
            key={label(s)}
            center={[s.lat!, s.lng!]}
            radius={radius}
            pathOptions={{
              color: isSel ? "#1D2B3A" : "#ffffff",
              weight: isSel ? 3 : 2,
              fillColor: meta.color,
              fillOpacity: level === "nodata" ? 0.45 : 0.78,
            }}
            eventHandlers={{ click: () => onSelect(s) }}
          >
            <Tooltip direction="top" offset={[0, -radius + 4]}>
              <div className="text-[13px]">
                <div className="font-semibold">{label(s)}</div>
                <div>
                  {meta.label}
                  {risk !== null && n >= 3 && <> · เสี่ยง {Math.round(risk)}%</>}
                </div>
                <div className="text-gray-500">{s.total} ตัวที่ลงทะเบียน</div>
              </div>
            </Tooltip>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
