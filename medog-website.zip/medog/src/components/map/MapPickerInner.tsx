"use client";

import { useEffect } from "react";
import { CircleMarker, MapContainer, TileLayer, useMap, useMapEvents } from "react-leaflet";

export const TILE_URL = "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png";
export const TILE_ATTR =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';

const THAILAND: [number, number] = [13.4, 101.0];

function ClickHandler({ onPick }: { onPick?: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onPick?.(Number(e.latlng.lat.toFixed(6)), Number(e.latlng.lng.toFixed(6)));
    },
  });
  return null;
}

function Recenter({ lat, lng }: { lat: number | null; lng: number | null }) {
  const map = useMap();
  useEffect(() => {
    if (lat != null && lng != null) map.setView([lat, lng], Math.max(map.getZoom(), 15));
  }, [lat, lng, map]);
  return null;
}

export default function MapPickerInner({
  lat,
  lng,
  onPick,
  readOnly,
}: {
  lat: number | null;
  lng: number | null;
  onPick?: (lat: number, lng: number) => void;
  readOnly?: boolean;
}) {
  const has = lat != null && lng != null;
  return (
    <MapContainer
      center={has ? [lat!, lng!] : THAILAND}
      zoom={has ? 15 : 5}
      scrollWheelZoom={!readOnly}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer url={TILE_URL} attribution={TILE_ATTR} />
      {!readOnly && <ClickHandler onPick={onPick} />}
      {!readOnly && <Recenter lat={lat} lng={lng} />}
      {has && (
        <>
          <CircleMarker center={[lat!, lng!]} radius={16} pathOptions={{ color: "#E8735A", weight: 0, fillOpacity: 0.25 }} />
          <CircleMarker center={[lat!, lng!]} radius={7} pathOptions={{ color: "#fff", weight: 3, fillColor: "#E8735A", fillOpacity: 1 }} />
        </>
      )}
    </MapContainer>
  );
}
