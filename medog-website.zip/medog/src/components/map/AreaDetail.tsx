import Link from "next/link";
import { FileText } from "lucide-react";
import type { AreaStat } from "@/lib/types";
import { COVERAGE_TARGET, type Disease, LEVEL_META, areaName, levelOf, neededForTarget, pct, riskOf } from "@/lib/risk";

function Bar({ label, ok, n, target }: { label: string; ok: number; n: number; target?: number }) {
  const p = pct(ok, n);
  const level = levelOf(100 - p, n);
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm">
        <span>{label}</span>
        <span className="tabular-nums">
          <b>{p}%</b> <span className="text-muted">({ok}/{n})</span>
        </span>
      </div>
      <div className="relative h-2.5 overflow-hidden rounded-full bg-sand">
        <div className="h-full rounded-full" style={{ width: `${p}%`, background: LEVEL_META[level].color }} />
        {target && <div className="absolute inset-y-0 w-0.5 bg-ink/60" style={{ left: `${target * 100}%` }} />}
      </div>
    </div>
  );
}

export function AreaDetail({ s, disease }: { s: AreaStat; disease: Disease }) {
  const { risk, n } = riskOf(s, disease);
  const level = levelOf(risk, n);
  const meta = LEVEL_META[level];
  const need = neededForTarget(s.total, s.rabies_ok);
  const q = new URLSearchParams({ province: s.province, ...(s.amphoe ? { amphoe: s.amphoe } : {}), ...(s.tambon ? { tambon: s.tambon } : {}) });

  return (
    <div>
      <p className="text-sm text-muted">พื้นที่ที่เลือก</p>
      <h3 className="text-lg font-semibold leading-snug">{areaName(s)}</h3>
      <div className="mt-3 flex items-center gap-3 rounded-xl px-4 py-3" style={{ background: meta.soft, color: meta.text }}>
        <span className="size-3 rounded-full" style={{ background: meta.color }} />
        <span className="font-semibold">{meta.label}</span>
        {risk !== null && n >= 3 && <span className="ml-auto text-2xl font-bold tabular-nums">{Math.round(risk)}%</span>}
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-sand p-2.5">
          <p className="text-lg font-bold">{s.total}</p>
          <p className="text-xs text-muted">ทั้งหมด</p>
        </div>
        <div className="rounded-xl bg-sand p-2.5">
          <p className="text-lg font-bold">{s.dogs}/{s.cats}</p>
          <p className="text-xs text-muted">สุนัข/แมว</p>
        </div>
        <div className="rounded-xl bg-sand p-2.5">
          <p className="text-lg font-bold">{s.strays}</p>
          <p className="text-xs text-muted">สัตว์จร/ชุมชน</p>
        </div>
      </div>

      <div className="mt-5 space-y-3.5">
        <Bar label="วัคซีนพิษสุนัขบ้า" ok={s.rabies_ok} n={s.total} target={COVERAGE_TARGET} />
        {s.dogs > 0 && <Bar label="วัคซีนรวมสุนัข" ok={s.dog_core_ok} n={s.dogs} />}
        {s.cats > 0 && <Bar label="วัคซีนรวมแมว" ok={s.cat_core_ok} n={s.cats} />}
        <Bar label="ทำหมันแล้ว" ok={s.sterilized} n={s.total} />
      </div>

      <ul className="mt-5 space-y-1.5 text-sm">
        {need > 0 ? (
          <li>
            • ต้องฉีดวัคซีนพิษสุนัขบ้าเพิ่มอย่างน้อย <b>{need} ตัว</b> เพื่อให้ถึงเป้าหมาย {COVERAGE_TARGET * 100}%
          </li>
        ) : (
          <li>• ความครอบคลุมวัคซีนพิษสุนัขบ้าถึงเป้าหมาย {COVERAGE_TARGET * 100}% แล้ว</li>
        )}
        {s.aggressive > 0 && <li>• มีสัตว์ที่ดุ/เคยทำร้ายคน {s.aggressive} ตัว</li>}
        {s.open_cases > 0 && <li>• มีเคสที่ยังเปิดอยู่ {s.open_cases} เคส</li>}
        {s.total < 3 && <li className="text-muted">• ข้อมูลยังน้อย (น้อยกว่า 3 ตัว) ผลอาจยังไม่แม่นยำ</li>}
      </ul>

      <Link
        href={`/report?${q.toString()}`}
        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-line bg-white py-2.5 text-sm font-semibold hover:bg-sand"
      >
        <FileText className="size-4" /> ดูรายงานพื้นที่ (สำหรับ อบต./เทศบาล)
      </Link>
    </div>
  );
}
