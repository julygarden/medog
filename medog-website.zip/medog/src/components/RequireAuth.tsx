"use client";

import { Lock } from "lucide-react";
import { useAuth } from "./AuthProvider";
import { Container, Empty, LinkButton, Spinner } from "./ui";
import { isConfigured } from "@/lib/supabase";

export function RequireAuth({
  children,
  staff,
  admin,
  message = "กรุณาเข้าสู่ระบบเพื่อใช้งานส่วนนี้",
}: {
  children: React.ReactNode;
  staff?: boolean;
  admin?: boolean;
  message?: string;
}) {
  const { user, loading, isStaff, isAdmin } = useAuth();

  if (!isConfigured) {
    return <>{children}</>;
  }
  if (loading) return <Spinner />;
  if (!user) {
    const next = typeof window !== "undefined" ? window.location.pathname : "/";
    return (
      <Container className="py-16">
        <Empty
          icon={<Lock className="size-6" />}
          title="ต้องเข้าสู่ระบบก่อน"
          desc={message}
          action={<LinkButton href={`/login?next=${encodeURIComponent(next)}`}>เข้าสู่ระบบ / สมัครสมาชิก</LinkButton>}
        />
      </Container>
    );
  }
  if ((admin && !isAdmin) || (staff && !isStaff)) {
    return (
      <Container className="py-16">
        <Empty icon={<Lock className="size-6" />} title="ไม่มีสิทธิ์เข้าถึง" desc="ส่วนนี้สำหรับผู้ดูแลระบบเท่านั้น" />
      </Container>
    );
  }
  return <>{children}</>;
}
