/** โลโก้ "จมูกหมา" ของ Me Dog */
export function NoseMark({ size = 36, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      className={className}
      role="img"
      aria-label="Me Dog"
    >
      <rect width="64" height="64" rx="18" fill="#E8735A" />
      {/* จมูก */}
      <path
        d="M32 17c9.8 0 18.5 2.9 18.5 10.4 0 7.3-7.1 11.9-12.2 15.6-2.5 1.8-4.1 4-6.3 4s-3.8-2.2-6.3-4C20.6 39.3 13.5 34.7 13.5 27.4 13.5 19.9 22.2 17 32 17Z"
        fill="#1D2B3A"
      />
      {/* รูจมูก */}
      <path d="M21.5 28.6c1.6-2.6 5.2-3.2 7.3-1.4.9.8.5 2.1-.6 2.4-2 .6-3.6 1.6-4.8 3-1 1.1-2.8.4-2.8-1.1 0-1 .3-2 .9-2.9Z" fill="#FBF8F4" />
      <path d="M42.5 28.6c-1.6-2.6-5.2-3.2-7.3-1.4-.9.8-.5 2.1.6 2.4 2 .6 3.6 1.6 4.8 3 1 1.1 2.8.4 2.8-1.1 0-1-.3-2-.9-2.9Z" fill="#FBF8F4" />
      {/* ประกายจมูกชื้น */}
      <ellipse cx="27" cy="21.6" rx="4.2" ry="1.6" fill="#FBF8F4" opacity=".55" />
      {/* ร่องกลางจมูก */}
      <path d="M32 36.5v7" stroke="#FBF8F4" strokeWidth="1.6" strokeLinecap="round" opacity=".45" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <NoseMark size={compact ? 32 : 38} />
      <span className="leading-tight">
        <span className="block text-lg font-bold tracking-tight text-ink">Me Dog</span>
        {!compact && <span className="block text-[11px] font-medium text-muted">ทะเบียน · แผนที่ · ช่วยเหลือ</span>}
      </span>
    </span>
  );
}
