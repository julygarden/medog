"use client";

import { Loader2, RefreshCw, Sparkles } from "lucide-react";
import type { BreedAI } from "@/lib/types";
import { Button } from "../ui";

const CONF = { high: "มั่นใจสูง", medium: "มั่นใจปานกลาง", low: "มั่นใจต่ำ" };

export function BreedAIPanel({
  result,
  loading,
  error,
  onRetry,
  onUse,
  current,
}: {
  result: BreedAI | null;
  loading: boolean;
  error: string;
  onRetry?: () => void;
  onUse: (name: string) => void;
  current: string;
}) {
  if (!loading && !result && !error) return null;
  return (
    <div className="mt-4 rounded-xl border border-violet-200 bg-violet-50/60 p-4">
      <div className="mb-3 flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-sm font-semibold text-violet-900">
          <Sparkles className="size-4" /> AI วิเคราะห์สายพันธุ์จากรูป
        </p>
        {onRetry && !loading && (
          <Button type="button" variant="ghost" size="sm" onClick={onRetry}>
            <RefreshCw className="size-3.5" /> วิเคราะห์ใหม่
          </Button>
        )}
      </div>

      {loading && (
        <p className="flex items-center gap-2 text-sm text-violet-900">
          <Loader2 className="size-4 animate-spin" /> กำลังวิเคราะห์ใบหน้าและลักษณะ…
        </p>
      )}
      {error && !loading && <p className="text-sm text-red-700">{error}</p>}

      {result && !loading && (
        <>
          {result.species === "none" ? (
            <p className="text-sm">ไม่พบสุนัขหรือแมวในรูป ลองใช้รูปที่เห็นหน้าชัดๆ</p>
          ) : (
            <ul className="space-y-2.5">
              {result.breeds.map((b) => (
                <li key={b.name_th}>
                  <div className="mb-1 flex items-center justify-between gap-2 text-sm">
                    <span className="font-medium">
                      {b.name_th}
                      {b.name_en && <span className="text-muted"> · {b.name_en}</span>}
                    </span>
                    <span className="flex items-center gap-2">
                      <b className="tabular-nums">{b.percent}%</b>
                      {current !== b.name_th ? (
                        <button
                          type="button"
                          onClick={() => onUse(b.name_th)}
                          className="rounded-md bg-white px-2 py-0.5 text-xs font-semibold text-violet-800 ring-1 ring-violet-200 hover:bg-violet-100"
                        >
                          ใช้
                        </button>
                      ) : (
                        <span className="rounded-md bg-violet-700 px-2 py-0.5 text-xs font-semibold text-white">เลือกอยู่</span>
                      )}
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-white">
                    <div className="h-full rounded-full bg-violet-500" style={{ width: `${b.percent}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-xs text-violet-900/80">
            {result.confidence && <>{CONF[result.confidence]} · </>}
            {result.note_th ?? "ผลจาก AI เป็นการประเมินจากรูปภาพ แก้ไขสายพันธุ์ได้เสมอหากไม่ถูกต้อง"}
          </p>
        </>
      )}
    </div>
  );
}
