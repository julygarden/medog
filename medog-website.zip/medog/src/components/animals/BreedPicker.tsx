"use client";

import { Check, ChevronDown, Search } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { breedsFor } from "@/lib/constants";
import type { Species } from "@/lib/types";
import { cls } from "@/lib/utils";

/** เลือกสายพันธุ์: พิมพ์ค้นหา / เลื่อนเลือกจากรายการ / พิมพ์เองได้ */
export function BreedPicker({
  species,
  value,
  onChange,
}: {
  species: Species;
  value: string;
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const box = useRef<HTMLDivElement>(null);
  const list = breedsFor(species);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const filtered = useMemo(() => {
    const k = q.trim().toLowerCase();
    if (!k) return list;
    return list.filter((b) => b.th.toLowerCase().includes(k) || b.en.toLowerCase().includes(k));
  }, [q, list]);

  const exact = list.some((b) => b.th === q.trim());

  return (
    <div className="relative" ref={box}>
      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setQ("");
        }}
        className="flex w-full items-center justify-between rounded-xl border border-line bg-white px-3.5 py-2.5 text-left text-[15px] hover:border-ink/30"
      >
        <span className={value ? "text-ink" : "text-gray-400"}>{value || "เลือกหรือพิมพ์สายพันธุ์"}</span>
        <ChevronDown className="size-4 text-muted" />
      </button>
      {open && (
        <div className="absolute z-30 mt-1.5 w-full overflow-hidden rounded-xl border border-line bg-white shadow-lg">
          <div className="flex items-center gap-2 border-b border-line px-3">
            <Search className="size-4 text-muted" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  if (q.trim()) {
                    onChange(filtered[0]?.th && !exact && filtered.length === 1 ? filtered[0].th : q.trim());
                    setOpen(false);
                  }
                }
              }}
              placeholder="ค้นหา เช่น ชิวาวา, poodle"
              className="w-full py-2.5 text-[15px] outline-none"
            />
          </div>
          <ul className="max-h-64 overflow-y-auto py-1">
            {q.trim() && !exact && (
              <li>
                <button
                  type="button"
                  onClick={() => {
                    onChange(q.trim());
                    setOpen(false);
                  }}
                  className="w-full px-3.5 py-2 text-left text-sm text-brand-dark hover:bg-brand-soft"
                >
                  ใช้ “{q.trim()}” (พิมพ์เอง)
                </button>
              </li>
            )}
            {filtered.map((b) => (
              <li key={b.th}>
                <button
                  type="button"
                  onClick={() => {
                    onChange(b.th);
                    setOpen(false);
                  }}
                  className={cls(
                    "flex w-full items-center justify-between px-3.5 py-2 text-left text-sm hover:bg-sand",
                    value === b.th && "bg-sand font-semibold",
                  )}
                >
                  <span>
                    {b.th} <span className="text-muted">· {b.en}</span>
                  </span>
                  {value === b.th && <Check className="size-4" />}
                </button>
              </li>
            ))}
            {filtered.length === 0 && !q.trim() && (
              <li className="px-3.5 py-3 text-sm text-muted">พิมพ์ชื่อสายพันธุ์ได้เลย</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
