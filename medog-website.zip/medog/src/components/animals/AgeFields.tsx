"use client";

import { useState } from "react";
import { Field, Input, Segmented } from "../ui";
import { ageParts, birthFromAge, formatAge, parseISODate, toISODate } from "@/lib/utils";

/**
 * วันเกิด: ระบุแน่นอน หรือ ประมาณ
 * โหมดประมาณ: กรอก "เกิดประมาณ (เดือน/ปี)" หรือ "อายุประมาณ" ช่องใดช่องหนึ่ง อีกช่องคำนวณให้ทันที
 */
export function AgeFields({
  birthDate,
  estimated,
  onChange,
}: {
  birthDate: string | null;
  estimated: boolean;
  onChange: (birthDate: string | null, estimated: boolean) => void;
}) {
  const [mode, setMode] = useState<"exact" | "estimate" | "unknown">(
    birthDate ? (estimated ? "estimate" : "exact") : "estimate",
  );
  const b = parseISODate(birthDate);
  const parts = b ? ageParts(b) : null;
  const [years, setYears] = useState(parts ? String(parts.years) : "");
  const [months, setMonths] = useState(parts ? String(parts.months) : "");

  const monthValue = b ? toISODate(b).slice(0, 7) : "";

  const setFromAge = (y: string, m: string) => {
    setYears(y);
    setMonths(m);
    if (y === "" && m === "") return onChange(null, true);
    const d = birthFromAge(Number(y || 0), Number(m || 0));
    onChange(toISODate(d), true);
  };

  const setFromMonth = (v: string) => {
    if (!v) {
      setYears("");
      setMonths("");
      return onChange(null, true);
    }
    const d = new Date(Number(v.slice(0, 4)), Number(v.slice(5, 7)) - 1, 1);
    const p = ageParts(d);
    setYears(String(p.years));
    setMonths(String(p.months));
    onChange(toISODate(d), true);
  };

  return (
    <div>
      <Segmented
        value={mode}
        onChange={(m) => {
          setMode(m);
          if (m === "unknown") onChange(null, true);
          else if (birthDate) onChange(birthDate, m === "estimate");
        }}
        options={{ exact: "รู้วันเกิดแน่นอน", estimate: "ประมาณเอา", unknown: "ไม่ทราบเลย" }}
      />

      {mode === "exact" && (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="วันเกิด">
            <Input
              type="date"
              max={toISODate(new Date())}
              value={birthDate ?? ""}
              onChange={(e) => onChange(e.target.value || null, false)}
            />
          </Field>
          <div className="self-end rounded-xl bg-sand px-4 py-3 text-sm">
            อายุ: <b>{formatAge(birthDate)}</b>
          </div>
        </div>
      )}

      {mode === "estimate" && (
        <div className="mt-4 grid items-end gap-4 sm:grid-cols-[1fr_auto_1fr]">
          <Field label="เกิดประมาณ (เดือน/ปี)">
            <Input type="month" max={toISODate(new Date()).slice(0, 7)} value={monthValue} onChange={(e) => setFromMonth(e.target.value)} />
          </Field>
          <span className="hidden pb-3 text-sm font-medium text-muted sm:block">หรือ</span>
          <Field label="อายุประมาณ">
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min={0}
                max={30}
                inputMode="numeric"
                placeholder="0"
                value={years}
                onChange={(e) => setFromAge(e.target.value, months)}
                className="text-center"
              />
              <span className="text-sm text-muted">ปี</span>
              <Input
                type="number"
                min={0}
                max={11}
                inputMode="numeric"
                placeholder="0"
                value={months}
                onChange={(e) => setFromAge(years, e.target.value)}
                className="text-center"
              />
              <span className="text-sm text-muted">เดือน</span>
            </div>
          </Field>
          {birthDate && (
            <p className="text-xs text-muted sm:col-span-3">
              ระบบคำนวณ: เกิดประมาณ{" "}
              {parseISODate(birthDate)!.toLocaleDateString("th-TH", { month: "long", year: "numeric" })} · อายุ{" "}
              {formatAge(birthDate, true)}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
