"use client";

import { Plus, Syringe, Trash2 } from "lucide-react";
import { VACCINES } from "@/lib/constants";
import type { Species, Vaccination, VaccineKey } from "@/lib/types";
import { addDays, toISODate } from "@/lib/utils";
import { Button, Input, Select } from "../ui";

export function VaccinationEditor({
  species,
  value,
  onChange,
}: {
  species: Species;
  value: Vaccination[];
  onChange: (v: Vaccination[]) => void;
}) {
  const options = (Object.entries(VACCINES) as [VaccineKey, (typeof VACCINES)[VaccineKey]][])
    .filter(([, v]) => v.species.includes(species))
    .map(([k, v]) => ({ value: k, label: v.label }));

  const update = (i: number, patch: Partial<Vaccination>) =>
    onChange(value.map((v, idx) => (idx === i ? { ...v, ...patch } : v)));

  const add = () => {
    const today = toISODate(new Date());
    onChange([
      ...value,
      { vaccine: "rabies", vaccine_name: null, given_on: today, next_due: addDays(today, 365), clinic: null },
    ]);
  };

  return (
    <div className="space-y-3">
      {value.length === 0 && (
        <p className="flex items-center gap-2 rounded-xl bg-sand px-4 py-3 text-sm text-muted">
          <Syringe className="size-4" /> ยังไม่มีประวัติวัคซีน — กด “เพิ่มวัคซีน” เพื่อบันทึก
        </p>
      )}
      {value.map((v, i) => (
        <div key={i} className="rounded-xl border border-line p-3 sm:p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <Select
              value={v.vaccine}
              onChange={(e) => update(i, { vaccine: e.target.value as VaccineKey })}
              options={options}
              aria-label="ชนิดวัคซีน"
            />
            {v.vaccine === "other" ? (
              <Input
                placeholder="ชื่อวัคซีน"
                value={v.vaccine_name ?? ""}
                onChange={(e) => update(i, { vaccine_name: e.target.value })}
              />
            ) : (
              <Input
                placeholder="ยี่ห้อ / ล็อตวัคซีน (ถ้ามี)"
                value={v.vaccine_name ?? ""}
                onChange={(e) => update(i, { vaccine_name: e.target.value })}
              />
            )}
            <label className="text-xs text-muted">
              วันที่ฉีด
              <Input
                type="date"
                max={toISODate(new Date())}
                value={v.given_on}
                onChange={(e) =>
                  update(i, { given_on: e.target.value, next_due: e.target.value ? addDays(e.target.value, 365) : v.next_due })
                }
              />
            </label>
            <label className="text-xs text-muted">
              นัดฉีดครั้งถัดไป
              <Input type="date" value={v.next_due ?? ""} onChange={(e) => update(i, { next_due: e.target.value || null })} />
            </label>
            <Input
              className="sm:col-span-2"
              placeholder="สถานที่ฉีด เช่น คลินิก / หน่วยปศุสัตว์ / โครงการ อบต."
              value={v.clinic ?? ""}
              onChange={(e) => update(i, { clinic: e.target.value })}
            />
          </div>
          <div className="mt-2 flex justify-end">
            <button
              type="button"
              onClick={() => onChange(value.filter((_, idx) => idx !== i))}
              className="flex items-center gap-1 text-xs font-medium text-red-700 hover:underline"
            >
              <Trash2 className="size-3.5" /> ลบรายการนี้
            </button>
          </div>
        </div>
      ))}
      <Button type="button" variant="secondary" size="sm" onClick={add}>
        <Plus className="size-4" /> เพิ่มวัคซีน
      </Button>
    </div>
  );
}
