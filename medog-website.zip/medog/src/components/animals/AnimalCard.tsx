import Link from "next/link";
import { Cat, Dog, PawPrint, Syringe } from "lucide-react";
import { ANIMAL_STATUS, SEX, SPECIES } from "@/lib/constants";
import type { Animal } from "@/lib/types";
import { formatAge } from "@/lib/utils";
import { Badge } from "../ui";

export function SpeciesIcon({ species, className = "size-5" }: { species: string; className?: string }) {
  if (species === "dog") return <Dog className={className} />;
  if (species === "cat") return <Cat className={className} />;
  return <PawPrint className={className} />;
}

export function rabiesValid(a: Animal) {
  const today = new Date().toISOString().slice(0, 10);
  return (a.vaccinations ?? []).some((v) => {
    if (v.vaccine !== "rabies") return false;
    const due = v.next_due ?? addYear(v.given_on);
    return due >= today;
  });
}

function addYear(iso: string) {
  const [y, m, d] = iso.split("-");
  return `${Number(y) + 1}-${m}-${d}`;
}

export function AnimalCard({ a }: { a: Animal }) {
  const vaxOk = rabiesValid(a);
  return (
    <Link
      href={`/animals/${a.id}`}
      className="group overflow-hidden rounded-2xl border border-line bg-white transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative aspect-[4/3] bg-sand">
        {a.photo_urls[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={a.photo_urls[0]} alt={a.name ?? ""} className="size-full object-cover" />
        ) : (
          <div className="grid size-full place-items-center text-muted/60">
            <SpeciesIcon species={a.species} className="size-12" />
          </div>
        )}
        <span className="absolute left-2 top-2">
          <Badge tone={a.status === "pet" ? "blue" : a.status === "community" ? "violet" : "amber"}>
            {ANIMAL_STATUS[a.status].split(" ")[0]}
          </Badge>
        </span>
        {a.is_deceased && (
          <span className="absolute inset-0 grid place-items-center bg-ink/50 text-sm font-semibold text-white">เสียชีวิตแล้ว</span>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate font-semibold">{a.name || "ไม่มีชื่อ"}</p>
          <SpeciesIcon species={a.species} className="size-4 text-muted" />
        </div>
        <p className="mt-0.5 truncate text-sm text-muted">
          {a.breed || SPECIES[a.species]} · {SEX[a.sex]} · {formatAge(a.birth_date, a.birth_date_estimated)}
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Badge tone={vaxOk ? "green" : "red"}>
            <Syringe className="size-3" /> {vaxOk ? "วัคซีนพิษสุนัขบ้าครบ" : "ยังไม่ได้วัคซีนพิษสุนัขบ้า"}
          </Badge>
          <Badge tone={a.sterilized === "yes" ? "green" : "gray"}>{a.sterilized === "yes" ? "ทำหมันแล้ว" : "ยังไม่ทำหมัน"}</Badge>
        </div>
      </div>
    </Link>
  );
}
