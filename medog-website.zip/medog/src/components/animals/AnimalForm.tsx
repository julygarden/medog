"use client";

import { CalendarDays, Camera, HeartPulse, MapPin, PawPrint, User } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useAuth } from "../AuthProvider";
import { AddressSelect } from "../AddressSelect";
import { LocationPicker } from "../map/LocationPicker";
import { PhotoUploader } from "../PhotoUploader";
import { Alert, Button, Field, Input, Section, Segmented, Select, Textarea } from "../ui";
import { AgeFields } from "./AgeFields";
import { BreedAIPanel } from "./BreedAIPanel";
import { BreedPicker } from "./BreedPicker";
import { VaccinationEditor } from "./VaccinationEditor";
import { ANIMAL_STATUS, SEX, SPECIES, STERILIZED, TEMPERAMENT, breedsFor } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Animal, BreedAI, Species, Vaccination } from "@/lib/types";
import { blobToDataURL, resizeImage } from "@/lib/utils";

type FormState = Omit<Animal, "id" | "owner_id" | "is_demo" | "created_at" | "updated_at" | "vaccinations">;

const EMPTY: FormState = {
  species: "dog",
  status: "pet",
  name: "",
  sex: "unknown",
  breed: "",
  breed_ai: null,
  color: "",
  markings: "",
  birth_date: null,
  birth_date_estimated: true,
  weight_kg: null,
  microchip: "",
  sterilized: "unknown",
  sterilized_date: null,
  sterilized_place: "",
  temperament: "friendly",
  bite_history: false,
  health_notes: "",
  photo_urls: [],
  province: null,
  amphoe: null,
  tambon: null,
  address_note: "",
  lat: null,
  lng: null,
  caretaker_name: "",
  caretaker_phone: "",
  is_deceased: false,
};

export async function analyzeBreed(blob: Blob, species: Species | null): Promise<BreedAI> {
  const small = await resizeImage(blob, 896, 0.82);
  const image = await blobToDataURL(small);
  const { data } = await supabase.auth.getSession();
  const res = await fetch("/api/breed", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${data.session?.access_token ?? ""}`,
    },
    body: JSON.stringify({ image, species }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || "วิเคราะห์ไม่สำเร็จ");
  return json as BreedAI;
}

export function AnimalForm({ initial }: { initial?: Animal }) {
  const router = useRouter();
  const { user } = useAuth();
  const [f, setF] = useState<FormState>(() => (initial ? { ...EMPTY, ...stripAnimal(initial) } : EMPTY));
  const [vax, setVax] = useState<Vaccination[]>(initial?.vaccinations ?? []);
  const [breedTouched, setBreedTouched] = useState(Boolean(initial?.breed));
  const [ai, setAi] = useState<{ loading: boolean; error: string; blob: Blob | null }>({
    loading: false,
    error: "",
    blob: null,
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }));

  const runAI = async (blob: Blob) => {
    setAi({ loading: true, error: "", blob });
    try {
      const r = await analyzeBreed(blob, f.species);
      const result: BreedAI = { ...r, analyzed_at: new Date().toISOString() };
      setF((s) => {
        const next = { ...s, breed_ai: result };
        if (r.species === "dog" || r.species === "cat") next.species = r.species;
        if (!breedTouched && r.breeds?.[0]) next.breed = r.breeds[0].name_th;
        return next;
      });
      setAi({ loading: false, error: "", blob });
    } catch (e) {
      setAi({ loading: false, error: errorText(e), blob });
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!isConfigured) return setErr("ยังไม่ได้เชื่อมฐานข้อมูล (ดู README)");
    if (!user) return setErr("กรุณาเข้าสู่ระบบก่อน");
    if (!f.province || !f.amphoe || !f.tambon) return setErr("กรุณาเลือกจังหวัด อำเภอ และตำบล เพื่อใช้คำนวณแผนที่ความเสี่ยง");
    setSaving(true);
    try {
      const payload = {
        ...f,
        name: f.name?.trim() || null,
        breed: f.breed?.trim() || null,
        weight_kg: f.weight_kg ? Number(f.weight_kg) : null,
        sterilized_date: f.sterilized === "yes" ? f.sterilized_date : null,
        sterilized_place: f.sterilized === "yes" ? f.sterilized_place : null,
      };
      let id = initial?.id;
      if (id) {
        const { error } = await supabase.from("animals").update(payload).eq("id", id);
        if (error) throw error;
        const { error: delErr } = await supabase.from("vaccinations").delete().eq("animal_id", id);
        if (delErr) throw delErr;
      } else {
        const { data, error } = await supabase.from("animals").insert({ ...payload, owner_id: user.id }).select("id").single();
        if (error) throw error;
        id = data.id as string;
      }
      const rows = vax
        .filter((v) => v.given_on)
        .map((v) => ({
          animal_id: id,
          vaccine: v.vaccine,
          vaccine_name: v.vaccine_name || null,
          given_on: v.given_on,
          next_due: v.next_due || null,
          clinic: v.clinic || null,
        }));
      if (rows.length) {
        const { error } = await supabase.from("vaccinations").insert(rows);
        if (error) throw error;
      }
      router.push(`/animals/${id}`);
    } catch (e2) {
      setErr(errorText(e2));
      setSaving(false);
    }
  };

  const isStray = f.status !== "pet";

  return (
    <form onSubmit={submit} className="space-y-6">
      <Section
        title="รูปภาพและสายพันธุ์"
        desc="แนบรูปที่เห็นหน้าชัด ระบบ AI จะช่วยเดาสายพันธุ์และกรอกให้อัตโนมัติ (แก้ไขได้)"
        icon={<Camera className="size-5" />}
      >
        <PhotoUploader
          bucket="animal-photos"
          value={f.photo_urls}
          onChange={(v) => set("photo_urls", v)}
          onNewPhoto={(blob, isFirst) => {
            if (isFirst) runAI(blob);
          }}
        />
        <BreedAIPanel
          result={f.breed_ai}
          loading={ai.loading}
          error={ai.error}
          current={f.breed ?? ""}
          onRetry={ai.blob ? () => runAI(ai.blob!) : undefined}
          onUse={(name) => {
            set("breed", name);
            setBreedTouched(true);
          }}
        />
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <Field label="ชนิดสัตว์" required>
            <Segmented
              value={f.species}
              onChange={(v) => {
                set("species", v);
                if (!breedsFor(v).some((b) => b.th === f.breed)) set("breed", "");
              }}
              options={SPECIES}
            />
          </Field>
          <Field label="สายพันธุ์" hint="พิมพ์ค้นหา เลื่อนเลือก หรือพิมพ์ชื่อเองได้">
            <BreedPicker
              species={f.species}
              value={f.breed ?? ""}
              onChange={(v) => {
                set("breed", v);
                setBreedTouched(true);
              }}
            />
          </Field>
        </div>
      </Section>

      <Section title="ข้อมูลทั่วไป" icon={<PawPrint className="size-5" />}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="ประเภท" required className="sm:col-span-2">
            <Segmented value={f.status} onChange={(v) => set("status", v)} options={ANIMAL_STATUS} />
          </Field>
          <Field label="ชื่อ" hint={isStray ? "สัตว์จรตั้งชื่อเรียกได้ เช่น “ด่างหน้าตลาด”" : undefined}>
            <Input value={f.name ?? ""} onChange={(e) => set("name", e.target.value)} placeholder="เช่น ถุงทอง" />
          </Field>
          <Field label="เพศ">
            <Segmented value={f.sex} onChange={(v) => set("sex", v)} options={SEX} />
          </Field>
          <Field label="สีขน">
            <Input value={f.color ?? ""} onChange={(e) => set("color", e.target.value)} placeholder="เช่น น้ำตาล, ขาว-ดำ" />
          </Field>
          <Field label="ตำหนิ / ลักษณะเด่น">
            <Input value={f.markings ?? ""} onChange={(e) => set("markings", e.target.value)} placeholder="เช่น หูพับข้างเดียว หางสั้น" />
          </Field>
          <Field label="น้ำหนัก (กก.)">
            <Input
              type="number"
              step="0.1"
              min={0}
              value={f.weight_kg ?? ""}
              onChange={(e) => set("weight_kg", e.target.value ? Number(e.target.value) : null)}
            />
          </Field>
          <Field label="เลขไมโครชิป (ถ้ามี)">
            <Input value={f.microchip ?? ""} onChange={(e) => set("microchip", e.target.value)} />
          </Field>
        </div>
      </Section>

      <Section title="อายุ" desc="ไม่รู้วันเกิดแน่นอนก็ได้ กรอกเดือนที่เกิดโดยประมาณ หรืออายุโดยประมาณ ช่องใดช่องหนึ่ง" icon={<CalendarDays className="size-5" />}>
        <AgeFields
          birthDate={f.birth_date}
          estimated={f.birth_date_estimated}
          onChange={(d, est) => setF((s) => ({ ...s, birth_date: d, birth_date_estimated: est }))}
        />
      </Section>

      <Section title="สุขภาพ วัคซีน และการทำหมัน" icon={<HeartPulse className="size-5" />}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="การทำหมัน" className="sm:col-span-2">
            <Segmented value={f.sterilized} onChange={(v) => set("sterilized", v)} options={STERILIZED} />
          </Field>
          {f.sterilized === "yes" && (
            <>
              <Field label="วันที่ทำหมัน (ถ้าทราบ)">
                <Input type="date" value={f.sterilized_date ?? ""} onChange={(e) => set("sterilized_date", e.target.value || null)} />
              </Field>
              <Field label="สถานที่ทำหมัน">
                <Input value={f.sterilized_place ?? ""} onChange={(e) => set("sterilized_place", e.target.value)} />
              </Field>
            </>
          )}
        </div>
        <div className="mt-6">
          <p className="mb-2 text-sm font-medium">ประวัติวัคซีน</p>
          <VaccinationEditor species={f.species} value={vax} onChange={setVax} />
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Field label="นิสัย / พฤติกรรม">
            <Select value={f.temperament} onChange={(e) => set("temperament", e.target.value as FormState["temperament"])} options={TEMPERAMENT} />
          </Field>
          <Field label="เคยกัดหรือทำร้ายคนหรือไม่">
            <Segmented
              value={f.bite_history ? "yes" : "no"}
              onChange={(v) => set("bite_history", v === "yes")}
              options={{ no: "ไม่เคย", yes: "เคย" }}
            />
          </Field>
          <Field label="โรคประจำตัว / หมายเหตุสุขภาพ" className="sm:col-span-2">
            <Textarea value={f.health_notes ?? ""} onChange={(e) => set("health_notes", e.target.value)} />
          </Field>
        </div>
      </Section>

      <Section
        title="พื้นที่อาศัย"
        desc="ใช้คำนวณแผนที่ความเสี่ยงระดับตำบล (สาธารณะจะเห็นเพียงตัวเลขรวมของพื้นที่ ไม่เห็นตำแหน่งรายตัว)"
        icon={<MapPin className="size-5" />}
      >
        <AddressSelect
          required
          value={{ province: f.province, amphoe: f.amphoe, tambon: f.tambon }}
          onChange={(a) => setF((s) => ({ ...s, ...a }))}
        />
        <Field label="รายละเอียดที่อยู่ / จุดสังเกต" className="mt-4">
          <Input value={f.address_note ?? ""} onChange={(e) => set("address_note", e.target.value)} placeholder="เช่น หมู่ 3 หน้าวัด" />
        </Field>
        <div className="mt-4">
          <LocationPicker lat={f.lat} lng={f.lng} onChange={(lat, lng) => setF((s) => ({ ...s, lat, lng }))} />
        </div>
      </Section>

      <Section
        title={isStray ? "ผู้ดูแล / ผู้ให้อาหาร" : "ผู้ติดต่อ"}
        desc="ไม่บังคับ — เห็นเฉพาะคุณและผู้ดูแลระบบ"
        icon={<User className="size-5" />}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="ชื่อ">
            <Input value={f.caretaker_name ?? ""} onChange={(e) => set("caretaker_name", e.target.value)} />
          </Field>
          <Field label="เบอร์โทร">
            <Input type="tel" value={f.caretaker_phone ?? ""} onChange={(e) => set("caretaker_phone", e.target.value)} />
          </Field>
        </div>
        {initial && (
          <label className="mt-4 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={f.is_deceased} onChange={(e) => set("is_deceased", e.target.checked)} className="size-4" />
            น้องเสียชีวิตแล้ว (จะไม่นำไปคำนวณแผนที่)
          </label>
        )}
      </Section>

      {err && <Alert tone="red">{err}</Alert>}

      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-line bg-cream/95 px-4 py-4 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        <Button type="button" variant="secondary" onClick={() => router.back()}>
          ยกเลิก
        </Button>
        <Button type="submit" loading={saving} size="lg">
          {initial ? "บันทึกการแก้ไข" : "ลงทะเบียน"}
        </Button>
      </div>
    </form>
  );
}

function stripAnimal(a: Animal): Partial<FormState> {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { id, owner_id, is_demo, created_at, updated_at, vaccinations, ...rest } = a;
  return rest;
}
