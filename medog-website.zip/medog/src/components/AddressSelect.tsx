"use client";

import { useEffect, useState } from "react";
import { Field, Select } from "./ui";

type AddressTree = Record<string, Record<string, string[]>>;
let cache: Promise<AddressTree> | null = null;

/** โหลดรายชื่อจังหวัด/อำเภอ/ตำบลทั่วประเทศ (77 จังหวัด) */
export function useThaiAddress() {
  const [tree, setTree] = useState<AddressTree | null>(null);
  useEffect(() => {
    if (!cache) cache = fetch("/data/thai-address.json").then((r) => r.json());
    let alive = true;
    cache.then((t) => alive && setTree(t)).catch(() => (cache = null));
    return () => {
      alive = false;
    };
  }, []);
  return tree;
}

export interface AddressValue {
  province: string | null;
  amphoe: string | null;
  tambon: string | null;
}

export function AddressSelect({
  value,
  onChange,
  required,
  level = "tambon",
  labels = true,
  className = "grid gap-4 sm:grid-cols-3",
}: {
  value: AddressValue;
  onChange: (v: AddressValue) => void;
  required?: boolean;
  level?: "province" | "amphoe" | "tambon";
  labels?: boolean;
  className?: string;
}) {
  const tree = useThaiAddress();
  const provinces = tree ? Object.keys(tree) : [];
  const amphoes = tree && value.province ? Object.keys(tree[value.province] ?? {}) : [];
  const tambons = tree && value.province && value.amphoe ? (tree[value.province]?.[value.amphoe] ?? []) : [];

  const wrap = (label: string, el: React.ReactNode) =>
    labels ? (
      <Field label={label} required={required}>
        {el}
      </Field>
    ) : (
      el
    );

  return (
    <div className={className}>
      {wrap(
        "จังหวัด",
        <Select
          value={value.province ?? ""}
          onChange={(e) => onChange({ province: e.target.value || null, amphoe: null, tambon: null })}
          placeholder={tree ? "เลือกจังหวัด" : "กำลังโหลด…"}
          options={provinces.map((p) => ({ value: p, label: p }))}
          required={required}
        />,
      )}
      {level !== "province" &&
        wrap(
          "อำเภอ / เขต",
          <Select
            value={value.amphoe ?? ""}
            onChange={(e) => onChange({ ...value, amphoe: e.target.value || null, tambon: null })}
            placeholder="เลือกอำเภอ"
            options={amphoes.map((p) => ({ value: p, label: p }))}
            disabled={!value.province}
            required={required}
          />,
        )}
      {level === "tambon" &&
        wrap(
          "ตำบล / แขวง",
          <Select
            value={value.tambon ?? ""}
            onChange={(e) => onChange({ ...value, tambon: e.target.value || null })}
            placeholder="เลือกตำบล"
            options={tambons.map((p) => ({ value: p, label: p }))}
            disabled={!value.amphoe}
            required={required}
          />,
        )}
    </div>
  );
}
