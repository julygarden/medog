import Link from "next/link";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="no-print mt-20 border-t border-line bg-white">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            ระบบข้อมูลสัตว์เลี้ยงและสัตว์ชุมชน เพื่อให้ชุมชน อาสาสมัคร และหน่วยงานท้องถิ่นวางแผนฉีดวัคซีน ทำหมัน
            และช่วยเหลือสัตว์ได้ตรงจุด
          </p>
          <p className="mt-4 text-xs text-muted">
            ข้อมูลสัตว์รายตัวเห็นเฉพาะเจ้าของและผู้ดูแลระบบ — แผนที่สาธารณะแสดงเฉพาะตัวเลขภาพรวมของพื้นที่
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold">ใช้งาน</p>
          <ul className="mt-3 space-y-2 text-sm text-muted">
            <li><Link href="/animals/new" className="hover:text-ink">ลงทะเบียนสัตว์</Link></li>
            <li><Link href="/map" className="hover:text-ink">แผนที่ความเสี่ยงโรค</Link></li>
            <li><Link href="/cases/new" className="hover:text-ink">แจ้งเคสขอความช่วยเหลือ</Link></li>
            <li><Link href="/report" className="hover:text-ink">รายงานสำหรับ อบต./เทศบาล</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold">ร่วมช่วยเหลือ</p>
          <ul className="mt-3 space-y-2 text-sm text-muted">
            <li><Link href="/donate" className="hover:text-ink">บริจาคตามเคส</Link></li>
            <li><Link href="/shop" className="hover:text-ink">ร้านค้าเพื่อน้อง</Link></li>
            <li><Link href="/volunteer" className="hover:text-ink">สมัครอาสาสมัคร</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-muted">
        © {new Date().getFullYear()} Me Dog · ทำด้วยใจเพื่อสัตว์ชุมชน
      </div>
    </footer>
  );
}
