"use client";

import { useCallback, useEffect, useState } from "react";
import { slipUrl } from "../payment/SlipInput";
import { Badge, Button, Card, Empty, Segmented, Spinner } from "../ui";
import { DONATION_STATUS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Donation } from "@/lib/types";
import { baht, caseCode, formatDateTime } from "@/lib/utils";

type Row = Donation & { cases: { title: string; case_no: number } | null };

export function AdminDonations() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [filter, setFilter] = useState<"pending" | "confirmed" | "all">("pending");
  const [slips, setSlips] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    if (!isConfigured) return;
    let q = supabase.from("donations").select("*, cases(title, case_no)").order("created_at", { ascending: false }).limit(300);
    if (filter !== "all") q = q.eq("status", filter);
    const { data } = await q;
    setRows((data as Row[]) ?? []);
    setLoading(false);
  }, [filter]);
  useEffect(() => {
    load();
  }, [load]);

  const showSlip = async (d: Row) => {
    if (!d.slip_path) return;
    const u = await slipUrl(d.slip_path);
    setSlips((s) => ({ ...s, [d.id]: u }));
  };

  const setStatus = async (d: Row, status: "confirmed" | "rejected") => {
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("donations")
      .update({ status, confirmed_by: u.user?.id, confirmed_at: new Date().toISOString() })
      .eq("id", d.id);
    if (error) alert(errorText(error));
    load();
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">ตรวจสลิปบริจาค</h2>
          <p className="text-sm text-muted">ตรวจยอดในบัญชีธนาคารให้ตรงกับสลิปก่อนกดยืนยัน — เฉพาะยอดที่ยืนยันจะนับในหน้าเคส</p>
        </div>
        <Segmented value={filter} onChange={setFilter} options={{ pending: "รอตรวจ", confirmed: "ยืนยันแล้ว", all: "ทั้งหมด" }} />
      </div>
      {loading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ไม่มีรายการ" />
      ) : (
        <div className="space-y-3">
          {rows.map((d) => (
            <Card key={d.id} className="flex flex-col gap-4 p-4 text-sm sm:flex-row">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-lg font-bold">{baht(d.amount)}</p>
                  <Badge tone={DONATION_STATUS[d.status].tone}>{DONATION_STATUS[d.status].label}</Badge>
                  {d.is_demo && <Badge>ตัวอย่าง</Badge>}
                </div>
                <p className="mt-1">{d.cases ? `${caseCode(d.cases.case_no)} · ${d.cases.title}` : "กองทุนกลาง"}</p>
                <p className="text-muted">
                  {d.is_anonymous ? "ไม่ประสงค์ออกนาม" : d.donor_name || "-"} · {formatDateTime(d.created_at)}
                </p>
                {d.message && <p className="mt-1 text-muted">“{d.message}”</p>}
                {d.status === "pending" && (
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" onClick={() => setStatus(d, "confirmed")}>ยืนยันยอด</Button>
                    <Button size="sm" variant="secondary" onClick={() => setStatus(d, "rejected")}>สลิปไม่ถูกต้อง</Button>
                  </div>
                )}
              </div>
              {d.slip_path && (
                <div className="sm:w-40">
                  {slips[d.id] ? (
                    <a href={slips[d.id]} target="_blank" rel="noreferrer">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={slips[d.id]} alt="สลิป" className="max-h-56 rounded-lg border border-line" />
                    </a>
                  ) : (
                    <Button size="sm" variant="secondary" onClick={() => showSlip(d)} className="w-full">ดูสลิป</Button>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
