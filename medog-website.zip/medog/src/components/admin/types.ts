export type AdminTab = "overview" | "cases" | "agencies" | "animals" | "volunteers" | "donations" | "orders" | "products" | "users";
