"use client";

import { Pencil, Plus } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { PhotoUploader } from "../PhotoUploader";
import { ProductArt } from "../ProductArt";
import { Alert, Badge, Button, Card, Empty, Field, Input, Modal, Select, Spinner, Textarea } from "../ui";
import { PRODUCT_CATEGORY } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Product } from "@/lib/types";
import { baht } from "@/lib/utils";

type Edit = Omit<Product, "id" | "is_demo"> & { id?: string };
const BLANK: Edit = { name: "", description: "", price: 0, image_url: null, category: "food", impact_note: "", stock: null, is_active: true, sort: 0 };

export function AdminProducts() {
  const [rows, setRows] = useState<Product[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [edit, setEdit] = useState<Edit | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!isConfigured) return;
    const { data } = await supabase.from("products").select("*").order("sort");
    setRows((data as Product[]) ?? []);
    setLoading(false);
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    if (!edit?.name.trim()) return setErr("กรุณาใส่ชื่อสินค้า");
    setBusy(true);
    const { id, ...payload } = edit;
    const res = id ? await supabase.from("products").update(payload).eq("id", id) : await supabase.from("products").insert(payload);
    setBusy(false);
    if (res.error) return setErr(errorText(res.error));
    setEdit(null);
    load();
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-xl font-bold">สินค้าในร้าน</h2>
        <Button onClick={() => { setErr(""); setEdit({ ...BLANK, sort: rows.length + 1 }); }}>
          <Plus className="size-4" /> เพิ่มสินค้า
        </Button>
      </div>
      {loading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ยังไม่มีสินค้า" />
      ) : (
        <Card className="divide-y divide-line">
          {rows.map((p) => (
            <div key={p.id} className="flex items-center gap-4 px-4 py-3 text-sm">
              {p.image_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.image_url} alt="" className="size-14 rounded-lg object-cover" />
              ) : (
                <ProductArt category={p.category} className="size-14 rounded-lg [&_svg]:size-6" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{p.name}</p>
                <p className="text-muted">
                  {PRODUCT_CATEGORY[p.category]} · {baht(p.price)} · สต็อก {p.stock ?? "ไม่จำกัด"}
                </p>
              </div>
              {!p.is_active && <Badge>ซ่อน</Badge>}
              {p.is_demo && <Badge>ตัวอย่าง</Badge>}
              <Button size="sm" variant="ghost" onClick={() => { setErr(""); setEdit({ ...p }); }}>
                <Pencil className="size-4" />
              </Button>
            </div>
          ))}
        </Card>
      )}

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? "แก้ไขสินค้า" : "เพิ่มสินค้า"}>
        {edit && (
          <div className="space-y-4">
            <Field label="รูปสินค้า">
              <PhotoUploader bucket="product-images" max={1} value={edit.image_url ? [edit.image_url] : []} onChange={(v) => setEdit({ ...edit, image_url: v[0] ?? null })} />
            </Field>
            <Field label="ชื่อสินค้า" required>
              <Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="ราคา (บาท)">
                <Input type="number" min={0} value={edit.price} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} />
              </Field>
              <Field label="สต็อก" hint="เว้นว่าง = ไม่จำกัด">
                <Input type="number" min={0} value={edit.stock ?? ""} onChange={(e) => setEdit({ ...edit, stock: e.target.value === "" ? null : Number(e.target.value) })} />
              </Field>
              <Field label="หมวด">
                <Select value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value as Product["category"] })} options={PRODUCT_CATEGORY} />
              </Field>
            </div>
            <Field label="รายละเอียด">
              <Textarea rows={2} value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
            </Field>
            <Field label="ผลลัพธ์ต่อสัตว์ (แสดงเป็นแถบเขียว)" hint="เช่น 1 ถุง = อาหาร 60 มื้อ">
              <Input value={edit.impact_note ?? ""} onChange={(e) => setEdit({ ...edit, impact_note: e.target.value })} />
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="ลำดับการแสดง">
                <Input type="number" value={edit.sort} onChange={(e) => setEdit({ ...edit, sort: Number(e.target.value) })} />
              </Field>
              <label className="flex items-center gap-2 self-end pb-3 text-sm">
                <input type="checkbox" className="size-4" checked={edit.is_active} onChange={(e) => setEdit({ ...edit, is_active: e.target.checked })} />
                แสดงในร้าน
              </label>
            </div>
            {err && <Alert tone="red">{err}</Alert>}
            <Button className="w-full" onClick={save} loading={busy}>บันทึก</Button>
          </div>
        )}
      </Modal>
    </div>
  );
}
