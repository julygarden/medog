"use client";

import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, Empty, Input, Segmented, Spinner } from "../ui";
import { VOLUNTEER_SKILLS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { VolunteerApplication } from "@/lib/types";
import { formatDate } from "@/lib/utils";

const STATUS = {
  draft: { label: "ยังไม่ส่งใบสมัคร", tone: "gray" as const },
  pending: { label: "รออนุมัติ", tone: "amber" as const },
  approved: { label: "อนุมัติแล้ว", tone: "green" as const },
  rejected: { label: "ไม่อนุมัติ", tone: "red" as const },
};

export function AdminVolunteers() {
  const [rows, setRows] = useState<VolunteerApplication[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [filter, setFilter] = useState<"pending" | "approved" | "all">("pending");
  const [notes, setNotes] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    if (!isConfigured) return;
    let q = supabase.from("volunteer_applications").select("*").order("updated_at", { ascending: false });
    if (filter !== "all") q = q.eq("status", filter);
    const { data } = await q;
    setRows((data as VolunteerApplication[]) ?? []);
    setLoading(false);
  }, [filter]);
  useEffect(() => {
    load();
  }, [load]);

  const review = async (a: VolunteerApplication, status: "approved" | "rejected") => {
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("volunteer_applications")
      .update({ status, review_note: notes[a.user_id] || null, reviewed_by: u.user?.id, reviewed_at: new Date().toISOString() })
      .eq("user_id", a.user_id);
    if (error) alert(errorText(error));
    load();
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold">ใบสมัครอาสาสมัคร</h2>
        <Segmented value={filter} onChange={setFilter} options={{ pending: "รออนุมัติ", approved: "อนุมัติแล้ว", all: "ทั้งหมด" }} />
      </div>
      {loading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ไม่มีใบสมัคร" />
      ) : (
        <div className="space-y-3">
          {rows.map((a) => (
            <Card key={a.user_id} className="p-4 text-sm">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="text-base font-semibold">{a.full_name || "(ยังไม่กรอกชื่อ)"}</p>
                  <p className="text-muted">
                    {a.phone} · {a.amphoe && `อ.${a.amphoe} `}{a.province} · คะแนนทดสอบ {a.quiz_score ?? "-"}/10 · {formatDate(a.updated_at)}
                  </p>
                </div>
                <Badge tone={STATUS[a.status].tone}>{STATUS[a.status].label}</Badge>
              </div>
              {a.skills.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {a.skills.map((s) => <Badge key={s} tone="blue">{VOLUNTEER_SKILLS[s as keyof typeof VOLUNTEER_SKILLS] ?? s}</Badge>)}
                  {a.has_transport && <Badge tone="violet">มียานพาหนะ</Badge>}
                </div>
              )}
              {a.motivation && <p className="mt-2 rounded-lg bg-cream p-3">“{a.motivation}”</p>}
              {a.availability && <p className="mt-1 text-muted">เวลาที่สะดวก: {a.availability}</p>}
              {a.status !== "draft" && (
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                  <Input placeholder="หมายเหตุถึงผู้สมัคร (ไม่บังคับ)" value={notes[a.user_id] ?? ""} onChange={(e) => setNotes({ ...notes, [a.user_id]: e.target.value })} />
                  {a.status !== "approved" && <Button size="md" onClick={() => review(a, "approved")}>อนุมัติ</Button>}
                  {a.status !== "rejected" && <Button size="md" variant="secondary" onClick={() => review(a, "rejected")}>{a.status === "approved" ? "ถอนสิทธิ์" : "ไม่อนุมัติ"}</Button>}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
