"use client";

import { Pencil, Plus, Trash2 } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { AddressSelect } from "../AddressSelect";
import { Alert, Button, Card, Empty, Field, Input, Modal, Select, Spinner, Textarea } from "../ui";
import { AGENCY_KIND } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Agency } from "@/lib/types";

const BLANK: Omit<Agency, "id"> = {
  name: "",
  kind: "sao",
  province: null,
  amphoe: null,
  tambon: null,
  contact_person: "",
  phone: "",
  email: "",
  line_id: "",
  notes: "",
};

export function AdminAgencies() {
  const [rows, setRows] = useState<Agency[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [edit, setEdit] = useState<(Omit<Agency, "id"> & { id?: string }) | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!isConfigured) return;
    const { data } = await supabase.from("agencies").select("*").order("province").order("name");
    setRows((data as Agency[]) ?? []);
    setLoading(false);
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    if (!edit?.name.trim()) return setErr("กรุณาใส่ชื่อหน่วยงาน");
    setBusy(true);
    const { id, ...payload } = edit;
    const res = id ? await supabase.from("agencies").update(payload).eq("id", id) : await supabase.from("agencies").insert(payload);
    setBusy(false);
    if (res.error) return setErr(errorText(res.error));
    setEdit(null);
    load();
  };

  const remove = async (a: Agency) => {
    if (!confirm(`ลบ ${a.name}?`)) return;
    await supabase.from("agencies").delete().eq("id", a.id);
    load();
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">หน่วยงานในพื้นที่</h2>
          <p className="text-sm text-muted">รายชื่อ อบต./เทศบาล/ปศุสัตว์/มูลนิธิ สำหรับส่งต่อเคส</p>
        </div>
        <Button onClick={() => { setErr(""); setEdit({ ...BLANK }); }}>
          <Plus className="size-4" /> เพิ่มหน่วยงาน
        </Button>
      </div>
      {loading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ยังไม่มีหน่วยงาน" />
      ) : (
        <Card className="divide-y divide-line">
          {rows.map((a) => (
            <div key={a.id} className="flex items-start justify-between gap-3 px-4 py-3 text-sm">
              <div>
                <p className="font-semibold">{a.name}</p>
                <p className="text-muted">
                  {AGENCY_KIND[a.kind]} · {[a.tambon && `ต.${a.tambon}`, a.amphoe && `อ.${a.amphoe}`, a.province && `จ.${a.province}`].filter(Boolean).join(" ")}
                </p>
                <p className="text-muted">{[a.contact_person, a.phone, a.email, a.line_id && `LINE ${a.line_id}`].filter(Boolean).join(" · ") || "ยังไม่มีช่องทางติดต่อ"}</p>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => { setErr(""); setEdit({ ...a }); }}><Pencil className="size-4" /></Button>
                <Button size="sm" variant="ghost" className="text-red-700" onClick={() => remove(a)}><Trash2 className="size-4" /></Button>
              </div>
            </div>
          ))}
        </Card>
      )}

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? "แก้ไขหน่วยงาน" : "เพิ่มหน่วยงาน"}>
        {edit && (
          <div className="space-y-4">
            <Field label="ชื่อหน่วยงาน" required>
              <Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <Field label="ประเภท">
              <Select value={edit.kind} onChange={(e) => setEdit({ ...edit, kind: e.target.value as Agency["kind"] })} options={AGENCY_KIND} />
            </Field>
            <AddressSelect className="grid gap-3" value={edit} onChange={(a) => setEdit({ ...edit, ...a })} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="ผู้ประสานงาน"><Input value={edit.contact_person ?? ""} onChange={(e) => setEdit({ ...edit, contact_person: e.target.value })} /></Field>
              <Field label="โทร"><Input value={edit.phone ?? ""} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} /></Field>
              <Field label="อีเมล"><Input type="email" value={edit.email ?? ""} onChange={(e) => setEdit({ ...edit, email: e.target.value })} /></Field>
              <Field label="LINE"><Input value={edit.line_id ?? ""} onChange={(e) => setEdit({ ...edit, line_id: e.target.value })} /></Field>
            </div>
            <Field label="หมายเหตุ"><Textarea rows={2} value={edit.notes ?? ""} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} /></Field>
            {err && <Alert tone="red">{err}</Alert>}
            <Button className="w-full" onClick={save} loading={busy}>บันทึก</Button>
          </div>
        )}
      </Modal>
    </div>
  );
}
