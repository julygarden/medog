"use client";

import Link from "next/link";
import { Download, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { rabiesValid } from "../animals/AnimalCard";
import { useThaiAddress } from "../AddressSelect";
import { Badge, Button, Card, Input, Select, Spinner } from "../ui";
import { ANIMAL_STATUS, SEX, SPECIES, STERILIZED } from "@/lib/constants";
import { isConfigured, supabase } from "@/lib/supabase";
import type { Animal } from "@/lib/types";
import { downloadText, formatAge, formatDate } from "@/lib/utils";

export function AdminAnimals() {
  const tree = useThaiAddress();
  const [rows, setRows] = useState<Animal[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [province, setProvince] = useState("");
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!isConfigured) return;
    setLoading(true);
    let query = supabase.from("animals").select("*, vaccinations(*)").order("created_at", { ascending: false }).limit(2000);
    if (province) query = query.eq("province", province);
    query.then(({ data }) => {
      setRows((data as Animal[]) ?? []);
      setLoading(false);
    });
  }, [province]);

  const shown = useMemo(() => {
    const k = q.trim();
    return k ? rows.filter((a) => [a.name, a.breed, a.tambon, a.amphoe, a.microchip, a.caretaker_name].some((x) => x?.includes(k))) : rows;
  }, [rows, q]);

  const exportCsv = () => {
    const head = ["ชื่อ", "ชนิด", "ประเภท", "สายพันธุ์", "เพศ", "อายุ", "ทำหมัน", "วัคซีนพิษสุนัขบ้า", "จังหวัด", "อำเภอ", "ตำบล", "lat", "lng", "ผู้ดูแล", "โทร", "ลงทะเบียน", "ตัวอย่าง"];
    const lines = shown.map((a) => [
      a.name, SPECIES[a.species], ANIMAL_STATUS[a.status], a.breed, SEX[a.sex], formatAge(a.birth_date, a.birth_date_estimated),
      STERILIZED[a.sterilized], rabiesValid(a) ? "มี (ภายใน 1 ปี)" : "ไม่มี", a.province, a.amphoe, a.tambon, a.lat, a.lng,
      a.caretaker_name, a.caretaker_phone, formatDate(a.created_at), a.is_demo ? "ใช่" : "",
    ]);
    const csv = [head, ...lines].map((l) => l.map((x) => `"${String(x ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    downloadText(`medog-animals-${province || "all"}.csv`, csv);
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">ข้อมูลสัตว์รายตัว</h2>
          <p className="text-sm text-muted">เห็นเฉพาะแอดมิน (เจ้าของระบบ) · {shown.length} ตัว</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={province} onChange={(e) => setProvince(e.target.value)} placeholder="ทุกจังหวัด"
            options={(tree ? Object.keys(tree) : []).map((p) => ({ value: p, label: p }))} className="w-40" />
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
            <Input className="w-52 pl-9" placeholder="ค้นหา" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <Button variant="secondary" onClick={exportCsv}><Download className="size-4" /> CSV</Button>
        </div>
      </div>
      {loading ? (
        <Spinner />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-muted">
                <th className="px-4 py-3 font-medium">ชื่อ</th>
                <th className="px-4 py-3 font-medium">ชนิด / ประเภท</th>
                <th className="px-4 py-3 font-medium">พื้นที่</th>
                <th className="px-4 py-3 font-medium">วัคซีน</th>
                <th className="px-4 py-3 font-medium">หมัน</th>
                <th className="px-4 py-3 font-medium">ลงทะเบียน</th>
              </tr>
            </thead>
            <tbody>
              {shown.slice(0, 500).map((a) => (
                <tr key={a.id} className="border-b border-line/60 hover:bg-cream">
                  <td className="px-4 py-2.5">
                    <Link href={`/animals/${a.id}`} className="font-medium hover:underline">{a.name || "ไม่มีชื่อ"}</Link>
                    {a.is_demo && <Badge className="ml-1">ตัวอย่าง</Badge>}
                  </td>
                  <td className="px-4 py-2.5">{SPECIES[a.species]} · {ANIMAL_STATUS[a.status].split(" ")[0]}</td>
                  <td className="px-4 py-2.5">ต.{a.tambon} อ.{a.amphoe}</td>
                  <td className="px-4 py-2.5"><Badge tone={rabiesValid(a) ? "green" : "red"}>{rabiesValid(a) ? "ครบ" : "ขาด"}</Badge></td>
                  <td className="px-4 py-2.5">{a.sterilized === "yes" ? "✓" : "–"}</td>
                  <td className="px-4 py-2.5 text-muted">{formatDate(a.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {shown.length > 500 && <p className="p-3 text-center text-xs text-muted">แสดง 500 รายการแรก — ดาวน์โหลด CSV เพื่อดูทั้งหมด</p>}
        </Card>
      )}
    </div>
  );
}
