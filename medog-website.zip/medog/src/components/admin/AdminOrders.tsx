"use client";

import { useCallback, useEffect, useState } from "react";
import { slipUrl } from "../payment/SlipInput";
import { Badge, Button, Card, Empty, Input, Segmented, Select, Spinner } from "../ui";
import { ORDER_STATUS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Order } from "@/lib/types";
import { baht, formatDateTime, orderCode } from "@/lib/utils";

export function AdminOrders() {
  const [rows, setRows] = useState<Order[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [filter, setFilter] = useState<"todo" | "all">("todo");
  const [slips, setSlips] = useState<Record<string, string>>({});
  const [tracking, setTracking] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    if (!isConfigured) return;
    let q = supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(300);
    if (filter === "todo") q = q.in("status", ["pending_payment", "paid"]);
    const { data } = await q;
    setRows((data as Order[]) ?? []);
    setLoading(false);
  }, [filter]);
  useEffect(() => {
    load();
  }, [load]);

  const update = async (o: Order, patch: Partial<Order>) => {
    const { error } = await supabase.from("orders").update(patch).eq("id", o.id);
    if (error) alert(errorText(error));
    load();
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold">คำสั่งซื้อ</h2>
        <Segmented value={filter} onChange={setFilter} options={{ todo: "ต้องดำเนินการ", all: "ทั้งหมด" }} />
      </div>
      {loading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ไม่มีคำสั่งซื้อ" />
      ) : (
        <div className="space-y-3">
          {rows.map((o) => (
            <Card key={o.id} className="flex flex-col gap-4 p-4 text-sm sm:flex-row">
              <div className="flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-semibold">{orderCode(o.order_no)}</p>
                  <Badge tone={ORDER_STATUS[o.status].tone}>{ORDER_STATUS[o.status].label}</Badge>
                  <Badge tone={o.delivery === "donate" ? "violet" : "blue"}>{o.delivery === "donate" ? "บริจาคให้โครงการ" : "จัดส่ง"}</Badge>
                  <span className="text-muted">{formatDateTime(o.created_at)}</span>
                </div>
                <p>{o.items.map((i) => `${i.name} ×${i.qty}`).join(", ")}</p>
                <p className="text-lg font-bold">{baht(o.total)}</p>
                {o.delivery === "ship" && (
                  <p className="text-muted">
                    ส่งถึง: {o.ship_name} {o.ship_phone} — {o.ship_address}
                  </p>
                )}
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <Select
                    value={o.status}
                    onChange={(e) => update(o, { status: e.target.value as Order["status"] })}
                    options={Object.fromEntries(Object.entries(ORDER_STATUS).map(([k, v]) => [k, v.label]))}
                    className="w-40"
                  />
                  {o.delivery === "ship" && (
                    <>
                      <Input
                        className="w-44"
                        placeholder="เลขพัสดุ"
                        value={tracking[o.id] ?? o.tracking_no ?? ""}
                        onChange={(e) => setTracking({ ...tracking, [o.id]: e.target.value })}
                      />
                      <Button size="sm" variant="secondary" onClick={() => update(o, { tracking_no: tracking[o.id] ?? o.tracking_no, status: "shipped" })}>
                        บันทึกและแจ้งจัดส่ง
                      </Button>
                    </>
                  )}
                </div>
              </div>
              <div className="sm:w-40">
                {o.slip_path ? (
                  slips[o.id] ? (
                    <a href={slips[o.id]} target="_blank" rel="noreferrer">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={slips[o.id]} alt="สลิป" className="max-h-56 rounded-lg border border-line" />
                    </a>
                  ) : (
                    <Button size="sm" variant="secondary" className="w-full" onClick={async () => setSlips({ ...slips, [o.id]: await slipUrl(o.slip_path!) })}>
                      ดูสลิป
                    </Button>
                  )
                ) : (
                  <p className="text-xs text-muted">ยังไม่แนบสลิป</p>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
