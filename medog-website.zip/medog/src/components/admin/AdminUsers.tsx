"use client";

import { Search } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useThaiAddress } from "../AddressSelect";
import { Alert, Card, Input, Select, Spinner } from "../ui";
import { ROLE } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Role } from "@/lib/types";
import { formatDate } from "@/lib/utils";

interface Row {
  id: string;
  email: string;
  display_name: string | null;
  phone: string | null;
  role: Role;
  staff_province: string | null;
  created_at: string;
}

export function AdminUsers() {
  const tree = useThaiAddress();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [err, setErr] = useState("");

  const load = useCallback(async (query: string) => {
    if (!isConfigured) return;
    setLoading(true);
    const { data, error } = await supabase.rpc("admin_list_users", { p_query: query || null });
    if (error) setErr(errorText(error));
    setRows((data as Row[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(q), 300);
    return () => clearTimeout(t);
  }, [q, load]);

  const update = async (r: Row, patch: Partial<Row>) => {
    setErr("");
    const { error } = await supabase.from("profiles").update(patch).eq("id", r.id);
    if (error) setErr(errorText(error));
    load(q);
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">ผู้ใช้และสิทธิ์</h2>
          <p className="text-sm text-muted">แต่งตั้งผู้ช่วยแอดมิน (ดูแลเฉพาะเคส) และกำหนดจังหวัดที่รับผิดชอบ</p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <Input className="w-64 pl-9" placeholder="ค้นหาอีเมลหรือชื่อ" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      {err && <Alert tone="red" className="mb-3">{err}</Alert>}
      {loading ? (
        <Spinner />
      ) : (
        <Card className="divide-y divide-line">
          {rows.map((r) => (
            <div key={r.id} className="flex flex-col gap-3 px-4 py-3 text-sm sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{r.display_name || "-"}</p>
                <p className="truncate text-muted">{r.email} · สมัคร {formatDate(r.created_at)}</p>
              </div>
              <Select
                value={r.role}
                onChange={(e) => update(r, { role: e.target.value as Role })}
                options={ROLE}
                className="sm:w-52"
              />
              {r.role === "co_admin" && (
                <Select
                  value={r.staff_province ?? ""}
                  onChange={(e) => update(r, { staff_province: e.target.value || null })}
                  placeholder="ทุกจังหวัด"
                  options={(tree ? Object.keys(tree) : []).map((p) => ({ value: p, label: p }))}
                  className="sm:w-40"
                />
              )}
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
