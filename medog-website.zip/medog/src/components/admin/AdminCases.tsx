"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Copy, ExternalLink, Mail, MessageCircle, Siren } from "lucide-react";
import { useAuth } from "../AuthProvider";
import { urgencyTone } from "../cases/CaseCard";
import { UrgencyMeter } from "../cases/UrgencyMeter";
import { Alert, Badge, Button, Card, Empty, Field, Input, Modal, Segmented, Select, Spinner, Textarea } from "../ui";
import { AGENCY_KIND, AGGRESSION, CASE_CATEGORY, CASE_STATUS, PROXIMITY, SPECIES, VAX_STATUS } from "@/lib/constants";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { Agency, Case, CaseContact, CaseStatus, CaseUpdate } from "@/lib/types";
import { caseCode, formatDate, formatDateTime } from "@/lib/utils";

type Filter = "todo" | "active" | "done" | "all";

export function AdminCases({ focusId }: { focusId: string | null }) {
  const [rows, setRows] = useState<Case[]>([]);
  const [loading, setLoading] = useState(isConfigured);
  const [filter, setFilter] = useState<Filter>("todo");
  const [open, setOpen] = useState<Case | null>(null);

  const load = useCallback(async () => {
    if (!isConfigured) return;
    const { data } = await supabase.from("cases").select("*").order("created_at", { ascending: false }).limit(500);
    const list = (data as Case[]) ?? [];
    setRows(list);
    setLoading(false);
    return list;
  }, []);

  useEffect(() => {
    load().then((list) => {
      if (focusId && list) setOpen(list.find((c) => c.id === focusId) ?? null);
    });
  }, [load, focusId]);

  const shown = useMemo(
    () =>
      rows
        .filter((c) => {
          if (filter === "todo") return c.status === "submitted" || c.status === "reviewing";
          if (filter === "active") return ["verified", "forwarded", "fundraising", "in_progress"].includes(c.status);
          if (filter === "done") return c.status === "resolved" || c.status === "rejected";
          return true;
        })
        .sort((a, b) => Number(b.is_urgent) - Number(a.is_urgent) || b.urgency_score - a.urgency_score),
    [rows, filter],
  );

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold">จัดการเคส</h2>
        <Segmented
          value={filter}
          onChange={setFilter}
          options={{ todo: "รอตรวจสอบ", active: "กำลังดำเนินการ", done: "ปิดแล้ว", all: "ทั้งหมด" }}
        />
      </div>
      {loading ? (
        <Spinner />
      ) : shown.length === 0 ? (
        <Empty title="ไม่มีเคสในหมวดนี้" />
      ) : (
        <Card className="divide-y divide-line">
          {shown.map((c) => {
            const ut = urgencyTone(c.urgency_score);
            return (
              <button key={c.id} onClick={() => setOpen(c)} className="flex w-full items-center gap-4 px-4 py-3 text-left hover:bg-cream">
                <span className={`grid size-12 shrink-0 place-items-center rounded-xl text-sm font-bold ${ut.cls}`}>{c.urgency_score}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">
                    {c.is_urgent && <Siren className="mr-1 inline size-4 text-red-600" />}
                    {c.title}
                  </p>
                  <p className="truncate text-xs text-muted">
                    {caseCode(c.case_no)} · {CASE_CATEGORY[c.category]} · ต.{c.tambon ?? "-"} อ.{c.amphoe} จ.{c.province} · {formatDate(c.created_at)}
                  </p>
                </div>
                <Badge tone={CASE_STATUS[c.status].tone}>{CASE_STATUS[c.status].label}</Badge>
              </button>
            );
          })}
        </Card>
      )}
      {open && (
        <CaseManager
          c={open}
          onClose={() => setOpen(null)}
          onSaved={async () => {
            const list = await load();
            setOpen(list?.find((x) => x.id === open.id) ?? null);
          }}
        />
      )}
    </div>
  );
}

function CaseManager({ c, onClose, onSaved }: { c: Case; onClose: () => void; onSaved: () => void }) {
  const { user } = useAuth();
  const [f, setF] = useState({
    status: c.status,
    is_urgent: c.is_urgent,
    goal_amount: c.goal_amount ? String(c.goal_amount) : "",
    fund_purpose: c.fund_purpose ?? "",
    promptpay_id: c.promptpay_id ?? "",
    public_note: c.public_note ?? "",
    forwarded_agency_id: c.forwarded_agency_id ?? "",
  });
  const [contact, setContact] = useState<CaseContact | null>(null);
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [updates, setUpdates] = useState<CaseUpdate[]>([]);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState(false);

  const loadSide = useCallback(async () => {
    const [ct, ag, up] = await Promise.all([
      supabase.from("case_contacts").select("*").eq("case_id", c.id).maybeSingle(),
      supabase.from("agencies").select("*").order("name"),
      supabase.from("case_updates").select("*").eq("case_id", c.id).order("created_at", { ascending: false }),
    ]);
    setContact(ct.data as CaseContact | null);
    setAgencies((ag.data as Agency[]) ?? []);
    setUpdates((up.data as CaseUpdate[]) ?? []);
  }, [c.id]);

  useEffect(() => {
    loadSide();
  }, [loadSide]);

  const areaAgencies = agencies
    .map((a) => ({ a, score: (a.province === c.province ? 2 : 0) + (a.amphoe === c.amphoe ? 2 : 0) + (a.tambon === c.tambon ? 1 : 0) }))
    .sort((x, y) => y.score - x.score);
  const agency = agencies.find((a) => a.id === f.forwarded_agency_id) ?? null;

  const save = async () => {
    setErr("");
    let status: CaseStatus = f.status;
    if (status === "fundraising" && (!f.is_urgent || !Number(f.goal_amount))) {
      return setErr("การเปิดรับบริจาคต้องติ๊ก “ประเมินแล้วว่าเร่งด่วน” และระบุยอดเป้าหมาย");
    }
    const agencyChanged = (f.forwarded_agency_id || null) !== c.forwarded_agency_id;
    if (agencyChanged && f.forwarded_agency_id && ["submitted", "reviewing", "verified"].includes(status)) status = "forwarded";
    setBusy(true);
    const { error } = await supabase
      .from("cases")
      .update({
        status,
        is_urgent: f.is_urgent,
        goal_amount: f.goal_amount ? Number(f.goal_amount) : null,
        fund_purpose: f.fund_purpose || null,
        promptpay_id: f.promptpay_id.trim() || null,
        public_note: f.public_note || null,
        forwarded_agency_id: f.forwarded_agency_id || null,
        forwarded_at: agencyChanged ? (f.forwarded_agency_id ? new Date().toISOString() : null) : c.forwarded_at,
        reviewed_by: user?.id,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", c.id);
    if (!error && agencyChanged && agency) {
      await supabase.from("case_updates").insert({ case_id: c.id, author_id: user?.id, note: `ส่งต่อ ${agency.name}`, is_public: true });
    }
    setBusy(false);
    if (error) return setErr(errorText(error));
    onSaved();
  };

  const addNote = async (isPublic: boolean) => {
    if (!note.trim()) return;
    const { error } = await supabase.from("case_updates").insert({ case_id: c.id, author_id: user?.id, note: note.trim(), is_public: isPublic });
    if (error) return setErr(errorText(error));
    setNote("");
    loadSide();
  };

  const letter = agency ? buildLetter(c, agency) : "";
  const copy = async () => {
    await navigator.clipboard.writeText(letter);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Modal open onClose={onClose} title={`${caseCode(c.case_no)} · ${c.title}`} wide>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-4 text-sm">
          {c.photo_urls.length > 0 && (
            <div className="flex gap-2 overflow-x-auto">
              {c.photo_urls.map((u) => (
                <a key={u} href={u} target="_blank" rel="noreferrer" className="size-24 shrink-0 overflow-hidden rounded-lg">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={u} alt="" className="size-full object-cover" />
                </a>
              ))}
            </div>
          )}
          <div className="space-y-1">
            <p><span className="text-muted">ประเภท:</span> {CASE_CATEGORY[c.category]} · {SPECIES[c.species]} {c.animal_count} ตัว</p>
            <p><span className="text-muted">พื้นที่:</span> {c.location_note} ต.{c.tambon ?? "-"} อ.{c.amphoe} จ.{c.province}</p>
            {c.lat != null && (
              <a className="inline-flex items-center gap-1 text-sky-700 underline" target="_blank" rel="noreferrer" href={`https://www.google.com/maps?q=${c.lat},${c.lng}`}>
                เปิดใน Google Maps <ExternalLink className="size-3" />
              </a>
            )}
            <p><span className="text-muted">ใกล้ชุมชน:</span> {PROXIMITY[c.proximity]}</p>
            <p><span className="text-muted">ความก้าวร้าว:</span> {AGGRESSION[c.aggression]} · <span className="text-muted">วัคซีน:</span> {VAX_STATUS[c.vaccination_status]}</p>
          </div>
          {c.description && <p className="whitespace-pre-line rounded-xl bg-sand p-3">{c.description}</p>}
          <UrgencyMeter c={c} />
          <Card className="p-3">
            <p className="font-semibold">ผู้แจ้ง</p>
            {contact ? (
              <p>
                {contact.reporter_name || "-"} · {contact.phone && <a href={`tel:${contact.phone}`} className="underline">{contact.phone}</a>}
                {contact.line_id && <> · LINE {contact.line_id}</>}
              </p>
            ) : (
              <p className="text-muted">ไม่มีข้อมูลติดต่อ</p>
            )}
          </Card>
          <div>
            <p className="mb-2 font-semibold">ไทม์ไลน์ / บันทึก</p>
            <div className="mb-2 flex gap-2">
              <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="เพิ่มบันทึก" />
              <Button size="sm" variant="secondary" onClick={() => addNote(false)}>ภายใน</Button>
              <Button size="sm" onClick={() => addNote(true)}>สาธารณะ</Button>
            </div>
            <ul className="max-h-56 space-y-2 overflow-y-auto">
              {updates.map((u) => (
                <li key={u.id} className="rounded-lg bg-cream px-3 py-2">
                  <p>
                    {u.status && <b>{CASE_STATUS[u.status]?.label} </b>}
                    {u.note}
                    {!u.is_public && <Badge className="ml-1">ภายใน</Badge>}
                  </p>
                  <p className="text-xs text-muted">{formatDateTime(u.created_at)}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-4">
          <Field label="สถานะเคส">
            <Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as CaseStatus })}
              options={Object.fromEntries(Object.entries(CASE_STATUS).map(([k, v]) => [k, v.label]))} />
          </Field>
          <label className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm font-medium text-red-800">
            <input type="checkbox" className="size-4" checked={f.is_urgent} onChange={(e) => setF({ ...f, is_urgent: e.target.checked })} />
            ประเมินแล้วว่าเร่งด่วน (จำเป็นต้องเปิดรับบริจาค)
          </label>
          {(f.is_urgent || f.status === "fundraising") && (
            <div className="grid gap-3 rounded-xl border border-line p-3 sm:grid-cols-2">
              <Field label="ยอดเป้าหมาย (บาท)">
                <Input type="number" min={0} value={f.goal_amount} onChange={(e) => setF({ ...f, goal_amount: e.target.value })} />
              </Field>
              <Field label="พร้อมเพย์เฉพาะเคส" hint="เว้นว่าง = ใช้บัญชีกลาง">
                <Input value={f.promptpay_id} onChange={(e) => setF({ ...f, promptpay_id: e.target.value })} />
              </Field>
              <Field label="ใช้เงินสำหรับ" className="sm:col-span-2">
                <Input value={f.fund_purpose} onChange={(e) => setF({ ...f, fund_purpose: e.target.value })} placeholder="เช่น ค่ารักษาและยา" />
              </Field>
            </div>
          )}
          <Field label="ส่งต่อหน่วยงานในพื้นที่">
            <Select
              value={f.forwarded_agency_id}
              onChange={(e) => setF({ ...f, forwarded_agency_id: e.target.value })}
              placeholder="— ยังไม่ส่งต่อ —"
              options={areaAgencies.map(({ a, score }) => ({
                value: a.id,
                label: `${score >= 2 ? "★ " : ""}${a.name} (${AGENCY_KIND[a.kind]}${a.amphoe ? ` อ.${a.amphoe}` : ""})`,
              }))}
            />
          </Field>
          {agency && (
            <div className="rounded-xl border border-line bg-cream p-3 text-sm">
              <p className="mb-2 font-semibold">ข้อความแจ้งหน่วยงาน</p>
              <pre className="max-h-40 overflow-y-auto whitespace-pre-wrap font-sans text-xs text-ink-soft">{letter}</pre>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="secondary" onClick={copy}>
                  <Copy className="size-3.5" /> {copied ? "คัดลอกแล้ว" : "คัดลอก"}
                </Button>
                <a
                  className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#06C755] px-3 text-sm font-semibold text-white"
                  href={`https://line.me/R/msg/text/?${encodeURIComponent(letter)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MessageCircle className="size-3.5" /> ส่งทาง LINE
                </a>
                {agency.email && (
                  <a
                    className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-line bg-white px-3 text-sm font-semibold"
                    href={`mailto:${agency.email}?subject=${encodeURIComponent(`ขอความอนุเคราะห์ช่วยเหลือสัตว์ ${caseCode(c.case_no)}`)}&body=${encodeURIComponent(letter)}`}
                  >
                    <Mail className="size-3.5" /> อีเมล
                  </a>
                )}
              </div>
              {agency.phone && <p className="mt-2 text-xs">โทร: <a className="underline" href={`tel:${agency.phone}`}>{agency.phone}</a></p>}
            </div>
          )}
          <Field label="หมายเหตุสาธารณะ (แสดงในหน้าเคส)">
            <Textarea rows={2} value={f.public_note} onChange={(e) => setF({ ...f, public_note: e.target.value })} />
          </Field>
          {err && <Alert tone="red">{err}</Alert>}
          <div className="flex gap-2">
            <Button onClick={save} loading={busy} className="flex-1">บันทึก</Button>
            <Link href={`/cases/${c.id}`} className="inline-flex h-11 items-center rounded-xl border border-line px-4 text-sm font-semibold hover:bg-sand">
              ดูหน้าเคส
            </Link>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function buildLetter(c: Case, a: Agency) {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const place = [c.location_note, c.tambon && `ต.${c.tambon}`, c.amphoe && `อ.${c.amphoe}`, c.province && `จ.${c.province}`].filter(Boolean).join(" ");
  return [
    `เรื่อง ขอความอนุเคราะห์ช่วยเหลือสัตว์ในพื้นที่ (เคส ${caseCode(c.case_no)})`,
    `เรียน ${a.contact_person ? `${a.contact_person} ` : ""}${a.name}`,
    "",
    `ระบบ Me Dog ได้รับแจ้งเคส “${c.title}” ประเภท${CASE_CATEGORY[c.category]} (${SPECIES[c.species]} ${c.animal_count} ตัว)`,
    `สถานที่: ${place}${c.lat != null ? `\nพิกัด: https://www.google.com/maps?q=${c.lat},${c.lng}` : ""}`,
    c.description ? `รายละเอียด: ${c.description}` : "",
    `คะแนนความเร่งด่วน: ${c.urgency_score}/100 (ใกล้ชุมชน: ${PROXIMITY[c.proximity]} / ความก้าวร้าว: ${AGGRESSION[c.aggression]} / วัคซีน: ${VAX_STATUS[c.vaccination_status]})`,
    "",
    "ทีมงานได้ตรวจสอบข้อมูลเบื้องต้นแล้ว จึงเรียนมาเพื่อโปรดพิจารณาให้ความช่วยเหลือตามอำนาจหน้าที่",
    `ดูรูปภาพและความคืบหน้า: ${origin}/cases/${c.id}`,
    "",
    "ขอแสดงความนับถือ",
    "ทีมงาน Me Dog",
  ]
    .filter((x) => x !== null)
    .join("\n");
}
