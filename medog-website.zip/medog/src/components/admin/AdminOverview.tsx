"use client";

import { useEffect, useState } from "react";
import { Trash2 } from "lucide-react";
import { Alert, Button, Card, Stat } from "../ui";
import { errorText, isConfigured, supabase } from "@/lib/supabase";
import type { PublicSummary } from "@/lib/types";
import { baht, num } from "@/lib/utils";
import type { AdminTab } from "./types";

export function AdminOverview({ go }: { go: (t: AdminTab) => void }) {
  const [s, setS] = useState<PublicSummary | null>(null);
  const [pending, setPending] = useState({ cases: 0, donations: 0, orders: 0, volunteers: 0, demo: 0 });
  const [msg, setMsg] = useState<{ tone: "green" | "red"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!isConfigured) return;
    const count = (q: PromiseLike<{ count: number | null }>) => q.then((r) => r.count ?? 0);
    const [sum, c, d, o, v, demo] = await Promise.all([
      supabase.rpc("public_summary"),
      count(supabase.from("cases").select("id", { count: "exact", head: true }).in("status", ["submitted", "reviewing"])),
      count(supabase.from("donations").select("id", { count: "exact", head: true }).eq("status", "pending")),
      count(supabase.from("orders").select("id", { count: "exact", head: true }).eq("status", "pending_payment").not("slip_path", "is", null)),
      count(supabase.from("volunteer_applications").select("user_id", { count: "exact", head: true }).eq("status", "pending")),
      count(supabase.from("animals").select("id", { count: "exact", head: true }).eq("is_demo", true)),
    ]);
    setS(sum.data as PublicSummary);
    setPending({ cases: c, donations: d, orders: o, volunteers: v, demo });
  };

  useEffect(() => {
    load();
  }, []);

  const clearDemo = async () => {
    if (!confirm("ลบข้อมูลตัวอย่างทั้งหมด (สัตว์ เคส บริจาค สินค้าตัวอย่าง)? ย้อนกลับไม่ได้")) return;
    setBusy(true);
    const { error } = await supabase.rpc("clear_demo_data");
    setBusy(false);
    setMsg(error ? { tone: "red", text: errorText(error) } : { tone: "green", text: "ลบข้อมูลตัวอย่างแล้ว" });
    load();
  };

  const todo = [
    { n: pending.cases, t: "เคสรอตรวจสอบ", tab: "cases" as AdminTab },
    { n: pending.donations, t: "สลิปบริจาครอยืนยัน", tab: "donations" as AdminTab },
    { n: pending.orders, t: "คำสั่งซื้อรอตรวจสลิป", tab: "orders" as AdminTab },
    { n: pending.volunteers, t: "ใบสมัครอาสารออนุมัติ", tab: "volunteers" as AdminTab },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {todo.map((x) => (
          <button key={x.t} onClick={() => go(x.tab)} className="text-left">
            <Card className={`p-4 transition hover:shadow-md ${x.n > 0 ? "border-brand/40 bg-brand-soft/40" : ""}`}>
              <p className="text-3xl font-bold">{x.n}</p>
              <p className="text-sm text-muted">{x.t}</p>
            </Card>
          </button>
        ))}
      </div>

      {s && (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="สัตว์ในระบบ" value={num(s.animals)} sub={`สุนัข ${num(s.dogs)} · แมว ${num(s.cats)}`} />
          <Stat label="วัคซีนพิษสุนัขบ้า (ภายใน 1 ปี)" value={`${s.animals ? Math.round((s.rabies_ok / s.animals) * 100) : 0}%`} sub={`${num(s.rabies_ok)} ตัว`} />
          <Stat label="อาสา + ทีมงาน" value={num(s.volunteers)} />
          <Stat label="ยอดบริจาคยืนยันแล้ว" value={baht(s.funds_raised)} sub={`เคสสำเร็จ ${num(s.cases_resolved)}`} />
        </div>
      )}

      {pending.demo > 0 && (
        <Card className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-semibold">มีข้อมูลตัวอย่าง {pending.demo} ตัวในระบบ</p>
            <p className="text-sm text-muted">เมื่อพร้อมใช้งานจริง ให้ลบข้อมูลตัวอย่างออก เพื่อไม่ให้ปนกับข้อมูลจริง</p>
          </div>
          <Button variant="danger" onClick={clearDemo} loading={busy}>
            <Trash2 className="size-4" /> ลบข้อมูลตัวอย่าง
          </Button>
        </Card>
      )}
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
    </div>
  );
}
