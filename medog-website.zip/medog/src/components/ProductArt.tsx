import { Gift, Stethoscope, Syringe, UtensilsCrossed } from "lucide-react";
import type { Product } from "@/lib/types";
import { cls } from "@/lib/utils";

export function ProductArt({ category, className = "" }: { category: Product["category"]; className?: string }) {
  const map = {
    food: { icon: <UtensilsCrossed className="size-10" />, bg: "bg-amber-50 text-amber-700" },
    medical: { icon: <Stethoscope className="size-10" />, bg: "bg-sky-50 text-sky-700" },
    kit: { icon: <Syringe className="size-10" />, bg: "bg-green-50 text-green-700" },
    merch: { icon: <Gift className="size-10" />, bg: "bg-brand-soft text-brand-dark" },
  }[category];
  return <div className={cls("grid place-items-center", map.bg, className)}>{map.icon}</div>;
}

